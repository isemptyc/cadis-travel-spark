from __future__ import annotations

import argparse
import hmac
import json
import math
import os
import time
import uuid
from dataclasses import dataclass
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import unquote, urlparse

from cadis_map_render.admission import admit_scene_package
from cadis_map_render.render import render_map


API_PROFILE = "cadis.map_render.api"
DEFAULT_WORLDWIDE_SCENE_ID = "world_8192"
REGIONAL_CROP_PADDING_RATIO = 0.05
REGIONAL_CROP_MIN_PADDING_DEGREES = 0.25
DEFAULT_REGION_CLAIM_LEVELS_BY_COUNTRY = {
    "AU": [6, 7],
    "CA": [5, 6, 8],
    "CN": [6, 5, 8],
    "GB": [6, 5, 8],
    "HK": [6, 5, 8],
    "US": [6, 5, 8],
}
DEFAULT_REGION_CLAIM_POLICY_BY_COUNTRY = {
    country_iso: {"claim_levels": levels}
    for country_iso, levels in DEFAULT_REGION_CLAIM_LEVELS_BY_COUNTRY.items()
}
for country_iso in ("AU", "CA", "CN", "US"):
    DEFAULT_REGION_CLAIM_POLICY_BY_COUNTRY[country_iso] = {
        "region_levels": [4],
        "claim_levels": list(DEFAULT_REGION_CLAIM_LEVELS_BY_COUNTRY[country_iso]),
    }


class CadisMapRenderApiError(ValueError):
    def __init__(self, code: str, message: str, *, status: HTTPStatus = HTTPStatus.BAD_REQUEST) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.status = status


@dataclass(frozen=True)
class CadisMapRenderServiceConfig:
    dataset_root: Path
    output_root: Path
    cache_root: Path | None = None
    api_token: str | None = None
    admission_mode: str = "trusted"
    export_psd: bool = False
    render_profile: bool = False


@dataclass(frozen=True)
class SceneRecord:
    scene_id: str
    scene_version: str
    scene_manifest: Path
    scene_package: Path
    label: str | None
    bounds: list[float] | None = None
    projection: str | None = None
    width: int | None = None
    height: int | None = None

    def to_summary(self) -> dict[str, Any]:
        summary = {
            "scene_id": _public_scene_id(self.scene_id),
            "scene_version": self.scene_version,
            "label": self.label,
        }
        if self.bounds is not None:
            summary["bounds"] = list(self.bounds)
        if self.projection is not None:
            summary["projection"] = self.projection
        if self.width is not None:
            summary["width"] = self.width
        if self.height is not None:
            summary["height"] = self.height
        return summary


@dataclass(frozen=True)
class SceneResolution:
    scene: SceneRecord
    crop_bounds: list[float] | None = None


class CadisMapRenderService:
    def __init__(self, config: CadisMapRenderServiceConfig) -> None:
        self.config = config

    def health(self) -> dict[str, Any]:
        return {
            "status": "ok",
            "profile": API_PROFILE,
        }

    def list_scenes(self) -> list[dict[str, Any]]:
        return [scene.to_summary() for scene in self._discover_scenes()]

    def list_place_names(self, scene_id: str) -> dict[str, Any]:
        scene = self._scene_by_id(scene_id)
        return {
            "scene_id": _public_scene_id(scene.scene_id),
            "scene_version": scene.scene_version,
            "places": _place_index_entries(_load_place_index(scene)),
        }

    def list_styles(self) -> list[dict[str, Any]]:
        styles_by_id: dict[str, dict[str, Any]] = {}
        for scene in self._discover_scenes():
            manifest_path = scene.scene_package / "styles" / "style_manifest.json"
            if not manifest_path.exists():
                continue
            manifest = _read_json_object(manifest_path, "style_manifest")
            styles = manifest.get("styles")
            if not isinstance(styles, list):
                continue
            for row in styles:
                if not isinstance(row, dict):
                    continue
                style_id = str(row.get("style_id") or "").strip()
                if not style_id:
                    continue
                styles_by_id.setdefault(
                    style_id,
                    {
                        "style_id": style_id,
                        "description": row.get("description"),
                    },
                )
        return sorted(styles_by_id.values(), key=lambda item: str(item["style_id"]))

    def render_map_request(self, payload: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(payload, dict):
            raise CadisMapRenderApiError("invalid_request", "render request must be a JSON object")

        _reject_client_paths(payload)
        places = _request_places(payload)
        selected_regions = _request_selected_regions(payload)
        selected_places = _request_selected_places(payload)
        if not places and not selected_regions and not selected_places:
            raise CadisMapRenderApiError(
                "missing_render_input",
                "render request must include points, selected_regions, or selected_places",
            )
        style_id = _optional_string(payload.get("style_id")) or "puzzle-pale"
        scene_policy = _optional_string(payload.get("scene_policy")) or "auto"
        scene_id = _optional_string(payload.get("scene_id"))
        export_psd = _request_export_psd(payload, default=self.config.export_psd)
        render_profile = _optional_bool(
            payload.get("render_profile"),
            default=self.config.render_profile,
            label="render_profile",
        )
        requested_crop_bounds = _request_crop_bounds(payload)
        resolution = self._resolve_scene(scene_id=scene_id, scene_policy=scene_policy, places=places)
        scene = resolution.scene
        if selected_places:
            selected_regions.extend(_resolve_selected_places(scene, selected_places))
        activation_policy = _request_activation_policy(payload)
        if activation_policy is None:
            activation_policy = _default_activation_policy_for_scene(scene)
        crop_bounds = requested_crop_bounds if requested_crop_bounds is not None else resolution.crop_bounds
        if crop_bounds is None and requested_crop_bounds is None:
            crop_bounds = self._point_aware_single_country_crop_bounds(scene=scene, places=places)

        render_id = _new_render_id()
        render_root = self.config.output_root / "renders" / render_id
        render_root.mkdir(parents=True, exist_ok=False)

        request_json = render_root / "request.json"
        request_payload = {
            "map_style": style_id,
            "places": places,
        }
        if selected_regions:
            request_payload["selected_regions"] = selected_regions
        if activation_policy is not None:
            request_payload["activation_policy"] = activation_policy
        if crop_bounds is not None:
            request_payload["crop_bounds"] = crop_bounds
        request_json.write_text(
            json.dumps(request_payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )

        scene_root = self._runtime_scene_root(scene, render_root)
        style_manifest = scene_root / "styles" / "style_manifest.json"
        output_png = render_root / "map.png"
        trace_dir = render_root / "render_trace" if export_psd else None
        report = render_map(
            scene_manifest=scene_root / "scene_manifest.json",
            request_json=request_json,
            style_profile=None,
            style_manifest=style_manifest if style_manifest.exists() else None,
            output_png=output_png,
            trace_dir=trace_dir,
            profiling=render_profile,
        )
        if export_psd:
            report |= self._export_psd(render_root=render_root, report=report)
        _write_json(render_root / "report.json", report)

        response = _compact_render_response(
            render_id=render_id,
            requested_style_id=style_id,
            requested_scene_id=scene_id or "auto",
            scene_policy=scene_policy,
            report=report,
        )
        _write_json(render_root / "result.json", response)
        return response

    def _export_psd(self, *, render_root: Path, report: dict[str, Any]) -> dict[str, Any]:
        trace_manifest = report.get("trace_manifest")
        if not isinstance(trace_manifest, str) or not trace_manifest:
            raise CadisMapRenderApiError(
                "missing_render_trace",
                "PSD export requires render trace output",
                status=HTTPStatus.INTERNAL_SERVER_ERROR,
            )
        output_psd = render_root / "map.psd"
        export_report_path = render_root / "psd_export_report.json"
        try:
            from cadis_map_exporter import export_trace_to_psd
        except Exception as exc:
            raise CadisMapRenderApiError(
                "psd_export_unavailable",
                f"PSD export is unavailable: {exc}",
                status=HTTPStatus.INTERNAL_SERVER_ERROR,
            ) from exc
        report_payload = export_trace_to_psd(
            trace_manifest,
            output_psd,
            include_final="top",
        )
        _write_json(export_report_path, report_payload)
        if report_payload.get("status") != "ok":
            raise CadisMapRenderApiError(
                "psd_export_failed",
                "PSD export failed",
                status=HTTPStatus.INTERNAL_SERVER_ERROR,
            )
        return {
            "psd_output": str(output_psd),
            "psd_export_report": str(export_report_path),
            "psd_export_status": "ok",
        }

    def _runtime_scene_root(self, scene: SceneRecord, render_root: Path) -> Path:
        if self.config.admission_mode == "trusted":
            return scene.scene_package
        if self.config.admission_mode != "copy":
            raise CadisMapRenderApiError(
                "unsupported_admission_mode",
                f"unsupported admission mode: {self.config.admission_mode!r}",
                status=HTTPStatus.INTERNAL_SERVER_ERROR,
            )
        if self.config.cache_root is None:
            raise CadisMapRenderApiError(
                "missing_cache_root",
                "admission mode copy requires cache_root",
                status=HTTPStatus.INTERNAL_SERVER_ERROR,
            )
        admission = admit_scene_package(scene.scene_package, self.config.cache_root / "admitted")
        if admission.get("status") != "ok":
            _write_json(render_root / "admission.json", admission)
            raise CadisMapRenderApiError(
                "scene_admission_failed",
                f"scene package failed admission: {scene.scene_id}",
                status=HTTPStatus.INTERNAL_SERVER_ERROR,
            )
        return Path(str(admission["cache_path"]))

    def render_result(self, render_id: str) -> dict[str, Any]:
        return _read_render_json(self._render_root(render_id) / "result.json")

    def render_report(self, render_id: str) -> dict[str, Any]:
        return _read_render_json(self._render_root(render_id) / "report.json")

    def render_image(self, render_id: str) -> bytes:
        path = self._render_root(render_id) / "map.png"
        if not path.exists():
            raise CadisMapRenderApiError("render_image_not_found", "render image was not found", status=HTTPStatus.NOT_FOUND)
        return path.read_bytes()

    def render_psd(self, render_id: str) -> bytes:
        path = self._render_root(render_id) / "map.psd"
        if not path.exists():
            raise CadisMapRenderApiError("render_psd_not_found", "render PSD was not found", status=HTTPStatus.NOT_FOUND)
        return path.read_bytes()

    def _resolve_scene(self, *, scene_id: str | None, scene_policy: str, places: list[dict[str, Any]]) -> SceneResolution:
        scenes = self._discover_scenes()
        if scene_id:
            scene = self._scene_by_id(scene_id, scenes=scenes)
            return SceneResolution(scene=scene, crop_bounds=self._default_crop_bounds(scene=scene, scenes=scenes, places=places))
        if scene_policy not in {"auto", "single-country", "country", "regional-scene", "region", "worldwide", "world"}:
            raise CadisMapRenderApiError(
                "unsupported_scene_policy",
                f"unsupported scene_policy: {scene_policy!r}",
            )
        if not scenes:
            raise CadisMapRenderApiError(
                "no_scenes",
                "dataset root does not contain any scene_manifest.json files",
                status=HTTPStatus.INTERNAL_SERVER_ERROR,
            )
        countries = _request_country_iso_values(places)
        if scene_policy in {"single-country", "country"}:
            scene = self._select_single_country_scene(scenes=scenes, countries=countries)
            return SceneResolution(scene=scene)
        if scene_policy in {"worldwide", "world"}:
            return SceneResolution(scene=self._select_worldwide_scene(scenes))
        if scene_policy in {"regional-scene", "region"}:
            scene = self._select_regional_scene(scenes=scenes, countries=countries)
            return SceneResolution(scene=scene, crop_bounds=self._default_crop_bounds(scene=scene, scenes=scenes, places=places))
        if len(scenes) == 1:
            scene = scenes[0]
            return SceneResolution(scene=scene, crop_bounds=self._default_crop_bounds(scene=scene, scenes=scenes, places=places))
        if len(countries) == 1:
            country_scene = self._single_country_scene_by_iso(scenes).get(countries[0])
            if country_scene is not None:
                return SceneResolution(scene=country_scene)
        if len(countries) > 1:
            regional_scene = self._best_regional_scene(scenes=scenes, countries=countries)
            if regional_scene is not None:
                return SceneResolution(
                    scene=regional_scene,
                    crop_bounds=self._default_crop_bounds(scene=regional_scene, scenes=scenes, places=places),
                )
            worldwide_scene = self._best_worldwide_scene(scenes)
            if worldwide_scene is not None:
                return SceneResolution(scene=worldwide_scene)
        raise CadisMapRenderApiError(
            "ambiguous_scene_policy",
            "scene_policy auto could not infer a scene; provide scene_id or point country_iso values",
        )

    def _scene_by_id(self, scene_id: str, *, scenes: list[SceneRecord] | None = None) -> SceneRecord:
        for scene in scenes if scenes is not None else self._discover_scenes():
            if _scene_id_matches(scene.scene_id, scene_id):
                return scene
        raise CadisMapRenderApiError("unknown_scene_id", f"unknown scene_id: {scene_id!r}", status=HTTPStatus.NOT_FOUND)

    def _select_single_country_scene(self, *, scenes: list[SceneRecord], countries: list[str]) -> SceneRecord:
        if len(countries) != 1:
            raise CadisMapRenderApiError(
                "single_country_scene_requires_country",
                "scene_policy single-country requires points from exactly one country_iso",
            )
        scene = self._single_country_scene_by_iso(scenes).get(countries[0])
        if scene is None:
            raise CadisMapRenderApiError(
                "single_country_scene_not_found",
                f"no single-country scene found for country_iso {countries[0]!r}",
                status=HTTPStatus.NOT_FOUND,
            )
        return scene

    def _select_regional_scene(self, *, scenes: list[SceneRecord], countries: list[str]) -> SceneRecord:
        if not countries:
            raise CadisMapRenderApiError(
                "regional_scene_requires_countries",
                "scene_policy regional-scene requires point country_iso values",
            )
        scene = self._best_regional_scene(scenes=scenes, countries=countries)
        if scene is None:
            raise CadisMapRenderApiError(
                "regional_scene_not_found",
                f"no regional scene covers countries: {', '.join(countries)}",
                status=HTTPStatus.NOT_FOUND,
            )
        return scene

    def _select_worldwide_scene(self, scenes: list[SceneRecord]) -> SceneRecord:
        scene = self._best_worldwide_scene(scenes)
        if scene is None:
            raise CadisMapRenderApiError(
                "worldwide_scene_not_found",
                "dataset root does not contain a worldwide scene",
                status=HTTPStatus.NOT_FOUND,
            )
        return scene

    def _best_regional_scene(self, *, scenes: list[SceneRecord], countries: list[str]) -> SceneRecord | None:
        required = set(countries)
        candidates: list[tuple[float, str, SceneRecord]] = []
        for scene in scenes:
            if not _is_regional_country_scoped_scene(scene):
                continue
            manifest = _read_json_object(scene.scene_manifest, "scene_manifest")
            selectable = _country_iso_list(manifest.get("selectable_countries"))
            if required.issubset(set(selectable)):
                bounds = _manifest_bounds(manifest) or [-180.0, -60.0, 180.0, 85.0]
                candidates.append((_bounds_area(bounds), scene.scene_id, scene))
        if not candidates:
            return None
        return sorted(candidates, key=lambda row: (row[0], row[1]))[0][2]

    def _best_worldwide_scene(self, scenes: list[SceneRecord]) -> SceneRecord | None:
        by_id = {scene.scene_id: scene for scene in scenes}
        if DEFAULT_WORLDWIDE_SCENE_ID in by_id:
            return by_id[DEFAULT_WORLDWIDE_SCENE_ID]
        worldwide = [scene for scene in scenes if scene.scene_id.startswith("world_")]
        if not worldwide:
            return None
        return sorted(worldwide, key=lambda scene: scene.scene_id)[-1]

    def _single_country_scene_by_iso(self, scenes: list[SceneRecord]) -> dict[str, SceneRecord]:
        result: dict[str, SceneRecord] = {}
        for scene in scenes:
            country_iso = _scene_country_iso(scene)
            if country_iso is not None:
                result.setdefault(country_iso, scene)
        return result

    def _default_crop_bounds(
        self,
        *,
        scene: SceneRecord,
        scenes: list[SceneRecord],
        places: list[dict[str, Any]],
    ) -> list[float] | None:
        if not _is_regional_country_scoped_scene(scene):
            return None
        countries = _request_country_iso_values(places)
        if not countries:
            return None
        scene_manifest = _read_json_object(scene.scene_manifest, "scene_manifest")
        scene_bounds = _manifest_bounds(scene_manifest)
        if scene_bounds is None:
            return None
        country_bounds_by_iso = self._country_bounds_by_iso(scenes)
        country_bounds = [country_bounds_by_iso[country] for country in countries if country in country_bounds_by_iso]
        if len(country_bounds) != len(countries):
            return None
        return _clamp_bounds(_padded_bounds(_union_bounds(country_bounds)), scene_bounds)

    def _point_aware_single_country_crop_bounds(
        self,
        *,
        scene: SceneRecord,
        places: list[dict[str, Any]],
    ) -> list[float] | None:
        if _scene_country_iso(scene) != "US":
            return None
        manifest = _read_json_object(scene.scene_manifest, "scene_manifest")
        scene_bounds = _manifest_bounds(manifest)
        default_crop_bounds = _default_scene_crop_policy_bounds(manifest)
        if scene_bounds is None or default_crop_bounds is None:
            return None
        if all(_point_in_bounds(float(place["lon"]), float(place["lat"]), default_crop_bounds) for place in places):
            return None
        if not all(_point_in_bounds(float(place["lon"]), float(place["lat"]), scene_bounds) for place in places):
            return None
        return scene_bounds

    def _country_bounds_by_iso(self, scenes: list[SceneRecord]) -> dict[str, list[float]]:
        result: dict[str, list[float]] = {}
        for scene in scenes:
            country_iso = _scene_country_iso(scene)
            if country_iso is None:
                continue
            manifest = _read_json_object(scene.scene_manifest, "scene_manifest")
            bounds = _manifest_bounds(manifest)
            if bounds is not None:
                result.setdefault(country_iso, bounds)
        return result

    def _discover_scenes(self) -> list[SceneRecord]:
        root = self.config.dataset_root
        if not root.exists():
            raise CadisMapRenderApiError(
                "dataset_root_not_found",
                f"dataset root does not exist: {root}",
                status=HTTPStatus.INTERNAL_SERVER_ERROR,
            )
        records: list[SceneRecord] = []
        for manifest_path in sorted(root.rglob("scene_manifest.json")):
            manifest = _read_json_object(manifest_path, "scene_manifest")
            scene_id = str(manifest.get("scene_id") or "").strip()
            scene_version = str(manifest.get("scene_version") or "").strip()
            if not scene_id or not scene_version:
                continue
            label = manifest.get("label")
            records.append(
                SceneRecord(
                    scene_id=scene_id,
                    scene_version=scene_version,
                    scene_manifest=manifest_path,
                    scene_package=manifest_path.parent,
                    label=str(label) if label is not None else None,
                    bounds=_manifest_bounds(manifest),
                    projection=_optional_string(manifest.get("projection")),
                    width=_optional_positive_int(manifest.get("width")),
                    height=_optional_positive_int(manifest.get("height")),
                )
            )
        return records

    def _render_root(self, render_id: str) -> Path:
        if not _safe_id(render_id):
            raise CadisMapRenderApiError("invalid_render_id", "render_id is invalid")
        root = self.config.output_root / "renders" / render_id
        if not root.is_dir():
            raise CadisMapRenderApiError("render_not_found", "render was not found", status=HTTPStatus.NOT_FOUND)
        return root


def serve(service: CadisMapRenderService, *, host: str, port: int) -> None:
    handler_cls = _handler_class(service)
    server = ThreadingHTTPServer((host, port), handler_cls)
    server.serve_forever()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run the Cadis Map Render API server.")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--dataset-root", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--cache-root", type=Path)
    parser.add_argument(
        "--admission-mode",
        choices=("trusted", "copy"),
        default="trusted",
        help="Use trusted to render directly from the read-only dataset, or copy to admit scenes into cache first.",
    )
    parser.add_argument(
        "--api-token-env",
        default="CADIS_MAP_RENDER_API_TOKEN",
        help="Environment variable containing the bearer token required for /v1 API requests.",
    )
    parser.add_argument(
        "--api-token-file-env",
        default="CADIS_MAP_RENDER_API_TOKEN_FILE",
        help="Environment variable containing a path to a bearer token file for /v1 API requests.",
    )
    parser.add_argument(
        "--export-psd-env",
        default="CADIS_MAP_RENDER_EXPORT_PSD",
        help="Environment variable controlling post-render PSD export. Defaults to disabled.",
    )
    parser.add_argument(
        "--render-profile-env",
        default="CADIS_MAP_RENDER_PROFILE",
        help="Environment variable controlling render phase profiling. Defaults to disabled.",
    )
    args = parser.parse_args(argv)
    api_token = _optional_env_token(args.api_token_env, args.api_token_file_env)
    export_psd = _env_bool(args.export_psd_env, default=False)
    render_profile = _env_bool(args.render_profile_env, default=False)
    service = CadisMapRenderService(
        CadisMapRenderServiceConfig(
            dataset_root=args.dataset_root,
            output_root=args.output_root,
            cache_root=args.cache_root,
            api_token=api_token,
            admission_mode=args.admission_mode,
            export_psd=export_psd,
            render_profile=render_profile,
        )
    )
    serve(service, host=str(args.host), port=int(args.port))
    return 0


def _handler_class(service: CadisMapRenderService) -> type[BaseHTTPRequestHandler]:
    class CadisMapRenderHandler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:  # noqa: N802 - stdlib handler name
            path = urlparse(self.path).path
            try:
                if path == "/health":
                    self._send_json(HTTPStatus.OK, service.health())
                    return
                if not self._authorize_request():
                    return
                if path == "/v1/scenes":
                    self._send_json(HTTPStatus.OK, {"scenes": service.list_scenes()})
                    return
                if path == "/v1/styles":
                    self._send_json(HTTPStatus.OK, {"styles": service.list_styles()})
                    return
                scene_id = _scene_places_route(path)
                if scene_id is not None:
                    self._send_json(HTTPStatus.OK, service.list_place_names(scene_id))
                    return
                render_id, suffix = _render_route(path)
                if render_id is not None and suffix == "":
                    self._send_json(HTTPStatus.OK, service.render_result(render_id))
                    return
                if render_id is not None and suffix == "report":
                    self._send_json(HTTPStatus.OK, service.render_report(render_id))
                    return
                if render_id is not None and suffix == "image":
                    self._send_bytes(HTTPStatus.OK, service.render_image(render_id), content_type="image/png")
                    return
                if render_id is not None and suffix == "psd":
                    self._send_bytes(HTTPStatus.OK, service.render_psd(render_id), content_type="application/octet-stream")
                    return
                self._send_json(HTTPStatus.NOT_FOUND, {"ok": False, "error": "not_found"})
            except CadisMapRenderApiError as exc:
                self._send_json(exc.status, {"ok": False, "code": exc.code, "error": exc.message})

        def do_POST(self) -> None:  # noqa: N802 - stdlib handler name
            path = urlparse(self.path).path
            if path != "/v1/render_map":
                self._send_json(HTTPStatus.NOT_FOUND, {"ok": False, "error": "not_found"})
                return
            if not self._authorize_request():
                return
            try:
                payload = self._read_json_body()
                self._send_json(HTTPStatus.OK, service.render_map_request(payload))
            except json.JSONDecodeError:
                self._send_json(HTTPStatus.BAD_REQUEST, {"ok": False, "code": "invalid_json", "error": "request body must be JSON"})
            except CadisMapRenderApiError as exc:
                self._send_json(exc.status, {"ok": False, "code": exc.code, "error": exc.message})

        def log_message(self, format: str, *args: Any) -> None:
            return

        def _read_json_body(self) -> dict[str, Any]:
            length = int(self.headers.get("Content-Length", "0") or "0")
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
            if not isinstance(payload, dict):
                raise CadisMapRenderApiError("invalid_request", "request body must be a JSON object")
            return payload

        def _authorize_request(self) -> bool:
            expected = service.config.api_token
            if expected is None:
                return True
            authorization = self.headers.get("Authorization", "")
            prefix = "Bearer "
            if authorization.startswith(prefix) and hmac.compare_digest(authorization[len(prefix):], expected):
                return True
            self.send_response(int(HTTPStatus.UNAUTHORIZED))
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("WWW-Authenticate", 'Bearer realm="cadis-map-render"')
            body = b'{"code":"unauthorized","error":"valid bearer token required","ok":false}'
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return False

        def _send_json(self, status: HTTPStatus, payload: dict[str, Any]) -> None:
            body = json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")
            self._send_bytes(status, body, content_type="application/json; charset=utf-8")

        def _send_bytes(self, status: HTTPStatus, body: bytes, *, content_type: str) -> None:
            self.send_response(int(status))
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

    return CadisMapRenderHandler


def _request_places(payload: dict[str, Any]) -> list[dict[str, Any]]:
    raw = payload.get("points")
    if raw is None:
        raw = payload.get("places")
    if raw is None:
        return []
    if not isinstance(raw, list):
        raise CadisMapRenderApiError("invalid_points", "points must be an array")
    places: list[dict[str, Any]] = []
    for index, row in enumerate(raw):
        if not isinstance(row, dict):
            raise CadisMapRenderApiError("invalid_point", f"points[{index}] must be an object")
        lat = row.get("lat")
        lon = row.get("lon")
        if not isinstance(lat, int | float) or not isinstance(lon, int | float):
            raise CadisMapRenderApiError("invalid_point", f"points[{index}] requires numeric lat and lon")
        point: dict[str, Any] = {
            "lat": float(lat),
            "lon": float(lon),
        }
        for key in ("label", "density", "country_iso"):
            if key in row:
                point[key] = row[key]
        places.append(point)
    return places


def _request_selected_regions(payload: dict[str, Any]) -> list[dict[str, Any]]:
    raw = payload.get("selected_regions")
    if raw is None:
        return []
    if not isinstance(raw, list):
        raise CadisMapRenderApiError("invalid_selected_regions", "selected_regions must be an array")
    selected: list[dict[str, Any]] = []
    for index, row in enumerate(raw):
        if not isinstance(row, dict):
            raise CadisMapRenderApiError("invalid_selected_region", f"selected_regions[{index}] must be an object")
        semantic_id = row.get("semantic_id")
        density = row.get("density", row.get("weight", 1))
        if isinstance(semantic_id, bool) or not isinstance(semantic_id, int) or semantic_id <= 0:
            raise CadisMapRenderApiError("invalid_selected_region", f"selected_regions[{index}].semantic_id must be a positive integer")
        if not _is_positive_number(density):
            raise CadisMapRenderApiError("invalid_selected_region", f"selected_regions[{index}].density must be a positive number")
        selected.append({"semantic_id": int(semantic_id), "density": _normalize_number(density)})
    return selected


def _request_selected_places(payload: dict[str, Any]) -> list[dict[str, Any]]:
    raw = payload.get("selected_places")
    if raw is None:
        return []
    if not isinstance(raw, list):
        raise CadisMapRenderApiError("invalid_selected_places", "selected_places must be an array")
    selected: list[dict[str, Any]] = []
    for index, row in enumerate(raw):
        if not isinstance(row, dict):
            raise CadisMapRenderApiError("invalid_selected_place", f"selected_places[{index}] must be an object")
        place_name = row.get("place_name", row.get("name"))
        density = row.get("density", row.get("weight", 1))
        if not isinstance(place_name, str) or not place_name.strip():
            raise CadisMapRenderApiError(
                "invalid_selected_place",
                f"selected_places[{index}].place_name must be a non-empty string",
            )
        if not _is_positive_number(density):
            raise CadisMapRenderApiError(
                "invalid_selected_place",
                f"selected_places[{index}].density must be a positive number",
            )
        selected.append({"place_name": place_name.strip(), "density": _normalize_number(density)})
    return selected


def _resolve_selected_places(scene: SceneRecord, selected_places: list[dict[str, Any]]) -> list[dict[str, Any]]:
    place_index = _load_place_index(scene)
    lookup = _place_index_lookup(place_index)
    selected_regions: list[dict[str, Any]] = []
    for index, selected_place in enumerate(selected_places):
        key = _normalize_place_key(str(selected_place["place_name"]))
        entry = lookup.get(key)
        if entry is None:
            raise CadisMapRenderApiError(
                "unknown_selected_place",
                f"selected_places[{index}].place_name is not listed in scene place_index: {selected_place['place_name']!r}",
                status=HTTPStatus.NOT_FOUND,
            )
        semantic_id = entry.get("semantic_id")
        if isinstance(semantic_id, bool) or not isinstance(semantic_id, int) or semantic_id <= 0:
            raise CadisMapRenderApiError(
                "invalid_place_index",
                f"scene place_index entry has invalid semantic_id for {selected_place['place_name']!r}",
                status=HTTPStatus.INTERNAL_SERVER_ERROR,
            )
        selected_regions.append({"semantic_id": int(semantic_id), "density": selected_place["density"]})
    return selected_regions


def _load_place_index(scene: SceneRecord) -> dict[str, Any]:
    manifest = _read_json_object(scene.scene_manifest, "scene_manifest")
    design = manifest.get("design_facing")
    if not isinstance(design, dict):
        raise CadisMapRenderApiError(
            "invalid_scene_manifest",
            "scene manifest design_facing must be an object",
            status=HTTPStatus.INTERNAL_SERVER_ERROR,
        )
    asset = design.get("place_index")
    if not isinstance(asset, dict):
        raise CadisMapRenderApiError(
            "place_index_not_found",
            "selected_places requires scene design_facing.place_index",
            status=HTTPStatus.NOT_FOUND,
        )
    place_index_path = _resolve_design_asset_path(scene.scene_package, manifest, asset, "place_index")
    try:
        payload = _read_json_object(place_index_path, "place_index")
    except OSError as exc:
        raise CadisMapRenderApiError(
            "place_index_not_found",
            f"scene place_index was not found: {place_index_path}",
            status=HTTPStatus.NOT_FOUND,
        ) from exc
    if payload.get("profile") != "cadis.map_render.place_index":
        raise CadisMapRenderApiError(
            "invalid_place_index",
            "scene place_index profile is unsupported",
            status=HTTPStatus.INTERNAL_SERVER_ERROR,
        )
    return payload


def _place_index_lookup(place_index: dict[str, Any]) -> dict[str, dict[str, Any]]:
    places = place_index.get("places")
    if not isinstance(places, dict):
        raise CadisMapRenderApiError(
            "invalid_place_index",
            "scene place_index must contain places object",
            status=HTTPStatus.INTERNAL_SERVER_ERROR,
        )
    lookup: dict[str, dict[str, Any]] = {}
    for key, raw_entry in places.items():
        if not isinstance(raw_entry, dict):
            continue
        for name in (key, raw_entry.get("label"), *(_place_aliases(raw_entry.get("aliases")))):
            if isinstance(name, str) and name.strip():
                lookup.setdefault(_normalize_place_key(name), raw_entry)
    return lookup


def _place_index_entries(place_index: dict[str, Any]) -> list[dict[str, Any]]:
    places = place_index.get("places")
    if not isinstance(places, dict):
        raise CadisMapRenderApiError(
            "invalid_place_index",
            "scene place_index must contain places object",
            status=HTTPStatus.INTERNAL_SERVER_ERROR,
        )
    entries: list[dict[str, Any]] = []
    for key, raw_entry in places.items():
        if not isinstance(raw_entry, dict):
            continue
        place_name = raw_entry.get("label") if isinstance(raw_entry.get("label"), str) else str(key)
        entry = {
            "key": str(key),
            "place_name": place_name,
        }
        for field in ("semantic_id", "feature_id", "country_iso", "level", "label", "source_name", "names"):
            if field in raw_entry:
                entry[field] = raw_entry[field]
        aliases = _place_aliases(raw_entry.get("aliases"))
        if aliases:
            entry["aliases"] = aliases
        entries.append(entry)
    return sorted(entries, key=lambda item: (str(item["place_name"]).casefold(), str(item["key"]).casefold()))


def _place_aliases(value: object) -> list[str]:
    if not isinstance(value, list):
        return []
    return [item for item in value if isinstance(item, str)]


def _normalize_place_key(value: str) -> str:
    return " ".join(value.strip().casefold().replace("_", " ").split())


def _resolve_design_asset_path(package_dir: Path, scene: dict[str, Any], asset: dict[str, Any], label: str) -> Path:
    roots = {
        "scene": package_dir,
        "core": package_dir,
        "presentation": package_dir,
    }
    split = scene.get("package_split")
    if isinstance(split, dict):
        for role, key in (("core", "core_root"), ("presentation", "presentation_root")):
            raw_root = split.get(key)
            if isinstance(raw_root, str) and raw_root:
                roots[role] = _resolve_relative_package_path(package_dir, raw_root, f"package_split.{key}")
    raw_package = asset.get("package", "scene")
    if raw_package not in roots:
        raise CadisMapRenderApiError(
            "invalid_scene_manifest",
            f"scene {label}.package must be scene, core, or presentation",
            status=HTTPStatus.INTERNAL_SERVER_ERROR,
        )
    raw_path = asset.get("path")
    if not isinstance(raw_path, str) or not raw_path:
        raise CadisMapRenderApiError(
            "invalid_scene_manifest",
            f"scene {label}.path is required",
            status=HTTPStatus.INTERNAL_SERVER_ERROR,
        )
    return _resolve_relative_package_path(roots[str(raw_package)], raw_path, f"{label}.path")


def _resolve_relative_package_path(root: Path, raw_path: str, label: str) -> Path:
    path = Path(raw_path)
    if path.is_absolute() or ".." in path.parts:
        raise CadisMapRenderApiError(
            "invalid_scene_manifest",
            f"scene {label} must be package-relative",
            status=HTTPStatus.INTERNAL_SERVER_ERROR,
        )
    return root / path


def _is_positive_number(value: Any) -> bool:
    return not isinstance(value, bool) and isinstance(value, (int, float)) and math.isfinite(float(value)) and float(value) > 0


def _normalize_number(value: int | float) -> int | float:
    return int(value) if isinstance(value, int) else float(value)


def _request_export_psd(payload: dict[str, Any], *, default: bool) -> bool:
    value = _optional_bool(payload.get("export_psd"), default=default, label="export_psd")
    if value and not default:
        raise CadisMapRenderApiError(
            "psd_export_disabled",
            "export_psd=true requires PSD export to be enabled on the server",
        )
    return value


def _request_activation_policy(payload: dict[str, Any]) -> dict[str, Any] | None:
    if "activation_policy" not in payload:
        return None
    raw = payload.get("activation_policy")
    if not isinstance(raw, dict):
        raise CadisMapRenderApiError("invalid_activation_policy", "activation_policy must be an object")
    if raw.get("mode") != "region_claim":
        return None

    claim_levels = _clean_level_list(raw.get("claim_levels"))
    region_levels = _clean_level_list(raw.get("region_levels"))
    admin_region_levels = _clean_level_list(raw.get("admin_region_levels"))
    country_activation = raw.get("country_activation") is True
    if not claim_levels and not region_levels and not admin_region_levels and not country_activation:
        return None

    policy: dict[str, Any] = {
        "mode": "region_claim",
    }
    if country_activation:
        policy["country_activation"] = True
    if admin_region_levels:
        policy["admin_region_levels"] = admin_region_levels
    if region_levels:
        policy["region_levels"] = region_levels
    if claim_levels:
        policy["claim_levels"] = claim_levels
    return policy


def _request_crop_bounds(payload: dict[str, Any]) -> list[float] | None:
    if "crop_bounds" not in payload:
        return None
    value = payload.get("crop_bounds")
    if not isinstance(value, list) or len(value) != 4:
        raise CadisMapRenderApiError(
            "invalid_crop_bounds",
            "crop_bounds must be a [min_lon, min_lat, max_lon, max_lat] array",
        )
    bounds: list[float] = []
    for index, item in enumerate(value):
        if isinstance(item, bool) or not isinstance(item, int | float):
            raise CadisMapRenderApiError("invalid_crop_bounds", f"crop_bounds[{index}] must be numeric")
        bounds.append(float(item))
    min_lon, min_lat, max_lon, max_lat = bounds
    if min_lon >= max_lon or min_lat >= max_lat:
        raise CadisMapRenderApiError("invalid_crop_bounds", "crop_bounds must have increasing longitude and latitude bounds")
    return bounds


def _default_activation_policy_for_scene(scene: SceneRecord) -> dict[str, Any] | None:
    country_iso = _scene_country_iso(scene)
    policy = DEFAULT_REGION_CLAIM_POLICY_BY_COUNTRY.get(country_iso)
    if policy is None:
        if _is_regional_country_scoped_scene(scene):
            result = {
                "mode": "region_claim",
                "country_activation": True,
            }
            admin_region_levels = _regional_default_admin_region_levels(scene)
            if admin_region_levels:
                result["admin_region_levels"] = admin_region_levels
            return result
        return None
    result: dict[str, Any] = {"mode": "region_claim"}
    if "region_levels" in policy:
        result["region_levels"] = list(policy["region_levels"])
    if "claim_levels" in policy:
        result["claim_levels"] = list(policy["claim_levels"])
    return result


def _is_regional_country_scoped_scene(scene: SceneRecord) -> bool:
    manifest = _read_json_object(scene.scene_manifest, "scene_manifest")
    scene_id = scene.scene_id.strip().lower()
    if scene_id.startswith("world_"):
        return False
    selectable = manifest.get("selectable_countries")
    if not isinstance(selectable, list) or len(selectable) <= 1:
        return False
    design = manifest.get("design_facing")
    semantic_sidecar = design.get("semantic_sidecar") if isinstance(design, dict) else None
    if isinstance(semantic_sidecar, dict) and semantic_sidecar.get("semantic_sidecar_scope") == "country":
        return True
    renderer = manifest.get("cadis_internal", {}).get("renderer", {})
    if isinstance(renderer, dict) and renderer.get("semantic_sidecar_scope") == "country":
        return True
    return False


def _regional_default_admin_region_levels(scene: SceneRecord) -> list[int]:
    manifest = _read_json_object(scene.scene_manifest, "scene_manifest")
    design = manifest.get("design_facing")
    claim_sidecars = design.get("claim_semantic_sidecars") if isinstance(design, dict) else None
    if not isinstance(claim_sidecars, dict):
        return []
    return [4] if isinstance(claim_sidecars.get("4"), dict) else []


def _request_country_iso_values(places: list[dict[str, Any]]) -> list[str]:
    countries: list[str] = []
    for place in places:
        raw = place.get("country_iso")
        if not isinstance(raw, str):
            continue
        country_iso = raw.strip().upper()
        if len(country_iso) != 2 or not country_iso.isalpha():
            continue
        if country_iso not in countries:
            countries.append(country_iso)
    return countries


def _country_iso_list(value: object) -> list[str]:
    if not isinstance(value, list):
        return []
    countries: list[str] = []
    for item in value:
        if not isinstance(item, str):
            continue
        country_iso = item.strip().upper()
        if len(country_iso) == 2 and country_iso.isalpha() and country_iso not in countries:
            countries.append(country_iso)
    return countries


def _manifest_bounds(manifest: dict[str, Any]) -> list[float] | None:
    value = manifest.get("bounds")
    if not isinstance(value, list) or len(value) != 4:
        return None
    bounds: list[float] = []
    for item in value:
        if isinstance(item, bool) or not isinstance(item, int | float):
            return None
        bounds.append(float(item))
    min_lon, min_lat, max_lon, max_lat = bounds
    if min_lon >= max_lon or min_lat >= max_lat:
        return None
    return bounds


def _bounds_area(bounds: list[float]) -> float:
    return max(0.0, bounds[2] - bounds[0]) * max(0.0, bounds[3] - bounds[1])


def _default_scene_crop_policy_bounds(manifest: dict[str, Any]) -> list[float] | None:
    crop_policy = manifest.get("crop_policy")
    if not isinstance(crop_policy, dict):
        return None
    profiles = crop_policy.get("truncate_bounds_profiles")
    profile = crop_policy.get("default_truncate_bounds_profile")
    if isinstance(profile, str) and isinstance(profiles, dict) and profile in profiles:
        return _valid_bounds(profiles[profile])
    return _valid_bounds(crop_policy.get("truncate_bounds"))


def _valid_bounds(value: object) -> list[float] | None:
    if not isinstance(value, list) or len(value) != 4:
        return None
    bounds: list[float] = []
    for item in value:
        if isinstance(item, bool) or not isinstance(item, int | float):
            return None
        bounds.append(float(item))
    min_lon, min_lat, max_lon, max_lat = bounds
    if min_lon >= max_lon or min_lat >= max_lat:
        return None
    return bounds


def _point_in_bounds(lon: float, lat: float, bounds: list[float]) -> bool:
    return bounds[0] <= lon <= bounds[2] and bounds[1] <= lat <= bounds[3]


def _union_bounds(bounds_list: list[list[float]]) -> list[float]:
    return [
        min(bounds[0] for bounds in bounds_list),
        min(bounds[1] for bounds in bounds_list),
        max(bounds[2] for bounds in bounds_list),
        max(bounds[3] for bounds in bounds_list),
    ]


def _padded_bounds(bounds: list[float]) -> list[float]:
    width = max(0.0, bounds[2] - bounds[0])
    height = max(0.0, bounds[3] - bounds[1])
    lon_pad = max(width * REGIONAL_CROP_PADDING_RATIO, REGIONAL_CROP_MIN_PADDING_DEGREES)
    lat_pad = max(height * REGIONAL_CROP_PADDING_RATIO, REGIONAL_CROP_MIN_PADDING_DEGREES)
    return [
        bounds[0] - lon_pad,
        bounds[1] - lat_pad,
        bounds[2] + lon_pad,
        bounds[3] + lat_pad,
    ]


def _clamp_bounds(bounds: list[float], containing_bounds: list[float]) -> list[float] | None:
    clamped = [
        max(containing_bounds[0], bounds[0]),
        max(containing_bounds[1], bounds[1]),
        min(containing_bounds[2], bounds[2]),
        min(containing_bounds[3], bounds[3]),
    ]
    if clamped[0] >= clamped[2] or clamped[1] >= clamped[3]:
        return None
    return clamped


def _clean_level_list(value: object) -> list[int]:
    if not isinstance(value, list):
        return []
    levels: list[int] = []
    for item in value:
        if isinstance(item, bool) or not isinstance(item, int) or item <= 0:
            continue
        if item not in levels:
            levels.append(item)
    return levels


def _scene_country_iso(scene: SceneRecord) -> str | None:
    manifest = _read_json_object(scene.scene_manifest, "scene_manifest")
    selectable = manifest.get("selectable_countries")
    if isinstance(selectable, list) and len(selectable) == 1:
        country_iso = str(selectable[0]).strip().upper()
        if country_iso:
            return country_iso
    scene_id = scene.scene_id.strip().lower()
    if scene_id.startswith("country_") and len(scene_id) == len("country_") + 2:
        return scene_id.removeprefix("country_").upper()
    if scene_id.startswith("iso2_") and len(scene_id) == len("iso2_") + 2:
        return scene_id.removeprefix("iso2_").upper()
    if _is_iso2_scene_id(scene_id):
        return scene_id.upper()
    return None


def _scene_id_matches(actual: str, requested: str) -> bool:
    return requested.strip().lower() in _scene_id_aliases(actual)


def _scene_id_aliases(scene_id: str) -> set[str]:
    normalized = scene_id.strip().lower()
    aliases = {scene_id, normalized}
    if _is_iso2_scene_id(normalized):
        aliases.update({f"iso2_{normalized}", f"country_{normalized}"})
    if normalized.startswith("country_") and len(normalized) == len("country_") + 2:
        iso2 = normalized.removeprefix("country_")
        aliases.update({iso2, f"iso2_{iso2}"})
    if normalized.startswith("iso2_") and len(normalized) == len("iso2_") + 2:
        iso2 = normalized.removeprefix("iso2_")
        aliases.update({iso2, f"country_{iso2}"})
    return aliases


def _public_scene_id(scene_id: object) -> object:
    if not isinstance(scene_id, str):
        return scene_id
    normalized = scene_id.strip().lower()
    if normalized.startswith("country_") and len(normalized) == len("country_") + 2:
        return normalized.removeprefix("country_")
    if normalized.startswith("iso2_") and len(normalized) == len("iso2_") + 2:
        return normalized.removeprefix("iso2_")
    return scene_id


def _is_iso2_scene_id(value: str) -> bool:
    return len(value) == 2 and value.isalpha()


def _optional_bool(value: Any, *, default: bool, label: str) -> bool:
    if value is None:
        return default
    if not isinstance(value, bool):
        raise CadisMapRenderApiError(f"invalid_{label}", f"{label} must be a boolean")
    return value


def _reject_client_paths(payload: dict[str, Any]) -> None:
    forbidden = {
        "cache_dir",
        "dataset_root",
        "map_dataset_root",
        "metadata_json",
        "output_png",
        "scene_manifest",
        "scene_package",
        "scene_package_path",
    }
    for key in sorted(forbidden):
        if key in payload:
            raise CadisMapRenderApiError(
                "client_path_not_allowed",
                f"render request must not include service-owned path field: {key}",
            )
    output = payload.get("output")
    if isinstance(output, dict):
        for key in ("path", "png", "metadata", "metadata_json"):
            if key in output:
                raise CadisMapRenderApiError(
                    "client_path_not_allowed",
                    f"render request output must not include service-owned path field: {key}",
                )


def _compact_render_response(
    *,
    render_id: str,
    requested_style_id: str,
    requested_scene_id: str,
    scene_policy: str,
    report: dict[str, Any],
) -> dict[str, Any]:
    return {
        "operation": "render",
        "render_type": "map",
        "render_id": render_id,
        "status": report.get("status"),
        "style_id": requested_style_id,
        "cadis_style_id": report.get("style_id"),
        "requested_scene_id": requested_scene_id,
        "scene_policy": scene_policy,
        "scene_id": _public_scene_id(report.get("scene_id")),
        "scene_version": report.get("scene_version"),
        "source_point_count": int(report.get("source_point_count") or 0),
        "located_point_count": int(report.get("located_point_count") or 0),
        "located_density_weight": report.get("located_density_weight") or 0,
        "activation_mode": report.get("activation_mode"),
        "image_url": f"/v1/renders/{render_id}/image",
        "report_url": f"/v1/renders/{render_id}/report",
        **({} if report.get("psd_export_status") != "ok" else {"psd_url": f"/v1/renders/{render_id}/psd"}),
    }


def _render_route(path: str) -> tuple[str | None, str | None]:
    prefix = "/v1/renders/"
    if not path.startswith(prefix):
        return None, None
    rest = path[len(prefix):].strip("/")
    if not rest:
        return None, None
    parts = rest.split("/")
    if len(parts) == 1:
        return parts[0], ""
    if len(parts) == 2 and parts[1] in {"image", "psd", "report"}:
        return parts[0], parts[1]
    return None, None


def _scene_places_route(path: str) -> str | None:
    prefix = "/v1/scenes/"
    suffix = "/places"
    if not path.startswith(prefix) or not path.endswith(suffix):
        return None
    scene_id = path[len(prefix):-len(suffix)].strip("/")
    if not scene_id or "/" in scene_id:
        return None
    return unquote(scene_id)


def _read_json_object(path: Path, label: str) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise CadisMapRenderApiError("invalid_json_asset", f"{label} must be a JSON object: {path}")
    return value


def _read_render_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise CadisMapRenderApiError("render_artifact_not_found", "render artifact was not found", status=HTTPStatus.NOT_FOUND)
    return _read_json_object(path, path.name)


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def _optional_string(value: Any) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise CadisMapRenderApiError("invalid_string", "optional string fields must be strings")
    normalized = value.strip()
    return normalized or None


def _optional_positive_int(value: object) -> int | None:
    if isinstance(value, bool) or not isinstance(value, int):
        return None
    if value <= 0:
        return None
    return int(value)


def _optional_env_token(token_env: str, token_file_env: str) -> str | None:
    value = os.environ.get(token_env, "").strip()
    if value:
        return value
    token_file = os.environ.get(token_file_env, "").strip()
    if not token_file:
        return None
    value = Path(token_file).read_text(encoding="utf-8").strip()
    return value or None


def _env_bool(name: str, *, default: bool) -> bool:
    value = os.environ.get(name)
    if value is None:
        return default
    normalized = value.strip().lower()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off"}:
        return False
    return default


def _safe_id(value: str) -> bool:
    return bool(value) and all(ch.isalnum() or ch in "._-" for ch in value)


def _new_render_id() -> str:
    return f"ren_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"


if __name__ == "__main__":
    raise SystemExit(main())
