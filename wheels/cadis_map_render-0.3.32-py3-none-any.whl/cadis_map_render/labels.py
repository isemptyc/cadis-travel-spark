from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from cadis_map_render.image import Image
from cadis_map_render.style_profile import parse_hex_color


SCENE_LABELS_PROFILE = "cadis.semantic_world.scene_labels"
LABEL_MANIFEST_PROFILE = "cadis.map_render.label_manifest"
SUPPORTED_LABEL_MANIFEST_KEYS = {
    "visible",
    "anchor_offset_px",
    "style_class",
    "size_px",
    "fill",
    "halo_fill",
    "halo_width_px",
    "opacity",
}


def labels_enabled(style: dict) -> bool:
    labels = style.get("labels")
    return isinstance(labels, dict) and labels.get("enabled") is True


def apply_label_pass(
    image: Image,
    *,
    scene_dir: Path,
    package_roots: dict[str, Path] | None = None,
    scene: dict,
    style: dict,
    crop_box: list[int] | None,
    external_label_manifest: str | Path | dict[str, Any] | None = None,
) -> tuple[Image, int, dict[str, Any]]:
    if not labels_enabled(style):
        return image, 0, {"label_manifest_source": "none"}
    roots = package_roots or {"scene": scene_dir, "core": scene_dir, "presentation": scene_dir}
    sidecar = _load_label_sidecar(scene_dir, scene, package_roots=roots)
    if sidecar is None:
        return image, 0, {"label_manifest_source": "none"}
    manifest = _resolve_label_manifest(
        scene_dir,
        scene,
        package_roots=roots,
        external_label_manifest=external_label_manifest,
    )
    output = image.copy()
    count = 0
    for label in sorted(sidecar.get("labels", []), key=lambda row: str(row.get("label_id", ""))):
        if not isinstance(label, dict) or label.get("placement", {}).get("status") != "placed":
            continue
        resolved = _resolve_label_style(label, manifest, style)
        if not resolved["visible"]:
            continue
        anchor = label.get("anchor_pixel")
        if not _is_number_pair(anchor):
            continue
        x = float(anchor[0]) + resolved["anchor_offset_px"][0]
        y = float(anchor[1]) + resolved["anchor_offset_px"][1]
        if crop_box is not None and _hide_outside_crop(label, x=x, y=y, crop_box=crop_box):
            continue
        _draw_text(
            output,
            str(label.get("display_name", "")),
            center_x=int(round(x)),
            center_y=int(round(y)),
            size_px=resolved["size_px"],
            fill=resolved["fill"],
            halo_fill=resolved["halo_fill"],
            halo_width_px=resolved["halo_width_px"],
            opacity=resolved["opacity"],
        )
        count += 1
    return output, count, {"label_manifest_source": manifest["source"]}


def _load_label_sidecar(
    scene_dir: Path,
    scene: dict,
    *,
    package_roots: dict[str, Path],
) -> dict | None:
    path = _design_asset_path(scene_dir, scene, "label_sidecar", required=False, package_roots=package_roots)
    if path is None:
        return None
    sidecar = _load_json(path)
    if sidecar.get("profile") != SCENE_LABELS_PROFILE:
        raise ValueError("unsupported label sidecar profile")
    if sidecar.get("schema_version") != 1:
        raise ValueError("unsupported label sidecar schema_version")
    if sidecar.get("scene_id") != scene.get("scene_id"):
        raise ValueError("label sidecar scene_id must match scene manifest")
    if sidecar.get("scene_version") != scene.get("scene_version"):
        raise ValueError("label sidecar scene_version must match scene manifest")
    return sidecar


def _resolve_label_manifest(
    scene_dir: Path,
    scene: dict,
    *,
    package_roots: dict[str, Path],
    external_label_manifest: str | Path | dict[str, Any] | None,
) -> dict:
    packaged = _load_packaged_label_manifest(scene_dir, scene, package_roots=package_roots)
    external = _load_external_label_manifest(external_label_manifest, scene)
    if not external.get("labels"):
        return packaged
    source = (
        "packaged+external"
        if packaged.get("labels")
        else "external"
    )
    merged = {"labels": dict(packaged.get("labels", {}))}
    for label_id, override in external["labels"].items():
        base = merged["labels"].get(label_id)
        if isinstance(base, dict):
            row = dict(base)
            row.update(override)
            merged["labels"][label_id] = row
        else:
            merged["labels"][label_id] = dict(override)
    merged["source"] = source
    return merged


def _load_packaged_label_manifest(
    scene_dir: Path,
    scene: dict,
    *,
    package_roots: dict[str, Path],
) -> dict:
    path = _design_asset_path(scene_dir, scene, "label_manifest", required=False, package_roots=package_roots)
    if path is None:
        return {"labels": {}, "source": "none"}
    manifest = _validate_label_manifest(_load_json(path), scene)
    manifest["source"] = "packaged" if manifest["labels"] else "none"
    return manifest


def _load_external_label_manifest(
    value: str | Path | dict[str, Any] | None,
    scene: dict,
) -> dict:
    if value is None:
        return {"labels": {}, "source": "none"}
    manifest = value if isinstance(value, dict) else _load_json(Path(value))
    validated = _validate_label_manifest(manifest, scene)
    validated["source"] = "external" if validated["labels"] else "none"
    return validated


def _validate_label_manifest(manifest: dict, scene: dict) -> dict:
    if not isinstance(manifest, dict):
        raise ValueError("label manifest must be a JSON object")
    if manifest.get("profile") != LABEL_MANIFEST_PROFILE:
        raise ValueError("unsupported label manifest profile")
    if manifest.get("schema_version") != 1:
        raise ValueError("unsupported label manifest schema_version")
    if manifest.get("scene_id") not in {None, scene.get("scene_id")}:
        raise ValueError("label manifest scene_id must match scene manifest")
    if manifest.get("scene_version") not in {None, scene.get("scene_version")}:
        raise ValueError("label manifest scene_version must match scene manifest")
    labels = manifest.get("labels")
    if not isinstance(labels, dict):
        raise ValueError("label manifest labels must be an object")
    for label_id, override in labels.items():
        if not isinstance(label_id, str) or not isinstance(override, dict):
            raise ValueError("label manifest overrides must be keyed objects")
        unsupported = sorted(set(override) - SUPPORTED_LABEL_MANIFEST_KEYS)
        if unsupported:
            raise ValueError(f"unsupported label manifest keys for {label_id}: {', '.join(unsupported)}")
        if "anchor_offset_px" in override and not _is_number_pair(override["anchor_offset_px"]):
            raise ValueError("label anchor_offset_px must be [x,y]")
    return {"labels": labels}


def _design_asset_path(
    scene_dir: Path,
    scene: dict,
    key: str,
    *,
    required: bool,
    package_roots: dict[str, Path] | None = None,
) -> Path | None:
    design = scene.get("design_facing")
    if not isinstance(design, dict):
        raise ValueError("scene manifest design_facing must be an object")
    asset = design.get(key)
    if asset is None and not required:
        return None
    if not isinstance(asset, dict):
        raise ValueError(f"scene manifest design_facing.{key} must be an object")
    raw_package = asset.get("package", "scene")
    roots = package_roots or {"scene": scene_dir, "core": scene_dir, "presentation": scene_dir}
    if raw_package not in roots:
        raise ValueError(f"scene manifest design_facing.{key}.package is unsupported")
    rel_path = asset.get("path")
    if not isinstance(rel_path, str) or not rel_path:
        raise ValueError(f"scene manifest design_facing.{key}.path is required")
    path = Path(rel_path)
    if path.is_absolute() or ".." in path.parts:
        raise ValueError(f"scene manifest design_facing.{key}.path must be package-relative")
    resolved = roots[str(raw_package)] / path
    if not resolved.exists():
        raise ValueError(f"Missing scene label asset: {resolved}")
    expected_sha = asset.get("sha256")
    if isinstance(expected_sha, str) and expected_sha and _sha256(resolved) != expected_sha:
        raise ValueError(f"Checksum mismatch for scene label asset: {rel_path}")
    return resolved


def _resolve_label_style(label: dict, manifest: dict, style: dict) -> dict:
    label_id = str(label.get("label_id", ""))
    labels_style = style.get("labels") if isinstance(style.get("labels"), dict) else {}
    classes = labels_style.get("classes") if isinstance(labels_style.get("classes"), dict) else {}
    style_class = str(label.get("style_class", "country.default"))
    resolved = dict(classes.get(style_class, {})) if isinstance(classes.get(style_class), dict) else {}
    manifest_labels = manifest.get("labels") if isinstance(manifest.get("labels"), dict) else {}
    override = manifest_labels.get(label_id)
    if isinstance(override, dict):
        override_class = override.get("style_class")
        if isinstance(override_class, str) and isinstance(classes.get(override_class), dict):
            resolved.update(classes[override_class])
        resolved.update(override)
    offset = resolved.get("anchor_offset_px", [0, 0])
    if not _is_number_pair(offset):
        raise ValueError("label anchor_offset_px must be [x,y]")
    return {
        "visible": bool(resolved.get("visible", True)),
        "anchor_offset_px": [float(offset[0]), float(offset[1])],
        "size_px": max(5, int(round(float(resolved.get("size_px", 12))))),
        "fill": parse_hex_color(resolved.get("fill", "#22342d")),
        "halo_fill": parse_hex_color(resolved.get("halo_fill", "#f2f6ee")),
        "halo_width_px": max(0, int(round(float(resolved.get("halo_width_px", 1))))),
        "opacity": max(0.0, min(1.0, float(resolved.get("opacity", 1.0)))),
    }


def _hide_outside_crop(label: dict, *, x: float, y: float, crop_box: list[int]) -> bool:
    policy = label.get("visibility", {}).get("crop_policy")
    if policy not in {None, "hide_if_anchor_outside_crop"}:
        return False
    left, top, right, bottom = crop_box
    return x < left or x >= right or y < top or y >= bottom


def _draw_text(
    image: Image,
    text: str,
    *,
    center_x: int,
    center_y: int,
    size_px: int,
    fill: tuple[float, float, float],
    halo_fill: tuple[float, float, float],
    halo_width_px: int,
    opacity: float,
) -> None:
    scale = max(1, int(round(size_px / 7.0)))
    glyph_width = 5 * scale
    glyph_height = 7 * scale
    spacing = scale
    text = text.upper()
    width = sum((_glyph_width(ch) * scale if ch != " " else 3 * scale) for ch in text)
    if text:
        width += spacing * (len(text) - 1)
    x0 = center_x - width // 2
    y0 = center_y - glyph_height // 2
    if halo_width_px > 0:
        for dy in range(-halo_width_px, halo_width_px + 1):
            for dx in range(-halo_width_px, halo_width_px + 1):
                if dx == 0 and dy == 0:
                    continue
                _draw_glyphs(image, text, x0 + dx, y0 + dy, scale, halo_fill, opacity)
    _draw_glyphs(image, text, x0, y0, scale, fill, opacity)


def _draw_glyphs(
    image: Image,
    text: str,
    x: int,
    y: int,
    scale: int,
    color: tuple[float, float, float],
    opacity: float,
) -> None:
    cursor = x
    for ch in text:
        if ch == " ":
            cursor += 4 * scale
            continue
        glyph = FONT_5X7.get(ch, FONT_5X7["?"])
        for row, bits in enumerate(glyph):
            for col, value in enumerate(bits):
                if value != "1":
                    continue
                for yy in range(y + row * scale, y + (row + 1) * scale):
                    if yy < 0 or yy >= image.height:
                        continue
                    for xx in range(cursor + col * scale, cursor + (col + 1) * scale):
                        if 0 <= xx < image.width:
                            image.blend_pixel(yy, xx, color, opacity)
        cursor += (_glyph_width(ch) + 1) * scale


def _glyph_width(ch: str) -> int:
    if ch == " ":
        return 3
    return len(FONT_5X7.get(ch, FONT_5X7["?"])[0])


def _is_number_pair(value: object) -> bool:
    return (
        isinstance(value, list)
        and len(value) == 2
        and all(isinstance(item, int | float) and not isinstance(item, bool) for item in value)
    )


def _load_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON asset must be an object: {path}")
    return value


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


FONT_5X7 = {
    "A": ["01110", "10001", "10001", "11111", "10001", "10001", "10001"],
    "B": ["11110", "10001", "10001", "11110", "10001", "10001", "11110"],
    "C": ["01111", "10000", "10000", "10000", "10000", "10000", "01111"],
    "D": ["11110", "10001", "10001", "10001", "10001", "10001", "11110"],
    "E": ["11111", "10000", "10000", "11110", "10000", "10000", "11111"],
    "F": ["11111", "10000", "10000", "11110", "10000", "10000", "10000"],
    "G": ["01111", "10000", "10000", "10011", "10001", "10001", "01111"],
    "H": ["10001", "10001", "10001", "11111", "10001", "10001", "10001"],
    "I": ["11111", "00100", "00100", "00100", "00100", "00100", "11111"],
    "J": ["00111", "00010", "00010", "00010", "10010", "10010", "01100"],
    "K": ["10001", "10010", "10100", "11000", "10100", "10010", "10001"],
    "L": ["10000", "10000", "10000", "10000", "10000", "10000", "11111"],
    "M": ["10001", "11011", "10101", "10101", "10001", "10001", "10001"],
    "N": ["10001", "11001", "10101", "10011", "10001", "10001", "10001"],
    "O": ["01110", "10001", "10001", "10001", "10001", "10001", "01110"],
    "P": ["11110", "10001", "10001", "11110", "10000", "10000", "10000"],
    "Q": ["01110", "10001", "10001", "10001", "10101", "10010", "01101"],
    "R": ["11110", "10001", "10001", "11110", "10100", "10010", "10001"],
    "S": ["01111", "10000", "10000", "01110", "00001", "00001", "11110"],
    "T": ["11111", "00100", "00100", "00100", "00100", "00100", "00100"],
    "U": ["10001", "10001", "10001", "10001", "10001", "10001", "01110"],
    "V": ["10001", "10001", "10001", "10001", "10001", "01010", "00100"],
    "W": ["10001", "10001", "10001", "10101", "10101", "10101", "01010"],
    "X": ["10001", "10001", "01010", "00100", "01010", "10001", "10001"],
    "Y": ["10001", "10001", "01010", "00100", "00100", "00100", "00100"],
    "Z": ["11111", "00001", "00010", "00100", "01000", "10000", "11111"],
    "0": ["01110", "10001", "10011", "10101", "11001", "10001", "01110"],
    "1": ["00100", "01100", "00100", "00100", "00100", "00100", "01110"],
    "2": ["01110", "10001", "00001", "00010", "00100", "01000", "11111"],
    "3": ["11110", "00001", "00001", "01110", "00001", "00001", "11110"],
    "4": ["00010", "00110", "01010", "10010", "11111", "00010", "00010"],
    "5": ["11111", "10000", "10000", "11110", "00001", "00001", "11110"],
    "6": ["01110", "10000", "10000", "11110", "10001", "10001", "01110"],
    "7": ["11111", "00001", "00010", "00100", "01000", "01000", "01000"],
    "8": ["01110", "10001", "10001", "01110", "10001", "10001", "01110"],
    "9": ["01110", "10001", "10001", "01111", "00001", "00001", "01110"],
    "-": ["00000", "00000", "00000", "11111", "00000", "00000", "00000"],
    ".": ["000", "000", "000", "000", "000", "110", "110"],
    "'": ["10", "10", "00", "00", "00", "00", "00"],
    "?": ["11110", "00001", "00001", "00110", "00100", "00000", "00100"],
}
