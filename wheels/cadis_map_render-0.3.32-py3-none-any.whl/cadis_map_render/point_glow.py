from __future__ import annotations

import json
import math
from pathlib import Path

from cadis_map_render.image import FloatColor, Image, float_color

from cadis_map_render.png_io import read_rgb_png, write_png
from cadis_map_render.style_profile import parse_hex_color


EARTH_RADIUS_KM = 6371.0088
PROJECTION_EQUIRECTANGULAR = "equirectangular"
PROJECTION_WEB_MERCATOR = "web-mercator"
ACTIVATION_POINT_CLUSTER = "point_cluster"
ACTIVATION_POINT_MARKER = "point_marker"
ACTIVATION_MODES = {ACTIVATION_POINT_CLUSTER, ACTIVATION_POINT_MARKER}


def render_point_cluster_glow(
    base_png: str | Path,
    photos_path: str | Path,
    output_png: str | Path,
    *,
    bounds: tuple[float, float, float, float],
    projection: str = PROJECTION_WEB_MERCATOR,
    cluster_radius_km: float = 5.0,
    min_glow_radius_px: float = 20.0,
    max_glow_radius_px: float = 92.0,
    activation_mode: str = ACTIVATION_POINT_CLUSTER,
    glow_color: str = "#ffc556",
    marker_color: str = "#fff4c2",
    marker_outline_color: str = "#5a3b10",
    marker_min_radius_px: float = 4.0,
    marker_max_radius_px: float = 14.0,
    halo_alpha: float = 0.62,
    core_alpha: float = 0.42,
    max_alpha: float = 0.86,
) -> dict:
    if activation_mode not in ACTIVATION_MODES:
        raise ValueError(f"Unknown activation mode: {activation_mode!r}")
    if cluster_radius_km <= 0:
        raise ValueError("cluster_radius_km must be positive")
    base = read_rgb_png(base_png).copy()
    source_rows = _load_point_rows(photos_path)
    points = [
        {
            "lat": float(row["lat"]),
            "lon": float(row["lon"]),
            "weight": int(row.get("weight", 1)),
        }
        for row in source_rows
        if _is_number(row.get("lat")) and _is_number(row.get("lon"))
    ]
    clusters = _cluster_points(points, radius_km=cluster_radius_km)
    output = _paint_clusters(
        base,
        clusters,
        bounds=bounds,
        projection=projection,
        min_glow_radius_px=min_glow_radius_px,
        max_glow_radius_px=max_glow_radius_px,
        activation_mode=activation_mode,
        glow_color=glow_color,
        marker_color=marker_color,
        marker_outline_color=marker_outline_color,
        marker_min_radius_px=marker_min_radius_px,
        marker_max_radius_px=marker_max_radius_px,
        halo_alpha=halo_alpha,
        core_alpha=core_alpha,
        max_alpha=max_alpha,
    )
    output_path = Path(output_png)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    write_png(output_path, output)
    return {
        "status": "ok",
        "base_png": str(Path(base_png)),
        "photos": str(Path(photos_path)),
        "output_png": str(output_path),
        "bounds": [float(value) for value in bounds],
        "projection": projection,
        "activation_mode": activation_mode,
        "cluster_radius_km": float(cluster_radius_km),
        "glow_color": glow_color,
        "source_point_count": len(source_rows),
        "located_point_count": len(points),
        "located_density_weight": sum(point.get("weight", 1) for point in points),
        "cluster_count": len(clusters),
        "clusters": [
            {
                "lat": round(cluster["lat"], 6),
                "lon": round(cluster["lon"], 6),
                "count": int(cluster["count"]),
            }
            for cluster in sorted(clusters, key=lambda row: -int(row["count"]))
        ],
    }


def _load_point_rows(path: str | Path) -> list[dict]:
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if isinstance(value, dict) and isinstance(value.get("places"), list):
        return [
            {
                "lat": row.get("lat"),
                "lon": row.get("lon"),
                "weight": row.get("density", 1),
            }
            for row in value["places"]
            if isinstance(row, dict)
        ]
    if isinstance(value, dict) and isinstance(value.get("photos"), list):
        value = value["photos"]
    if not isinstance(value, list) or not all(isinstance(item, dict) for item in value):
        raise ValueError(
            "point glow input must be photos JSON or a publish request with places"
        )
    return [
        {
            "lat": row.get("latitude"),
            "lon": row.get("longitude"),
            "weight": 1,
        }
        for row in value
    ]


def _cluster_points(points: list[dict], *, radius_km: float) -> list[dict]:
    clusters: list[dict] = []
    for point in points:
        nearest = None
        nearest_distance = math.inf
        for cluster in clusters:
            distance = _haversine_km(
                float(point["lat"]),
                float(point["lon"]),
                float(cluster["lat"]),
                float(cluster["lon"]),
            )
            if distance < nearest_distance:
                nearest = cluster
                nearest_distance = distance
        if nearest is None or nearest_distance > radius_km:
            clusters.append(
                {
                    "lat": float(point["lat"]),
                    "lon": float(point["lon"]),
                    "count": int(point.get("weight", 1)),
                }
            )
            continue
        count = int(nearest["count"])
        weight = int(point.get("weight", 1))
        nearest["lat"] = (
            float(nearest["lat"]) * count + float(point["lat"]) * weight
        ) / (count + weight)
        nearest["lon"] = (
            float(nearest["lon"]) * count + float(point["lon"]) * weight
        ) / (count + weight)
        nearest["count"] = count + weight
    return clusters


def _paint_clusters(
    base: Image,
    clusters: list[dict],
    *,
    bounds: tuple[float, float, float, float],
    projection: str,
    min_glow_radius_px: float,
    max_glow_radius_px: float,
    activation_mode: str,
    glow_color: str,
    marker_color: str,
    marker_outline_color: str,
    marker_min_radius_px: float,
    marker_max_radius_px: float,
    halo_alpha: float,
    core_alpha: float,
    max_alpha: float,
) -> Image:
    canvas = base.copy()
    height, width = canvas.height, canvas.width
    glow = float_color(parse_hex_color(glow_color))
    marker = float_color(parse_hex_color(marker_color))
    marker_outline = float_color(parse_hex_color(marker_outline_color))
    for cluster in clusters:
        x, y = _project_to_pixel(
            float(cluster["lon"]),
            float(cluster["lat"]),
            bounds=bounds,
            projection=projection,
            width=width,
            height=height,
        )
        if x < -max_glow_radius_px or y < -max_glow_radius_px:
            continue
        if x > width + max_glow_radius_px or y > height + max_glow_radius_px:
            continue
        count = int(cluster["count"])
        radius = min(
            max_glow_radius_px,
            max(min_glow_radius_px, min_glow_radius_px + math.sqrt(count) * 8.0),
        )
        intensity = min(1.0, 0.24 + math.log1p(count) / 4.2)
        if activation_mode == ACTIVATION_POINT_CLUSTER:
            _add_glow(
                canvas,
                x=x,
                y=y,
                radius=radius,
                intensity=intensity,
                color=glow,
                halo_alpha=halo_alpha,
                core_alpha=core_alpha,
                max_alpha=max_alpha,
            )
        elif activation_mode == ACTIVATION_POINT_MARKER:
            marker_radius = min(
                marker_max_radius_px,
                max(marker_min_radius_px, marker_min_radius_px + math.sqrt(count) * 0.82),
            )
            _add_glow(
                canvas,
                x=x,
                y=y,
                radius=max(radius * 0.58, marker_radius * 3.2),
                intensity=min(1.0, intensity * 0.78),
                color=glow,
                halo_alpha=halo_alpha * 0.5,
                core_alpha=core_alpha * 0.35,
                max_alpha=max_alpha * 0.62,
            )
            _add_marker(
                canvas,
                x=x,
                y=y,
                radius=marker_radius,
                color=marker,
                outline_color=marker_outline,
            )
    return canvas


def _add_glow(
    canvas: Image,
    *,
    x: float,
    y: float,
    radius: float,
    intensity: float,
    color: FloatColor,
    halo_alpha: float,
    core_alpha: float,
    max_alpha: float,
) -> None:
    height, width = canvas.height, canvas.width
    pad = int(math.ceil(radius * 2.8))
    x0 = max(0, int(math.floor(x - pad)))
    x1 = min(width, int(math.ceil(x + pad + 1)))
    y0 = max(0, int(math.floor(y - pad)))
    y1 = min(height, int(math.ceil(y + pad + 1)))
    if x0 >= x1 or y0 >= y1:
        return
    sigma = radius * 0.72
    halo_denominator = 2.0 * sigma * sigma
    core_denominator = 2.0 * (radius * 0.22) ** 2
    core_intensity = min(1.0, intensity * 1.4)
    for row in range(y0, y1):
        dy2 = (row - y) ** 2
        for col in range(x0, x1):
            dist2 = (col - x) ** 2 + dy2
            halo = math.exp(-dist2 / halo_denominator) * intensity
            core = math.exp(-dist2 / core_denominator) * core_intensity
            alpha = min(max_alpha, max(0.0, halo * halo_alpha + core * core_alpha))
            canvas.blend_pixel(row, col, color, alpha)


def _add_marker(
    canvas: Image,
    *,
    x: float,
    y: float,
    radius: float,
    color: FloatColor,
    outline_color: FloatColor,
) -> None:
    height, width = canvas.height, canvas.width
    pad = int(math.ceil(radius + 3.0))
    x0 = max(0, int(math.floor(x - pad)))
    x1 = min(width, int(math.ceil(x + pad + 1)))
    y0 = max(0, int(math.floor(y - pad)))
    y1 = min(height, int(math.ceil(y + pad + 1)))
    if x0 >= x1 or y0 >= y1:
        return
    outer_radius = radius + 1.6
    highlight_radius = max(1.0, radius * 0.42)
    white = (255.0, 255.0, 255.0)
    for row in range(y0, y1):
        dy2 = (row - y) ** 2
        for col in range(x0, x1):
            dist = math.sqrt((col - x) ** 2 + dy2)
            if dist <= outer_radius:
                canvas.blend_pixel(row, col, outline_color, 0.82)
            if dist <= radius:
                canvas.blend_pixel(row, col, color, 0.82)
            if dist <= highlight_radius:
                canvas.blend_pixel(row, col, white, 0.65)


def _project_to_pixel(
    lon: float,
    lat: float,
    *,
    bounds: tuple[float, float, float, float],
    projection: str,
    width: int,
    height: int,
) -> tuple[float, float]:
    min_lon, min_lat, max_lon, max_lat = bounds
    minx, miny = _project_lonlat(min_lon, min_lat, projection)
    maxx, maxy = _project_lonlat(max_lon, max_lat, projection)
    x, y = _project_lonlat(lon, lat, projection)
    px = (x - minx) / (maxx - minx) * width
    py = (maxy - y) / (maxy - miny) * height
    return px, py


def _project_lonlat(lon: float, lat: float, projection: str) -> tuple[float, float]:
    if projection == PROJECTION_EQUIRECTANGULAR:
        return lon, lat
    if projection == PROJECTION_WEB_MERCATOR:
        clipped = min(85.05112878, max(-85.05112878, lat))
        radians = math.radians(clipped)
        y = math.degrees(math.log(math.tan(math.pi / 4.0 + radians / 2.0)))
        return lon, y
    raise ValueError(f"Unknown projection: {projection!r}")


def _haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = (
        math.sin(dphi / 2.0) ** 2
        + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2.0) ** 2
    )
    return 2.0 * EARTH_RADIUS_KM * math.atan2(math.sqrt(a), math.sqrt(1.0 - a))


def _is_number(value: object) -> bool:
    return isinstance(value, int | float)
