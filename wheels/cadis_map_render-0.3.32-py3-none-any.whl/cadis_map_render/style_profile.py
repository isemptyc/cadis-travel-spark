from __future__ import annotations

import json
import os
from pathlib import Path
from importlib import resources


DEFAULT_STYLE_ID = "memory_atlas_warm_v1"
STYLE_DIR_ENV = "CADIS_MAP_RENDER_STYLE_DIR"
EONA_STYLE_ALIASES = {
    "puzzle-pale": "memory_atlas_pale_v1",
    "spark-night": "memory_atlas_night_v1",
}


def load_style_profile(path: str | Path | None) -> dict:
    if path is None:
        return default_style_profile()
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    return normalize_style_profile(value)


def load_bundled_style_profile(style_id: str | None) -> dict | None:
    resolved_style_id = resolve_style_id(style_id)
    if resolved_style_id is None:
        return None
    external_style_path = _external_style_profile_path(resolved_style_id)
    if external_style_path is not None and external_style_path.is_file():
        return load_style_profile(external_style_path)
    style_path = resources.files("cadis_map_render").joinpath(
        "styles",
        f"{resolved_style_id}.json",
    )
    if not style_path.is_file():
        return None
    value = json.loads(style_path.read_text(encoding="utf-8"))
    return normalize_style_profile(value)


def resolve_style_id(style_id: str | None) -> str | None:
    if style_id is None:
        return None
    normalized = style_id.strip()
    if not normalized:
        return None
    return EONA_STYLE_ALIASES.get(normalized, normalized)


def _external_style_profile_path(style_id: str) -> Path | None:
    style_dir = os.environ.get(STYLE_DIR_ENV)
    if not style_dir or not style_dir.strip():
        return None
    style_filename = _style_profile_filename(style_id)
    if style_filename is None:
        return None
    return Path(style_dir).expanduser() / style_filename


def _style_profile_filename(style_id: str) -> str | None:
    path = Path(f"{style_id}.json")
    if path.is_absolute() or ".." in path.parts or len(path.parts) != 1:
        return None
    return path.name


def normalize_style_profile(value: dict) -> dict:
    if not isinstance(value, dict):
        raise ValueError("style profile must be a JSON object")
    return _merge_style(default_style_profile(), value)


def default_style_profile() -> dict:
    return {
        "profile": "cadis.semantic_world.map_style",
        "schema_version": 1,
        "style_id": DEFAULT_STYLE_ID,
        "description": "Warm semantic memory atlas style.",
        "tone": {
            "mode": "none",
            "overlay": "#000000",
            "strength": 0.0,
        },
        "base": {
            "sea": "#0c1a2b",
            "land": "#3e5b4a",
            "context_land": "#5a6060",
            "outer_border": "#cfe0d6",
            "inner_border": "#4c7062",
            "focus_country_border": "#deeae0",
            "context_border": "#74807c",
            "sea_depth_mode": "none",
            "sea_depth_near_color": "#0c1a2b",
            "sea_depth_far_color": "#0c1a2b",
            "sea_depth_radius_px": 0.0,
            "sea_depth_alpha": 0.0,
            "outer_border_width_px": 0.0,
            "inner_border_width_px": 1.0,
            "focus_country_border_width_px": 1.0,
            "context_border_width_px": 1.0,
        },
        "activation": {
            "mode": "point_cluster",
            "cluster_radius_km": 5.0,
            "glow_color": "#ffc556",
            "marker_color": "#fff4c2",
            "marker_outline_color": "#5a3b10",
            "region_fill_color": "#ffc556",
            "region_border_color": "#fff4c2",
            "region_glow_color": "#ffc556",
            "activated_country_fill_color": "#a7c79e",
            "activated_country_fill_alpha": 0.22,
            "activated_country_fill_alpha_min": 0.08,
            "activated_country_density_scale": "log",
            "activated_country_border_color": "#ffffff",
            "activated_country_border_alpha": 0.55,
            "activated_country_glow_color": "#ffffff",
            "activated_country_glow_alpha": 0.0,
            "activated_country_glow_radius_px": 0.0,
            "activated_country_border_width_px": 1.0,
            "activated_admin_region_fill_color": "#a7c79e",
            "activated_admin_region_fill_alpha": 0.18,
            "activated_admin_region_fill_alpha_min": 0.04,
            "activated_admin_region_density_scale": "log",
            "activated_admin_region_border_color": "#ffffff",
            "activated_admin_region_border_alpha": 0.0,
            "activated_admin_region_glow_color": "#ffffff",
            "activated_admin_region_glow_alpha": 0.0,
            "activated_admin_region_glow_radius_px": 0.0,
            "activated_admin_region_border_width_px": 1.0,
            "activated_region_fill_alpha": 0.18,
            "activated_region_fill_alpha_min": 0.04,
            "activated_region_density_scale": "log",
            "activated_region_border_alpha": 0.0,
            "activated_region_glow_alpha": 0.0,
            "activated_region_glow_radius_px": 0.0,
            "activated_region_border_width_px": 1.0,
            "min_glow_radius_px": 24.0,
            "max_glow_radius_px": 120.0,
            "marker_min_radius_px": 4.0,
            "marker_max_radius_px": 14.0,
            "region_fill_alpha": 0.28,
            "region_fill_alpha_min": 0.0,
            "region_density_scale": "log",
            "region_border_alpha": 0.72,
            "region_glow_alpha": 0.28,
            "region_glow_radius_px": 18.0,
            "region_border_width_px": 1.0,
            "halo_alpha": 0.62,
            "core_alpha": 0.42,
            "max_alpha": 0.86,
        },
        "labels": {
            "enabled": False,
            "classes": {
                "country.default": {
                    "size_px": 12,
                    "fill": "#22342d",
                    "halo_fill": "#f2f6ee",
                    "halo_width_px": 1,
                    "opacity": 1.0,
                }
            },
        },
    }


def style_base(style: dict) -> dict:
    base = style.get("base")
    if not isinstance(base, dict):
        raise ValueError("style base must be an object")
    return base


def style_activation(style: dict) -> dict:
    activation = style.get("activation")
    if not isinstance(activation, dict):
        raise ValueError("style activation must be an object")
    return activation


def style_id(style: dict) -> str:
    value = style.get("style_id")
    return str(value) if value else DEFAULT_STYLE_ID


def style_tone(style: dict) -> dict:
    tone = style.get("tone")
    if not isinstance(tone, dict):
        raise ValueError("style tone must be an object")
    return tone


def style_labels(style: dict) -> dict:
    labels = style.get("labels")
    if not isinstance(labels, dict):
        raise ValueError("style labels must be an object")
    return labels


def parse_hex_color(value: object) -> tuple[float, float, float]:
    text = str(value).strip()
    if text.startswith("#"):
        text = text[1:]
    if len(text) != 6:
        raise ValueError(f"Expected #RRGGBB color, got {value!r}")
    return tuple(float(int(text[index : index + 2], 16)) for index in (0, 2, 4))


def _merge_style(base: dict, override: dict) -> dict:
    merged = dict(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = _merge_style(merged[key], value)
        else:
            merged[key] = value
    return merged
