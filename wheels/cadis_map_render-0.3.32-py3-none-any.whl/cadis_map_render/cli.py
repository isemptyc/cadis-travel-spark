from __future__ import annotations

import argparse
import json
from pathlib import Path

from cadis_map_render.dataset import (
    DEFAULT_CDN_DATASET_ROOT,
    CadisMapRenderClient,
    CdnDatasetCatalogSource,
    CdnDatasetSource,
    FileDatasetSource,
)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Render a Cadis map from a logical request JSON file.")
    source = parser.add_mutually_exclusive_group()
    source.add_argument("--dataset-root", type=Path, help="Existing local Cadis map dataset scene root.")
    source.add_argument("--dataset-archive-url", help="CDN/archive URL to download and cache before rendering.")
    source.add_argument(
        "--dataset-catalog-root",
        default=None,
        help=f"CDN dataset catalog root containing scene archive manifests. Defaults to {DEFAULT_CDN_DATASET_ROOT}.",
    )
    parser.add_argument("--dataset-key", help="Stable cache key for --dataset-archive-url.")
    parser.add_argument("--dataset-sha256", help="Expected SHA256 for --dataset-archive-url.")
    parser.add_argument("--dataset-subdir", help="Subdirectory inside the extracted dataset archive.")
    parser.add_argument("--scene-id", help="Explicit Cadis scene id for --dataset-catalog-root.")
    parser.add_argument("--dataset-resolution", help="Optional CDN catalog resolution, for example 2048 or 4096.")
    parser.add_argument("--dataset-family", help="Optional CDN catalog family override.")
    parser.add_argument("--scene-version", help="Optional explicit scene version for CDN catalog lookup.")
    parser.add_argument("--cache-root", type=Path, help="Dataset/admission cache root. Defaults to the OS user cache.")
    parser.add_argument("--output-root", type=Path, required=True, help="Render output root.")
    parser.add_argument("--request-json", type=Path, required=True, help="Logical render request JSON.")
    parser.add_argument("--admission-mode", choices=("trusted", "copy"), default="trusted")
    args = parser.parse_args(argv)

    if args.dataset_root is not None:
        dataset_source = FileDatasetSource(args.dataset_root)
    elif args.dataset_archive_url is not None:
        if not args.dataset_key:
            parser.error("--dataset-key is required with --dataset-archive-url")
        dataset_source = CdnDatasetSource(
            archive_url=str(args.dataset_archive_url),
            cache_root=args.cache_root,
            dataset_key=str(args.dataset_key),
            sha256=args.dataset_sha256,
            dataset_subdir=args.dataset_subdir,
        )
    else:
        if not args.scene_id:
            parser.error("--scene-id is required with CDN catalog mode")
        dataset_source = CdnDatasetCatalogSource(
            dataset_root_url=str(args.dataset_catalog_root or DEFAULT_CDN_DATASET_ROOT),
            cache_root=args.cache_root,
            scene_id=str(args.scene_id),
            resolution=args.dataset_resolution,
            version=args.scene_version,
            dataset_family=args.dataset_family,
        )

    payload = json.loads(args.request_json.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        parser.error("--request-json must contain a JSON object")

    client = CadisMapRenderClient(
        dataset_source=dataset_source,
        output_root=args.output_root,
        cache_root=args.cache_root,
        admission_mode=args.admission_mode,
    )
    print(json.dumps(client.render_map(payload), ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
