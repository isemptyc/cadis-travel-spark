from __future__ import annotations

import struct
import zlib
from pathlib import Path

from cadis_map_render.image import Image


def read_rgb_png(path: str | Path) -> Image:
    image = read_png(path)
    if image.channels != 3:
        raise ValueError("PNG reader expected an RGB PNG")
    return image


def read_png(path: str | Path) -> Image:
    png_path = Path(path)
    data = png_path.read_bytes()
    if not data.startswith(b"\x89PNG\r\n\x1a\n"):
        raise ValueError(f"Not a PNG file: {png_path}")
    offset = 8
    width = height = color_type = None
    compressed = b""
    while offset < len(data):
        length = struct.unpack(">I", data[offset : offset + 4])[0]
        kind = data[offset + 4 : offset + 8]
        payload = data[offset + 8 : offset + 8 + length]
        offset += 12 + length
        if kind == b"IHDR":
            width, height, bit_depth, color_type, _, _, _ = struct.unpack(
                ">IIBBBBB",
                payload,
            )
            if bit_depth != 8 or color_type not in {2, 6}:
                raise ValueError("PNG reader only supports 8-bit RGB/RGBA PNGs")
        elif kind == b"IDAT":
            compressed += payload
        elif kind == b"IEND":
            break
    if width is None or height is None or color_type is None:
        raise ValueError("PNG missing IHDR")
    raw = zlib.decompress(compressed)
    channels = 4 if color_type == 6 else 3
    stride = width * channels
    image = Image(width=width, height=height, channels=channels, data=bytearray(height * stride))
    for row in range(height):
        start = row * (stride + 1)
        filter_type = raw[start]
        if filter_type != 0:
            raise ValueError("PNG reader only supports unfiltered rows")
        row_start = row * stride
        image.data[row_start : row_start + stride] = raw[start + 1 : start + 1 + stride]
    return image


def write_png(path: str | Path, image: Image) -> None:
    if image.channels not in {3, 4}:
        raise ValueError("PNG writer expects uint8 RGB or RGBA image")
    height, width, channels = image.height, image.width, image.channels
    color_type = 2 if channels == 3 else 6
    raw = b"".join(b"\x00" + image.row_bytes(row) for row in range(height))
    payload = b"\x89PNG\r\n\x1a\n"
    payload += _png_chunk(
        b"IHDR",
        struct.pack(">IIBBBBB", width, height, 8, color_type, 0, 0, 0),
    )
    payload += _png_chunk(b"IDAT", zlib.compress(raw, level=9))
    payload += _png_chunk(b"IEND", b"")
    Path(path).write_bytes(payload)


def _png_chunk(kind: bytes, data: bytes) -> bytes:
    checksum = zlib.crc32(kind)
    checksum = zlib.crc32(data, checksum)
    return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", checksum)


_read_rgb_png = read_rgb_png
_write_png = write_png
