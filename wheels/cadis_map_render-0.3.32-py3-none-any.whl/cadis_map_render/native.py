from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cadis_map_render.image import Color, FloatColor, Image, Mask


def replace_rgb_colors(image: Image, replacements: list[tuple[Color, Color]]) -> bool:
    if not replacements:
        return True
    try:
        import cadis_map_render_native
    except ImportError:
        return False
    cadis_map_render_native.replace_rgb_colors(
        image.data,
        image.width,
        image.height,
        image.channels,
        replacements,
    )
    return True


def blend_mask(image: Image, mask: Mask, color: FloatColor, alpha: float) -> bool:
    if alpha <= 0.0:
        return True
    try:
        import cadis_map_render_native
    except ImportError:
        return False
    cadis_map_render_native.blend_mask(
        image.data,
        image.width,
        image.height,
        image.channels,
        bytes(mask.data),
        color,
        alpha,
    )
    return True


def dilate4(mask: Mask) -> bytearray | None:
    try:
        import cadis_map_render_native
    except ImportError:
        return None
    return bytearray(cadis_map_render_native.dilate4(bytes(mask.data), mask.width, mask.height))


def outer_borders(mask: Mask) -> bytearray | None:
    try:
        import cadis_map_render_native
    except ImportError:
        return None
    return bytearray(
        cadis_map_render_native.outer_borders(bytes(mask.data), mask.width, mask.height)
    )
