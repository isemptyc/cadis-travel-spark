from __future__ import annotations

import hashlib
import json
import re
import shutil
from pathlib import Path
from typing import Any

import numpy as np

from cadis_map_render.semantic_vector import validate_semantic_vector_sidecar


SCENE_TEMPLATE_PROFILE = "cadis.semantic_world.scene_template"
SCENE_TEMPLATE_SCHEMA_VERSION = 1
STYLE_MANIFEST_PROFILE = "cadis.semantic_world.map_style_set"
STYLE_MANIFEST_SCHEMA_VERSION = 1
FEATURE_INDEX_PROFILE = "cadis.semantic_world.scene_feature_index"
FEATURE_INDEX_SCHEMA_VERSION = 1
LABEL_SIDECAR_PROFILE = "cadis.semantic_world.scene_labels"
LABEL_SIDECAR_SCHEMA_VERSION = 1
LABEL_MANIFEST_PROFILE = "cadis.map_render.label_manifest"
LABEL_MANIFEST_SCHEMA_VERSION = 1
LABEL_MANIFEST_ALLOWED_KEYS = {
    "visible",
    "anchor_offset_px",
    "style_class",
    "size_px",
    "fill",
    "halo_fill",
    "halo_width_px",
    "opacity",
}
SAFE_SEGMENT_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*$")


def validate_scene_package(package_dir: str | Path) -> dict:
    root = Path(package_dir)
    errors: list[dict] = []
    warnings: list[dict] = []
    assets: list[dict] = []
    metadata: dict[str, Any] = {
        "package_dir": str(root),
        "scene_id": None,
        "scene_version": None,
        "fingerprint": None,
    }

    manifest_path = _resolve_package_path(
        root,
        "scene_manifest.json",
        errors,
        "scene_manifest.json",
    )
    if manifest_path is None:
        return _validation_report(metadata, assets, errors, warnings)
    if not manifest_path.exists():
        errors.append(_error("missing_scene_manifest", "scene_manifest.json is required"))
        return _validation_report(metadata, assets, errors, warnings)

    manifest = _read_json(manifest_path, errors, "scene_manifest")
    if manifest is None:
        return _validation_report(metadata, assets, errors, warnings)
    if not isinstance(manifest, dict):
        errors.append(_error("invalid_scene_manifest", "scene_manifest.json must be an object"))
        return _validation_report(metadata, assets, errors, warnings)

    _validate_scene_manifest_identity(manifest, errors, metadata)
    design = manifest.get("design_facing")
    if not isinstance(design, dict):
        errors.append(_error("invalid_design_facing", "design_facing must be an object"))
        design = {}
    package_roots = _package_roots(root, manifest, errors)

    _validate_manifest_asset(root, package_roots, design, "base_image", errors, assets, required=True)
    _validate_manifest_asset(root, package_roots, design, "preview_image", errors, assets, required=True)
    semantic = _validate_manifest_asset(
        root,
        package_roots,
        design,
        "semantic_sidecar",
        errors,
        assets,
        required=False,
    )
    if semantic is not None:
        _validate_semantic_sidecar(
            semantic,
            manifest,
            errors,
        )
    _validate_claim_semantic_sidecars(root, package_roots, design, manifest, errors, assets)
    semantic_vector = _validate_manifest_asset(
        root,
        package_roots,
        design,
        "semantic_vector_sidecar",
        errors,
        assets,
        required=False,
    )
    if semantic_vector is not None:
        _validate_semantic_vector_asset(
            semantic_vector,
            manifest,
            errors,
        )
    feature_index = _validate_manifest_asset(
        root,
        package_roots,
        design,
        "feature_index",
        errors,
        assets,
        required=False,
    )
    if feature_index is not None:
        _validate_feature_index(feature_index, errors)
    label_sidecar = _validate_manifest_asset(
        root,
        package_roots,
        design,
        "label_sidecar",
        errors,
        assets,
        required=False,
    )
    if label_sidecar is not None:
        _validate_label_sidecar(label_sidecar, manifest, errors)
    label_manifest = _validate_manifest_asset(
        root,
        package_roots,
        design,
        "label_manifest",
        errors,
        assets,
        required=False,
    )
    if label_manifest is not None:
        _validate_label_manifest(label_manifest, manifest, errors)

    _validate_style_manifest(root, errors, assets)
    metadata["fingerprint"] = _package_fingerprint(root, manifest, assets)
    metadata["scene_fingerprint_sha256"] = manifest.get("scene_fingerprint_sha256")

    return _validation_report(metadata, assets, errors, warnings)


def admit_scene_package(package_dir: str | Path, cache_dir: str | Path) -> dict:
    validation = validate_scene_package(package_dir)
    if validation["status"] != "ok":
        return {
            "status": "invalid",
            "cache_path": None,
            "scene_id": validation["metadata"].get("scene_id"),
            "scene_version": validation["metadata"].get("scene_version"),
            "fingerprint": validation["metadata"].get("fingerprint"),
            "admitted_asset_count": 0,
            "validation": validation,
        }

    metadata = validation["metadata"]
    scene_id = str(metadata["scene_id"])
    scene_version = str(metadata["scene_version"])
    fingerprint = str(metadata["fingerprint"])
    target = Path(cache_dir) / scene_id / scene_version / fingerprint
    if target.exists():
        if not target.is_dir():
            return {
                "status": "invalid",
                "cache_path": str(target),
                "scene_id": scene_id,
                "scene_version": scene_version,
                "fingerprint": fingerprint,
                "admitted_asset_count": 0,
                "validation": validation,
                "errors": [
                    _error("invalid_cache_target", "cache target exists but is not a directory")
                ],
            }
        cached_validation = validate_scene_package(target)
        if (
            cached_validation["status"] != "ok"
            or cached_validation["metadata"].get("fingerprint") != fingerprint
        ):
            return {
                "status": "invalid",
                "cache_path": str(target),
                "scene_id": scene_id,
                "scene_version": scene_version,
                "fingerprint": fingerprint,
                "admitted_asset_count": 0,
                "validation": validation,
                "cache_validation": cached_validation,
                "errors": [
                    _error("invalid_cache_target", "existing cache target failed validation")
                ],
            }
    else:
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(Path(package_dir), target)

    return {
        "status": "ok",
        "cache_path": str(target),
        "scene_id": scene_id,
        "scene_version": scene_version,
        "fingerprint": fingerprint,
        "admitted_asset_count": len(validation["assets"]),
        "validation": validation,
    }


def _validate_scene_manifest_identity(
    manifest: dict,
    errors: list[dict],
    metadata: dict,
) -> None:
    if manifest.get("profile") != SCENE_TEMPLATE_PROFILE:
        errors.append(
            _error(
                "unsupported_scene_profile",
                f"scene manifest profile must be {SCENE_TEMPLATE_PROFILE}",
            )
        )
    if manifest.get("schema_version") != SCENE_TEMPLATE_SCHEMA_VERSION:
        errors.append(
            _error(
                "unsupported_scene_schema",
                f"scene manifest schema_version must be {SCENE_TEMPLATE_SCHEMA_VERSION}",
            )
        )
    for key in ("scene_id", "scene_version", "projection"):
        value = manifest.get(key)
        if not isinstance(value, str) or not value:
            errors.append(_error(f"missing_{key}", f"scene manifest {key} is required"))
        elif not _is_safe_segment(value):
            errors.append(_error(f"unsafe_{key}", f"scene manifest {key} must be a safe path segment"))
        else:
            metadata[key] = value
    bounds = manifest.get("bounds")
    if not isinstance(bounds, list) or len(bounds) != 4:
        errors.append(_error("missing_bounds", "scene manifest bounds must contain four numbers"))
    else:
        for value in bounds:
            if not isinstance(value, int | float):
                errors.append(_error("invalid_bounds", "scene manifest bounds must be numeric"))
                break
    for key in ("width", "height"):
        value = manifest.get(key)
        if not isinstance(value, int) or value <= 0:
            errors.append(_error(f"missing_{key}", f"scene manifest {key} must be positive"))


def _validate_manifest_asset(
    root: Path,
    package_roots: dict[str, Path],
    design: dict,
    key: str,
    errors: list[dict],
    assets: list[dict],
    *,
    required: bool,
) -> Path | None:
    value = design.get(key)
    if value is None and not required:
        return None
    if not isinstance(value, dict):
        errors.append(_error(f"missing_{key}", f"design_facing.{key} must be an object"))
        return None
    role = value.get("package", "scene")
    if role not in package_roots:
        errors.append(_error("unsupported_package_role", f"design_facing.{key}.package is unsupported"))
        return None
    resolved = _resolve_package_path(
        package_roots[str(role)],
        value.get("path"),
        errors,
        f"design_facing.{key}.path",
        boundary=root,
    )
    if resolved is None:
        return None
    if not resolved.exists():
        errors.append(_error(f"missing_{key}", f"Missing package asset: {resolved.relative_to(root)}"))
        return None
    expected_sha = value.get("sha256")
    actual_sha = _sha256(resolved)
    if not isinstance(expected_sha, str) or not expected_sha:
        errors.append(
            _error(
                f"missing_{key}_checksum",
                f"Missing sha256 for {resolved.relative_to(root)}",
            )
        )
    elif expected_sha != actual_sha:
        errors.append(
            _error(
                f"bad_{key}_checksum",
                f"Checksum mismatch for {resolved.relative_to(root)}",
            )
        )
    assets.append(
        {
            "role": key,
            "path": str(resolved.relative_to(root)),
            "sha256": actual_sha,
            "bytes": resolved.stat().st_size,
        }
    )
    return resolved


def _validate_semantic_vector_asset(path: Path, manifest: dict, errors: list[dict]) -> None:
    if path.suffix != ".json":
        errors.append(
            _error(
                "invalid_semantic_vector_sidecar",
                "semantic_vector_sidecar must be a JSON asset",
            )
        )
        return
    _validate_semantic_vector(path, manifest, errors)


def _validate_semantic_sidecar(path: Path, manifest: dict, errors: list[dict]) -> None:
    if path.suffix != ".npy":
        errors.append(_error("invalid_semantic_sidecar", "semantic_sidecar must be a .npy asset"))
        return
    try:
        semantic = np.load(path, allow_pickle=False, mmap_mode="r")
    except Exception as exc:  # pragma: no cover - exact numpy exception varies
        errors.append(_error("invalid_semantic_sidecar", f"Cannot load semantic sidecar: {exc}"))
        return
    if semantic.dtype != np.uint32:
        errors.append(_error("invalid_semantic_dtype", "semantic sidecar dtype must be uint32"))
    expected_shape = (manifest.get("height"), manifest.get("width"))
    if semantic.shape != expected_shape:
        errors.append(
            _error(
                "invalid_semantic_dimensions",
                "semantic sidecar dimensions must match scene height,width",
            )
        )


def _validate_claim_semantic_sidecars(
    root: Path,
    package_roots: dict[str, Path],
    design: dict,
    manifest: dict,
    errors: list[dict],
    assets: list[dict],
) -> None:
    value = design.get("claim_semantic_sidecars")
    if value is None:
        return
    if not isinstance(value, dict):
        errors.append(_error("invalid_claim_semantic_sidecars", "design_facing.claim_semantic_sidecars must be an object"))
        return
    for level, asset in value.items():
        if not isinstance(level, str) or not level.isdigit():
            errors.append(_error("invalid_claim_semantic_level", "claim semantic sidecar keys must be positive integer strings"))
            continue
        if not isinstance(asset, dict):
            errors.append(_error("invalid_claim_semantic_sidecar", f"claim_semantic_sidecars.{level} must be an object"))
            continue
        path = _validate_manifest_asset(
            root,
            package_roots,
            value,
            level,
            errors,
            assets,
            required=False,
        )
        if path is not None:
            _validate_semantic_sidecar(path, manifest, errors)
            assets[-1]["role"] = f"claim_semantic_sidecar:{level}"


def _validate_semantic_vector(path: Path, manifest: dict, errors: list[dict]) -> None:
    value = _read_json(path, errors, "semantic_vector_sidecar")
    if not isinstance(value, dict):
        errors.append(_error("invalid_semantic_vector_sidecar", "semantic vector sidecar must be a JSON object"))
        return
    for message in validate_semantic_vector_sidecar(
        value,
        width=int(manifest.get("width", -1)),
        height=int(manifest.get("height", -1)),
    ):
        errors.append(_error("invalid_semantic_vector_sidecar", message))


def _validate_feature_index(path: Path, errors: list[dict]) -> None:
    value = _read_json(path, errors, "feature_index")
    if not isinstance(value, dict):
        errors.append(_error("invalid_feature_index", "feature index must be a JSON object"))
        return
    profile = value.get("profile")
    if profile is not None and profile != FEATURE_INDEX_PROFILE:
        errors.append(_error("unsupported_feature_index_profile", "feature index profile is unsupported"))
    schema_version = value.get("schema_version")
    if schema_version is not None and schema_version != FEATURE_INDEX_SCHEMA_VERSION:
        errors.append(_error("unsupported_feature_index_schema", "feature index schema is unsupported"))


def _validate_label_sidecar(path: Path, manifest: dict, errors: list[dict]) -> None:
    value = _read_json(path, errors, "label_sidecar")
    if not isinstance(value, dict):
        errors.append(_error("invalid_label_sidecar", "label sidecar must be a JSON object"))
        return
    if value.get("profile") != LABEL_SIDECAR_PROFILE:
        errors.append(_error("unsupported_label_sidecar_profile", "label sidecar profile is unsupported"))
    if value.get("schema_version") != LABEL_SIDECAR_SCHEMA_VERSION:
        errors.append(_error("unsupported_label_sidecar_schema", "label sidecar schema_version is unsupported"))
    if value.get("scene_id") != manifest.get("scene_id"):
        errors.append(_error("label_sidecar_scene_mismatch", "label sidecar scene_id must match scene manifest"))
    if value.get("scene_version") != manifest.get("scene_version"):
        errors.append(_error("label_sidecar_version_mismatch", "label sidecar scene_version must match scene manifest"))
    labels = value.get("labels")
    if not isinstance(labels, list):
        errors.append(_error("invalid_label_sidecar_labels", "label sidecar labels must be an array"))
        return
    seen: set[str] = set()
    for label in labels:
        if not isinstance(label, dict):
            errors.append(_error("invalid_label_sidecar_label", "label sidecar labels entries must be objects"))
            continue
        label_id = label.get("label_id")
        if not isinstance(label_id, str) or not label_id:
            errors.append(_error("missing_label_id", "label entries require label_id"))
        elif label_id in seen:
            errors.append(_error("duplicate_label_id", f"duplicate label_id {label_id!r}"))
        else:
            seen.add(label_id)
        if label.get("kind") == "country":
            source = label.get("source")
            country = source.get("country_iso") if isinstance(source, dict) else None
            if not isinstance(country, str) or len(country.strip()) != 2:
                errors.append(_error("missing_label_country_iso", "country labels require source.country_iso"))
        if not isinstance(label.get("display_name"), str) or not label.get("display_name"):
            errors.append(_error("missing_label_display_name", "label entries require display_name"))
        anchor = label.get("anchor_pixel")
        if not _is_number_pair(anchor):
            errors.append(_error("invalid_label_anchor", "label anchor_pixel must be [x,y]"))
        if not isinstance(label.get("style_class"), str) or not label.get("style_class"):
            errors.append(_error("missing_label_style_class", "label entries require style_class"))
        placement = label.get("placement")
        if not isinstance(placement, dict) or not isinstance(placement.get("status"), str):
            errors.append(_error("missing_label_placement_status", "label entries require placement.status"))


def _validate_label_manifest(path: Path, manifest: dict, errors: list[dict]) -> None:
    value = _read_json(path, errors, "label_manifest")
    if not isinstance(value, dict):
        errors.append(_error("invalid_label_manifest", "label manifest must be a JSON object"))
        return
    if value.get("profile") != LABEL_MANIFEST_PROFILE:
        errors.append(_error("unsupported_label_manifest_profile", "label manifest profile is unsupported"))
    if value.get("schema_version") != LABEL_MANIFEST_SCHEMA_VERSION:
        errors.append(_error("unsupported_label_manifest_schema", "label manifest schema_version is unsupported"))
    if value.get("scene_id") not in {None, manifest.get("scene_id")}:
        errors.append(_error("label_manifest_scene_mismatch", "label manifest scene_id must match scene manifest"))
    if value.get("scene_version") not in {None, manifest.get("scene_version")}:
        errors.append(_error("label_manifest_version_mismatch", "label manifest scene_version must match scene manifest"))
    labels = value.get("labels")
    if not isinstance(labels, dict):
        errors.append(_error("invalid_label_manifest_labels", "label manifest labels must be an object"))
        return
    for label_id, override in labels.items():
        if not isinstance(label_id, str) or not label_id:
            errors.append(_error("invalid_label_manifest_label_id", "label manifest label IDs must be non-empty strings"))
            continue
        if not isinstance(override, dict):
            errors.append(_error("invalid_label_manifest_override", f"label manifest override {label_id!r} must be an object"))
            continue
        unsupported = sorted(set(override) - LABEL_MANIFEST_ALLOWED_KEYS)
        if unsupported:
            errors.append(_error("unsupported_label_manifest_key", f"unsupported label manifest keys for {label_id}: {', '.join(unsupported)}"))
        if "anchor_offset_px" in override and not _is_number_pair(override["anchor_offset_px"]):
            errors.append(_error("invalid_label_manifest_anchor_offset", "anchor_offset_px must be [x,y]"))


def _is_number_pair(value: object) -> bool:
    return (
        isinstance(value, list)
        and len(value) == 2
        and all(isinstance(item, int | float) and not isinstance(item, bool) for item in value)
    )


def _validate_style_manifest(root: Path, errors: list[dict], assets: list[dict]) -> None:
    styles_dir = root / "styles"
    manifest_path = _resolve_package_path(
        root,
        "styles/style_manifest.json",
        errors,
        "styles/style_manifest.json",
    )
    if manifest_path is None:
        return
    if not styles_dir.exists() and not manifest_path.exists():
        return
    if not manifest_path.exists():
        errors.append(_error("missing_style_manifest", "styles/style_manifest.json is required when styles are present"))
        return
    value = _read_json(manifest_path, errors, "style_manifest")
    if not isinstance(value, dict):
        errors.append(_error("invalid_style_manifest", "style manifest must be a JSON object"))
        return
    if value.get("profile") != STYLE_MANIFEST_PROFILE:
        errors.append(_error("unsupported_style_profile", "style manifest profile is unsupported"))
    if value.get("schema_version") != STYLE_MANIFEST_SCHEMA_VERSION:
        errors.append(_error("unsupported_style_schema", "style manifest schema_version is unsupported"))
    styles = value.get("styles")
    if not isinstance(styles, list) or not all(isinstance(item, dict) for item in styles):
        errors.append(_error("invalid_style_manifest_styles", "style manifest styles must be an array of objects"))
        return
    assets.append(
        {
            "role": "style_manifest",
            "path": "styles/style_manifest.json",
            "sha256": _sha256(manifest_path),
            "bytes": manifest_path.stat().st_size,
        }
    )
    for index, style in enumerate(styles):
        path = _resolve_package_path(
            root,
            style.get("path"),
            errors,
            f"styles[{index}].path",
        )
        if path is None:
            continue
        if not path.exists():
            errors.append(_error("missing_style_file", f"Missing style file: {path.relative_to(root)}"))
            continue
        expected_sha = style.get("sha256")
        actual_sha = _sha256(path)
        if isinstance(expected_sha, str) and expected_sha and expected_sha != actual_sha:
            errors.append(_error("bad_style_checksum", f"Checksum mismatch for {path.relative_to(root)}"))
        assets.append(
            {
                "role": "style",
                "path": str(path.relative_to(root)),
                "sha256": actual_sha,
                "bytes": path.stat().st_size,
            }
        )


def _resolve_package_path(
    root: Path,
    raw_path: object,
    errors: list[dict],
    label: str,
    *,
    boundary: Path | None = None,
) -> Path | None:
    if not isinstance(raw_path, str) or not raw_path:
        errors.append(_error("invalid_package_path", f"{label} must be a package-relative path"))
        return None
    path = Path(raw_path)
    if path.is_absolute() or ".." in path.parts:
        errors.append(_error("unsafe_package_path", f"{label} must not be absolute or contain '..'"))
        return None
    resolved = root / path
    if resolved.is_symlink():
        errors.append(_error("unsafe_package_path", f"{label} must not be a symlink"))
        return None
    root_real = (boundary or root).resolve()
    try:
        resolved_real = resolved.resolve(strict=False)
    except OSError:
        errors.append(_error("unsafe_package_path", f"{label} could not be resolved safely"))
        return None
    if not resolved_real.is_relative_to(root_real):
        errors.append(_error("unsafe_package_path", f"{label} must stay inside the package root"))
        return None
    return resolved


def _package_roots(root: Path, manifest: dict, errors: list[dict]) -> dict[str, Path]:
    roots = {"scene": root, "core": root, "presentation": root}
    split = manifest.get("package_split")
    if split is None:
        return roots
    if not isinstance(split, dict):
        errors.append(_error("invalid_package_split", "package_split must be an object"))
        return roots
    for role, key in (("core", "core_root"), ("presentation", "presentation_root")):
        raw_path = split.get(key)
        if raw_path is None:
            continue
        resolved = _resolve_package_path(root, raw_path, errors, f"package_split.{key}")
        if resolved is not None:
            roots[role] = resolved
    return roots


def _is_safe_segment(value: str) -> bool:
    if value in {".", ".."}:
        return False
    if "/" in value or "\\" in value:
        return False
    return bool(SAFE_SEGMENT_RE.fullmatch(value))


def _read_json(path: Path, errors: list[dict], label: str) -> Any | None:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append(_error(f"invalid_{label}_json", f"Cannot read {label} JSON: {exc}"))
        return None


def _package_fingerprint(root: Path, manifest: dict, assets: list[dict]) -> str:
    payload = {
        "scene_id": manifest.get("scene_id"),
        "scene_version": manifest.get("scene_version"),
        "scene_fingerprint_sha256": manifest.get("scene_fingerprint_sha256"),
        "assets": sorted(
            [
                {
                    "path": asset["path"],
                    "sha256": asset["sha256"],
                    "bytes": asset["bytes"],
                }
                for asset in assets
            ],
            key=lambda row: row["path"],
        ),
    }
    manifest_path = root / "scene_manifest.json"
    if manifest_path.exists():
        payload["scene_manifest_sha256"] = _sha256(manifest_path)
    data = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def _validation_report(
    metadata: dict,
    assets: list[dict],
    errors: list[dict],
    warnings: list[dict],
) -> dict:
    return {
        "status": "ok" if not errors else "invalid",
        "metadata": metadata,
        "assets": sorted(assets, key=lambda asset: (asset["role"], asset["path"])),
        "asset_count": len(assets),
        "errors": errors,
        "warnings": warnings,
    }


def _error(code: str, message: str) -> dict:
    return {"code": code, "message": message}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()
