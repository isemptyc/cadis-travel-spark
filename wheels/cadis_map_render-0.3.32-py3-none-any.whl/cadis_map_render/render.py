from __future__ import annotations

import json
import math
import os
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

import numpy as np

import cadis_map_render.native as native
from cadis_map_render.image import FloatColor, Image, Mask, float_color
from cadis_map_render.labels import apply_label_pass, labels_enabled
from cadis_map_render.point_glow import (
    ACTIVATION_POINT_CLUSTER,
    ACTIVATION_POINT_MARKER,
    _project_to_pixel,
    render_point_cluster_glow,
)
from cadis_map_render.png_io import read_rgb_png, write_png
from cadis_map_render.semantic_vector import (
    rasterize_semantic_vector_mask,
    sample_semantic_vector_id,
    validate_semantic_vector_sidecar,
)
from cadis_map_render.style_profile import (
    load_bundled_style_profile,
    load_style_profile,
    normalize_style_profile,
    parse_hex_color,
    resolve_style_id,
    style_activation,
    style_base,
    style_id,
    style_tone,
)


MAP_RENDER_PROFILE = "cadis.map_render.render"

SEA = (12, 26, 43)
LAND = (62, 91, 74)
CONTEXT_LAND = (90, 96, 96)
OUTER_BORDER = (207, 224, 214)
INNER_BORDER = (76, 112, 98)
FOCUS_COUNTRY_BORDER = (222, 234, 224)
CONTEXT_BORDER = (116, 128, 124)


def render_map(
    scene_manifest: str | Path,
    request_json: str | Path,
    style_profile: dict | str | Path | None,
    output_png: str | Path,
    *,
    style_manifest: str | Path | None = None,
    label_manifest: str | Path | dict | None = None,
    trace_dir: str | Path | None = None,
    profiling: bool | None = None,
) -> dict:
    """Render a local map image from a packaged prebuilt Cadis scene."""
    return _render_packaged_scene_map(
        scene_manifest,
        request_json,
        output_png,
        style_profile=style_profile,
        style_manifest=style_manifest,
        label_manifest=label_manifest,
        trace_dir=trace_dir,
        profiling=profiling,
        profile=MAP_RENDER_PROFILE,
    )


def _render_packaged_scene_map(
    scene_manifest_path: str | Path,
    request_path: str | Path,
    output_png: str | Path,
    *,
    style_profile: dict | str | Path | None,
    style_manifest: str | Path | None,
    label_manifest: str | Path | dict | None,
    trace_dir: str | Path | None,
    profiling: bool | None,
    profile: str,
) -> dict:
    profiler = _RenderProfiler(_resolve_profiling(profiling))
    with profiler.phase("load_inputs"):
        scene_path = Path(scene_manifest_path)
        scene = _load_scene_manifest(scene_path)
        scene_roots = _scene_package_roots(scene_path, scene)
        request = _load_request(request_path)
        style = _resolve_scene_style(
            request,
            style_profile=style_profile,
            style_manifest=style_manifest,
        )
        activation = style_activation(style)
        activation_mode = str(activation.get("mode", ACTIVATION_POINT_CLUSTER))
        if activation_mode not in {
            ACTIVATION_POINT_CLUSTER,
            ACTIVATION_POINT_MARKER,
            "region_claim",
        }:
            raise ValueError(
                "map rendering supports point_cluster, point_marker, and "
                f"region_claim activation modes, got {activation_mode!r}"
            )

    with profiler.phase("prepare_output"):
        output = Path(output_png)
        output.parent.mkdir(parents=True, exist_ok=True)
        working_base = output.with_suffix(".base.png")
        crop = _resolve_scene_crop(scene, request)
        trace = _RenderTrace(
            _resolve_trace_dir(trace_dir, output),
            renderer_profile=profile,
            scene=scene,
            request=request,
            style=style,
            activation_mode=activation_mode,
            crop=crop,
        )
        render_output = (
            output.with_name(f"{output.stem}.full{output.suffix}")
            if crop is not None
            else output
        )
    with profiler.phase("load_base_image"):
        base_image = _scene_asset_path(scene_roots, scene, "base_image")
        write_png(working_base, read_rgb_png(base_image))
    if trace.enabled:
        with profiler.phase("trace_source_base"):
            trace.capture(
                "00_source_base",
                "Source Base Scene",
                "base",
                "source_base",
                read_rgb_png(working_base),
                inputs=["design_facing.base_image"],
                style_keys=[],
            )
    with profiler.phase("base_profile"):
        _apply_base_profile(working_base, style)
    if trace.enabled:
        with profiler.phase("trace_base_profile"):
            trace.capture(
                "01_base_profile",
                "Base Profile",
                "style_transform",
                "base_profile",
                read_rgb_png(working_base),
                inputs=["design_facing.base_image"],
                style_keys=["base.sea", "base.land", "base.context_land"],
            )
    with profiler.phase("sea_depth_profile"):
        _apply_sea_depth_profile(scene_roots, scene, working_base, style)
    if trace.enabled:
        with profiler.phase("trace_sea_depth"):
            trace.capture(
                "02_sea_depth",
                "Sea Depth",
                "style_transform",
                "sea_depth",
                read_rgb_png(working_base),
                inputs=["semantic_sidecar", "semantic_vector_sidecar"],
                style_keys=["base.sea_depth_*"],
            )
    with profiler.phase("tone_profile"):
        _apply_tone_profile(working_base, style)
    if trace.enabled:
        with profiler.phase("trace_tone"):
            trace.capture(
                "03_tone",
                "Tone",
                "style_transform",
                "tone",
                read_rgb_png(working_base),
                inputs=["design_facing.base_image"],
                style_keys=["tone.*"],
            )
    with profiler.phase("base_boundaries"):
        _apply_base_boundaries(scene_roots, scene, working_base, style)
    if trace.enabled:
        with profiler.phase("trace_base_boundaries"):
            trace.capture(
                "04_base_boundaries",
                "Runtime Boundaries",
                "presentation_overlay",
                "base_boundaries",
                read_rgb_png(working_base),
                inputs=["semantic_sidecar", "semantic_vector_sidecar", "claim_semantic_sidecars"],
                style_keys=["base.outer_border_*", "base.inner_border_*"],
            )
    with profiler.phase("activation"):
        bounds = tuple(float(value) for value in scene["bounds"])
        projection = str(scene["projection"])
        if activation_mode == "region_claim":
            country_activation = _request_country_activation(request)
            admin_region_levels = _request_admin_region_levels(request)
            if country_activation and admin_region_levels is None:
                admin_region_levels = _default_country_activation_admin_region_levels(scene)
            region_levels = _request_region_levels(request)
            claim_levels = _request_claim_levels(request)
            render_report = _render_region_claim(
                scene_roots,
                scene,
                request,
                working_base,
                render_output,
                style=activation,
                bounds=bounds,
                projection=projection,
                country_activation=country_activation,
                admin_region_levels=admin_region_levels,
                region_levels=region_levels,
                claim_levels=claim_levels,
            )
        else:
            render_report = render_point_cluster_glow(
                working_base,
                request_path,
                render_output,
                bounds=bounds,
                projection=projection,
                cluster_radius_km=float(activation.get("cluster_radius_km", 5.0)),
                activation_mode=activation_mode,
                min_glow_radius_px=float(activation.get("min_glow_radius_px", 24.0)),
                max_glow_radius_px=float(activation.get("max_glow_radius_px", 120.0)),
                glow_color=str(activation.get("glow_color", "#ffc556")),
                marker_color=str(activation.get("marker_color", "#fff4c2")),
                marker_outline_color=str(activation.get("marker_outline_color", "#5a3b10")),
                marker_min_radius_px=float(activation.get("marker_min_radius_px", 4.0)),
                marker_max_radius_px=float(activation.get("marker_max_radius_px", 14.0)),
                halo_alpha=float(activation.get("halo_alpha", 0.62)),
                core_alpha=float(activation.get("core_alpha", 0.42)),
                max_alpha=float(activation.get("max_alpha", 0.86)),
            )
    if trace.enabled:
        with profiler.phase("trace_activation"):
            trace.capture(
                "05_activation",
                "Semantic Activation",
                "semantic_overlay",
                "activation",
                read_rgb_png(render_output),
                inputs=["request.places", "semantic_sidecar", "semantic_vector_sidecar"],
                style_keys=["activation.*"],
            )
    label_count = 0
    label_metadata = {"label_manifest_source": "none"}
    with profiler.phase("labels"):
        if labels_enabled(style):
            labeled_output, label_count, label_metadata = apply_label_pass(
                read_rgb_png(render_output),
                scene_dir=scene_path.parent,
                package_roots=scene_roots,
                scene=scene,
                style=style,
                crop_box=None if crop is None else crop["crop_box"],
                external_label_manifest=label_manifest,
            )
            if label_count > 0:
                write_png(render_output, labeled_output)
                if trace.enabled:
                    trace.capture(
                        "06_labels",
                        "Labels",
                        "label_overlay",
                        "labels",
                        labeled_output,
                        inputs=["label_sidecar", "label_manifest"],
                        style_keys=["labels.*"],
                    )
    with profiler.phase("crop"):
        if crop is not None:
            _crop_png(render_output, output, crop["crop_box"])
            _crop_png(working_base, working_base, crop["crop_box"])
            if render_output != output and render_output.exists():
                render_output.unlink()
    with profiler.phase("read_output_metadata"):
        output_image = read_rgb_png(output)
        report_bounds = crop["bounds"] if crop is not None else [
            float(value) for value in scene["bounds"]
        ]
    if trace.enabled:
        with profiler.phase("trace_final_capture"):
            trace.capture(
                "99_final",
                "Final Composite",
                "final",
                "final",
                output_image,
                inputs=["render_output"],
                style_keys=[],
            )
    with profiler.phase("trace_write"):
        trace_manifest = trace.write(output=output, bounds=report_bounds)
    with profiler.phase("assemble_report"):
        report = {
            "status": "ok",
            "profile": profile,
            "scene_manifest": str(scene_path),
            "scene_id": scene["scene_id"],
            "scene_version": scene["scene_version"],
            "request": str(Path(request_path)),
            "output_png": str(output),
            "base_png": str(working_base),
            "style_id": style_id(style),
            "requested_style_id": _request_style_id(request),
            "activation_mode": activation_mode,
            "bounds": report_bounds,
            "scene_bounds": [float(value) for value in scene["bounds"]],
            "projection": str(scene["projection"]),
            "width": int(output_image.width),
            "height": int(output_image.height),
            "source_width": int(scene["width"]),
            "source_height": int(scene["height"]),
            **({} if trace_manifest is None else {"trace_manifest": str(trace_manifest)}),
            **(
                {}
                if crop is None
                else {
                    "crop_source": crop["source"],
                    "crop_policy_profile": crop["profile"],
                    "crop_bounds": crop["bounds"],
                    "crop_box": crop["crop_box"],
                }
            ),
            "source_point_count": int(render_report["source_point_count"]),
            "located_point_count": int(render_report["located_point_count"]),
            "cluster_count": int(render_report["cluster_count"]),
            "located_density_weight": render_report["located_density_weight"],
            "rendered_label_count": int(label_count),
            **label_metadata,
            **(
                {}
                if render_report.get("source_selected_region_count") is None
                else {
                    "source_selected_region_count": int(render_report["source_selected_region_count"]),
                    "located_selected_region_count": int(render_report["located_selected_region_count"]),
                }
            ),
            **(
                {}
                if render_report.get("country_activation") is None
                else {"country_activation": bool(render_report["country_activation"])}
            ),
            **(
                {}
                if render_report.get("requested_admin_region_levels") is None
                else {
                    "requested_admin_region_levels": list(render_report["requested_admin_region_levels"]),
                    "admin_region_levels_applied": list(render_report["admin_region_levels_applied"]),
                }
            ),
            **(
                {}
                if render_report.get("requested_region_levels") is None
                else {
                    "requested_region_levels": list(render_report["requested_region_levels"]),
                    "region_levels_applied": list(render_report["region_levels_applied"]),
                }
            ),
            **(
                {}
                if render_report.get("requested_claim_levels") is None
                else {
                    "requested_claim_levels": list(render_report["requested_claim_levels"]),
                    "claim_levels_applied": list(render_report["claim_levels_applied"]),
                }
            ),
        }
    profile_report = profiler.report()
    if profile_report is not None:
        report["render_profile"] = profile_report
    return report


class _RenderProfiler:
    def __init__(self, enabled: bool):
        self.enabled = enabled
        self.started = time.perf_counter()
        self.phases: list[dict[str, object]] = []

    @contextmanager
    def phase(self, name: str) -> Iterator[None]:
        if not self.enabled:
            yield
            return
        started = time.perf_counter()
        try:
            yield
        finally:
            ended = time.perf_counter()
            self.phases.append(
                {
                    "name": name,
                    "seconds": round(ended - started, 6),
                }
            )

    def report(self) -> dict | None:
        if not self.enabled:
            return None
        total = time.perf_counter() - self.started
        return {
            "profile": "cadis.map_render.profile",
            "schema_version": 1,
            "total_seconds": round(total, 6),
            "phases": list(self.phases),
        }


class _RenderTrace:
    def __init__(
        self,
        trace_dir: str | Path | None,
        *,
        renderer_profile: str,
        scene: dict,
        request: dict,
        style: dict,
        activation_mode: str,
        crop: dict | None,
    ):
        self.trace_dir = None if trace_dir is None else Path(trace_dir)
        self.renderer_profile = renderer_profile
        self.scene = scene
        self.request = request
        self.style = style
        self.activation_mode = activation_mode
        self.crop = crop
        self.layers: list[dict] = []

    @property
    def enabled(self) -> bool:
        return self.trace_dir is not None

    def capture(
        self,
        layer_id: str,
        name: str,
        kind: str,
        source_pass: str,
        image: Image,
        *,
        inputs: list[str],
        style_keys: list[str],
        blend_mode: str = "normal",
        opacity: int = 100,
        visible: bool = True,
    ) -> None:
        if self.trace_dir is None:
            return
        self.layers.append(
            {
                "id": layer_id,
                "name": name,
                "kind": kind,
                "path": f"layers/{layer_id}.png",
                "blend_mode": blend_mode,
                "opacity": int(opacity),
                "visible": bool(visible),
                "source_pass": source_pass,
                "inputs": list(inputs),
                "style_keys": list(style_keys),
                "_image": image.copy(),
            }
        )

    def write(self, *, output: Path, bounds: list[float]) -> Path | None:
        if self.trace_dir is None:
            return None
        layers_dir = self.trace_dir / "layers"
        layers_dir.mkdir(parents=True, exist_ok=True)
        manifest_layers = []
        crop_box = self.crop["crop_box"] if self.crop is not None else None
        for layer in self.layers:
            image = layer["_image"]
            if crop_box is not None and layer["id"] != "99_final":
                image = _crop_image(image, crop_box)
            manifest_layer = {key: value for key, value in layer.items() if key != "_image"}
            path = self.trace_dir / manifest_layer["path"]
            write_png(path, image)
            manifest_layers.append(manifest_layer)
        final_image = read_rgb_png(output)
        manifest = {
            "profile": "cadis.map_render.trace",
            "schema_version": 1,
            "renderer_profile": self.renderer_profile,
            "scene_id": self.scene["scene_id"],
            "scene_version": self.scene["scene_version"],
            "style_id": style_id(self.style),
            "requested_style_id": _request_style_id(self.request),
            "activation_mode": self.activation_mode,
            "width": int(final_image.width),
            "height": int(final_image.height),
            "bounds": list(bounds),
            "scene_bounds": [float(value) for value in self.scene["bounds"]],
            "crop": None if self.crop is None else {
                "source": self.crop["source"],
                "profile": self.crop["profile"],
                "bounds": self.crop["bounds"],
                "crop_box": self.crop["crop_box"],
            },
            "layers": manifest_layers,
            "final_output": str(output),
        }
        manifest_path = self.trace_dir / "render_trace.json"
        manifest_path.write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        return manifest_path


def _resolve_trace_dir(trace_dir: str | Path | None, output: Path) -> Path | None:
    if trace_dir is not None:
        return Path(trace_dir)
    trace_dir_env = os.environ.get("CADIS_MAP_RENDER_TRACE_DIR")
    if trace_dir_env:
        return Path(trace_dir_env)
    trace_enabled = os.environ.get("CADIS_MAP_RENDER_TRACE", "")
    if trace_enabled.strip().lower() in {"1", "true", "yes", "on"}:
        return output.with_suffix(".trace")
    return None


def _resolve_profiling(value: bool | None) -> bool:
    if value is not None:
        return bool(value)
    normalized = os.environ.get("CADIS_MAP_RENDER_PROFILE", "").strip().lower()
    return normalized in {"1", "true", "yes", "on"}


def _render_region_claim(
    scene_roots: dict[str, Path],
    scene: dict,
    request: dict,
    base_png: Path,
    output_png: Path,
    *,
    style: dict,
    bounds: tuple[float, float, float, float],
    projection: str,
    country_activation: bool,
    admin_region_levels: list[int] | None,
    region_levels: list[int] | None,
    claim_levels: list[int] | None,
) -> dict:
    base = read_rgb_png(base_png)
    presentation_semantic = _load_region_claim_semantic(
        scene_roots,
        scene,
        base_shape=(base.height, base.width),
    )
    claim_semantics = _load_claim_level_semantics(
        scene_roots,
        scene,
        base_shape=(base.height, base.width),
        claim_levels=claim_levels or [],
    )
    region_semantics = _load_claim_level_semantics(
        scene_roots,
        scene,
        base_shape=(base.height, base.width),
        claim_levels=region_levels or [],
    )
    admin_region_semantics = _load_claim_level_semantics(
        scene_roots,
        scene,
        base_shape=(base.height, base.width),
        claim_levels=admin_region_levels or [],
    )
    points = _request_points(request)
    selected_regions = _request_selected_regions(request)
    country_weights_by_source: dict[tuple[str, int], dict[int, int]] = {}
    admin_region_weights_by_source: dict[tuple[str, int], dict[int, int]] = {}
    claim_weights_by_source: dict[tuple[str, int], dict[int, int]] = {}
    region_weights_by_source: dict[tuple[str, int], dict[int, int]] = {}
    located_density_weight = 0
    located_point_count = 0
    located_selected_region_count = 0
    presentation_ids = presentation_semantic.semantic_ids()
    if selected_regions:
        claim_weights = claim_weights_by_source.setdefault(("presentation", 0), {})
        for selected in selected_regions:
            semantic_id = int(selected["semantic_id"])
            weight = max(1.0, float(selected.get("weight", 1)))
            if semantic_id not in presentation_ids:
                continue
            claim_weights[semantic_id] = claim_weights.get(semantic_id, 0) + weight
            located_density_weight += weight
            located_selected_region_count += 1
    for point in points:
        x, y = _project_to_pixel(
            point["lon"],
            point["lat"],
            bounds=bounds,
            projection=projection,
            width=presentation_semantic.width,
            height=presentation_semantic.height,
        )
        if x < 0 or y < 0 or x >= presentation_semantic.width or y >= presentation_semantic.height:
            continue
        weight = max(1, int(point.get("weight", 1)))
        point_located = False
        if country_activation:
            country_semantic_id = presentation_semantic.sample(x=x, y=y)
            if country_semantic_id != 0:
                country_weights = country_weights_by_source.setdefault(("presentation", 0), {})
                country_weights[country_semantic_id] = (
                    country_weights.get(country_semantic_id, 0) + weight
                )
                point_located = True
        if admin_region_levels:
            admin_source_key: tuple[str, int] | None = None
            admin_semantic_id = 0
            for admin_region_level, admin_region_semantic in admin_region_semantics:
                sampled_id = admin_region_semantic.sample(x=x, y=y)
                if sampled_id != 0:
                    admin_source_key = ("admin_region", admin_region_level)
                    admin_semantic_id = sampled_id
                    break
            if admin_source_key is not None and admin_semantic_id != 0:
                admin_region_weights = admin_region_weights_by_source.setdefault(admin_source_key, {})
                admin_region_weights[admin_semantic_id] = (
                    admin_region_weights.get(admin_semantic_id, 0) + weight
                )
                point_located = True
        claim_source_key: tuple[str, int] | None = None
        claim_semantic_id = 0
        for claim_level, claim_semantic in claim_semantics:
            sampled_id = claim_semantic.sample(x=x, y=y)
            if sampled_id != 0:
                claim_source_key = ("claim", claim_level)
                claim_semantic_id = sampled_id
                break
        if claim_semantic_id == 0 and not country_activation:
            claim_source_key = ("presentation", 0)
            claim_semantic_id = presentation_semantic.sample(x=x, y=y)
        if claim_source_key is not None and claim_semantic_id != 0:
            claim_weights = claim_weights_by_source.setdefault(claim_source_key, {})
            claim_weights[claim_semantic_id] = (
                claim_weights.get(claim_semantic_id, 0) + weight
            )
            point_located = True
        if not point_located:
            continue
        if region_levels:
            region_source_key: tuple[str, int] = ("presentation", 0)
            region_semantic_id = 0
            for region_level, region_semantic in region_semantics:
                sampled_id = region_semantic.sample(x=x, y=y)
                if sampled_id != 0:
                    region_source_key = ("region", region_level)
                    region_semantic_id = sampled_id
                    break
            if region_semantic_id == 0:
                region_semantic_id = presentation_semantic.sample(x=x, y=y)
            if region_semantic_id != 0:
                region_weights = region_weights_by_source.setdefault(region_source_key, {})
                region_weights[region_semantic_id] = (
                    region_weights.get(region_semantic_id, 0) + weight
                )
        located_density_weight += weight
        located_point_count += 1
    semantics_by_source = {("presentation", 0): presentation_semantic}
    semantics_by_source.update({("claim", level): semantic for level, semantic in claim_semantics})
    semantics_by_source.update({("region", level): semantic for level, semantic in region_semantics})
    semantics_by_source.update({("admin_region", level): semantic for level, semantic in admin_region_semantics})
    claim_activation = _build_region_activation_masks(
        base.width,
        base.height,
        weights_by_source=claim_weights_by_source,
        semantics_by_source=semantics_by_source,
    )
    output = base
    if country_activation:
        country_activation_masks = _build_region_activation_masks(
            base.width,
            base.height,
            weights_by_source=country_weights_by_source,
            semantics_by_source=semantics_by_source,
        )
        output = _apply_region_glow(
            output,
            country_activation_masks["active_mask"],
            active_border_mask=country_activation_masks["active_border_mask"],
            style=_active_country_style(style),
            region_masks=country_activation_masks["region_masks"],
            region_weights=country_activation_masks["region_weights"],
        )
    if admin_region_levels:
        admin_region_activation = _build_region_activation_masks(
            base.width,
            base.height,
            weights_by_source=admin_region_weights_by_source,
            semantics_by_source=semantics_by_source,
        )
        output = _apply_region_glow(
            output,
            admin_region_activation["active_mask"],
            active_border_mask=admin_region_activation["active_border_mask"],
            style=_active_claim_style(style),
            region_masks=admin_region_activation["region_masks"],
            region_weights=admin_region_activation["region_weights"],
        )
    if region_levels:
        middle_activation = _build_region_activation_masks(
            base.width,
            base.height,
            weights_by_source=region_weights_by_source,
            semantics_by_source=semantics_by_source,
        )
        output = _apply_region_glow(
            output,
            middle_activation["active_mask"],
            active_border_mask=middle_activation["active_border_mask"],
            style=_active_admin_region_style(style),
            region_masks=middle_activation["region_masks"],
            region_weights=middle_activation["region_weights"],
        )
    output = _apply_region_glow(
        output,
        claim_activation["active_mask"],
        active_border_mask=claim_activation["active_border_mask"],
        style=_active_claim_style(style),
        region_masks=claim_activation["region_masks"],
        region_weights=claim_activation["region_weights"],
    )
    write_png(output_png, output)
    applied_region_levels = [
        level
        for level in (region_levels or [])
        if ("region", level) in region_weights_by_source
    ]
    applied_claim_levels = [
        level
        for level in (claim_levels or [])
        if ("claim", level) in claim_weights_by_source
    ]
    applied_admin_region_levels = [
        level
        for level in (admin_region_levels or [])
        if ("admin_region", level) in admin_region_weights_by_source
    ]
    report = {
        "cluster_count": len(claim_activation["region_weights"]),
        "located_density_weight": located_density_weight,
        "source_point_count": len(points),
        "located_point_count": located_point_count,
    }
    if selected_regions:
        report["source_selected_region_count"] = len(selected_regions)
        report["located_selected_region_count"] = located_selected_region_count
    if country_activation:
        report["country_activation"] = True
        report["cluster_count"] = len(country_weights_by_source.get(("presentation", 0), {}))
    if admin_region_levels is not None:
        report["requested_admin_region_levels"] = admin_region_levels
        report["admin_region_levels_applied"] = applied_admin_region_levels
    if region_levels is not None:
        report["requested_region_levels"] = region_levels
        report["region_levels_applied"] = applied_region_levels
    if claim_levels is not None:
        report["requested_claim_levels"] = claim_levels
        report["claim_levels_applied"] = applied_claim_levels
    return report


def _build_region_activation_masks(
    width: int,
    height: int,
    *,
    weights_by_source: dict[tuple[str, int], dict[int, int]],
    semantics_by_source: dict[
        tuple[str, int],
        _RasterRegionClaimSemantic | _VectorRegionClaimSemantic,
    ],
) -> dict[str, object]:
    active_mask = Mask.empty(width, height)
    active_border_mask = Mask.empty(width, height)
    region_masks: dict[int, Mask] = {}
    region_weights: dict[int, int] = {}
    next_region_key = 1
    for source_key in sorted(weights_by_source, key=lambda item: (item[0], item[1])):
        semantic = semantics_by_source[source_key]
        active_semantic_ids = set(weights_by_source[source_key])
        source_mask = semantic.mask(active_semantic_ids)
        source_border = semantic.border_mask(source_mask, active_semantic_ids)
        _or_mask(active_mask, source_mask)
        _or_mask(active_border_mask, source_border)
        for scene_semantic_id, weight in sorted(weights_by_source[source_key].items()):
            region_masks[next_region_key] = semantic.mask({scene_semantic_id})
            region_weights[next_region_key] = weight
            next_region_key += 1
    return {
        "active_mask": active_mask,
        "active_border_mask": active_border_mask,
        "region_masks": region_masks,
        "region_weights": region_weights,
    }


def _resolve_scene_crop(scene: dict, request: dict) -> dict | None:
    requested_bounds = request.get("crop_bounds")
    if requested_bounds is not None:
        requested_profile = request.get("truncate_bounds_profile", request.get("crop_profile"))
        if requested_profile is not None:
            raise ValueError("crop_bounds cannot be combined with crop_profile")
        bounds = _bounds(requested_bounds, label="crop_bounds")
        scene_bounds = tuple(float(value) for value in scene["bounds"])
        projection = str(scene["projection"])
        crop_box = _crop_box_for_bounds(
            scene_bounds=scene_bounds,
            crop_bounds=tuple(bounds),
            projection=projection,
            width=int(scene["width"]),
            height=int(scene["height"]),
        )
        return {
            "profile": None,
            "source": "request_bounds",
            "bounds": bounds,
            "crop_box": list(crop_box),
        }
    crop_policy = scene.get("crop_policy")
    if not isinstance(crop_policy, dict):
        return None
    profiles = crop_policy.get("truncate_bounds_profiles")
    requested_profile = request.get("truncate_bounds_profile", request.get("crop_profile"))
    profile = requested_profile or crop_policy.get("default_truncate_bounds_profile")
    if profile is not None:
        if not isinstance(profile, str) or not profile:
            raise ValueError("crop profile must be a non-empty string")
        if not isinstance(profiles, dict) or profile not in profiles:
            raise ValueError(f"scene crop_policy has no truncate bounds profile {profile!r}")
        bounds = _bounds(profiles[profile], label=f"crop_policy.{profile}")
    else:
        profile = None
        bounds = _bounds(crop_policy.get("truncate_bounds"), label="crop_policy.truncate_bounds")
    scene_bounds = tuple(float(value) for value in scene["bounds"])
    projection = str(scene["projection"])
    crop_box = _crop_box_for_bounds(
        scene_bounds=scene_bounds,
        crop_bounds=tuple(bounds),
        projection=projection,
        width=int(scene["width"]),
        height=int(scene["height"]),
    )
    return {
        "profile": profile,
        "source": "scene_crop_policy",
        "bounds": bounds,
        "crop_box": list(crop_box),
    }


def _bounds(value: object, *, label: str) -> list[float]:
    if not isinstance(value, list) or len(value) != 4:
        raise ValueError(f"{label} must be [min_lon,min_lat,max_lon,max_lat]")
    bounds = [float(item) for item in value]
    minx, miny, maxx, maxy = bounds
    if minx >= maxx or miny >= maxy:
        raise ValueError(f"{label} must have increasing min/max values")
    return bounds


def _crop_box_for_bounds(
    *,
    scene_bounds: tuple[float, float, float, float],
    crop_bounds: tuple[float, float, float, float],
    projection: str,
    width: int,
    height: int,
) -> tuple[int, int, int, int]:
    crop_min_lon, crop_min_lat, crop_max_lon, crop_max_lat = crop_bounds
    left, bottom = _project_to_pixel(
        crop_min_lon,
        crop_min_lat,
        bounds=scene_bounds,
        projection=projection,
        width=width,
        height=height,
    )
    right, top = _project_to_pixel(
        crop_max_lon,
        crop_max_lat,
        bounds=scene_bounds,
        projection=projection,
        width=width,
        height=height,
    )
    left_px = math.floor(left)
    right_px = math.ceil(right)
    top_px = math.floor(top)
    bottom_px = math.ceil(bottom)
    if left_px < 0 or top_px < 0 or right_px > width or bottom_px > height:
        raise ValueError("crop_policy truncate_bounds must be inside scene bounds")
    left_px = max(0, min(width - 1, left_px))
    top_px = max(0, min(height - 1, top_px))
    right_px = max(left_px + 1, min(width, right_px))
    bottom_px = max(top_px + 1, min(height, bottom_px))
    return (left_px, top_px, right_px, bottom_px)


def _crop_png(source: Path, output: Path, crop_box: list[int]) -> None:
    image = read_rgb_png(source)
    write_png(output, _crop_image(image, crop_box))


def _crop_image(image: Image, crop_box: list[int]) -> Image:
    left, top, right, bottom = crop_box
    crop = Image.new(right - left, bottom - top, image.channels)
    crop_stride = crop.width * crop.channels
    for row in range(crop.height):
        source_start = ((top + row) * image.width + left) * image.channels
        crop_start = row * crop_stride
        crop.data[crop_start : crop_start + crop_stride] = image.data[
            source_start : source_start + crop_stride
        ]
    return crop


class _VectorRegionClaimSemantic:
    def __init__(self, sidecar: dict):
        self.sidecar = sidecar
        self.width = int(sidecar["width"])
        self.height = int(sidecar["height"])

    def sample(self, *, x: float, y: float) -> int:
        return sample_semantic_vector_id(self.sidecar, x=x, y=y)

    def mask(self, active_semantic_ids: set[int]) -> Mask:
        return rasterize_semantic_vector_mask(self.sidecar, active_semantic_ids)

    def border_mask(self, active_mask: Mask, active_semantic_ids: set[int]) -> Mask:
        border = _outer_borders(active_mask)
        outer = self.scene_outer_border_mask()
        for scene_semantic_id in active_semantic_ids:
            region_border = _outer_borders(self.mask({scene_semantic_id}))
            for offset, value in enumerate(region_border.data):
                if value and active_mask.data[offset] and not outer.data[offset]:
                    border.data[offset] = 1
        return border

    def scene_outer_border_mask(self) -> Mask:
        return _outer_borders(self.scene_mask())

    def scene_inner_border_mask(self) -> Mask:
        outer = self.scene_outer_border_mask()
        inner = Mask.empty(self.width, self.height)
        for scene_semantic_id in self.semantic_ids():
            region_border = _outer_borders(self.mask({scene_semantic_id}))
            for offset, value in enumerate(region_border.data):
                if value and not outer.data[offset]:
                    inner.data[offset] = 1
        return inner

    def scene_mask(self) -> Mask:
        return self.mask(self.semantic_ids())

    def semantic_ids(self) -> set[int]:
        return {
            int(region["scene_semantic_id"])
            for region in self.sidecar.get("regions", [])
            if int(region.get("scene_semantic_id", 0)) > 0
        }


class _RasterRegionClaimSemantic:
    def __init__(self, raster: np.ndarray):
        if raster.dtype != np.uint32:
            raise ValueError("scene semantic sidecar dtype must be uint32")
        if raster.ndim != 2:
            raise ValueError("scene semantic sidecar must be a 2D array")
        self.raster = raster
        self.height = int(raster.shape[0])
        self.width = int(raster.shape[1])

    def sample(self, *, x: float, y: float) -> int:
        col = int(x)
        row = int(y)
        if row < 0 or col < 0 or row >= self.height or col >= self.width:
            return 0
        return int(self.raster[row, col])

    def mask(self, active_semantic_ids: set[int]) -> Mask:
        mask = Mask.empty(self.width, self.height)
        if not active_semantic_ids:
            return mask
        active = np.isin(self.raster, np.array(sorted(active_semantic_ids), dtype=np.uint32))
        mask.data[:] = active.astype(np.uint8, copy=False).tobytes()
        return mask

    def border_mask(self, active_mask: Mask, active_semantic_ids: set[int]) -> Mask:
        border = _outer_borders(active_mask)
        if not active_semantic_ids:
            return border
        active = active_mask.array.astype(bool, copy=False)
        raster = self.raster
        borders = np.zeros(raster.shape, dtype=bool)
        borders[1:, :] |= active[1:, :] & active[:-1, :] & (raster[1:, :] != raster[:-1, :])
        borders[:-1, :] |= active[:-1, :] & active[1:, :] & (raster[:-1, :] != raster[1:, :])
        borders[:, 1:] |= active[:, 1:] & active[:, :-1] & (raster[:, 1:] != raster[:, :-1])
        borders[:, :-1] |= active[:, :-1] & active[:, 1:] & (raster[:, :-1] != raster[:, 1:])
        border.array[:] |= borders.astype(np.uint8, copy=False)
        return border

    def scene_outer_border_mask(self) -> Mask:
        return _outer_borders(self.scene_mask())

    def scene_inner_border_mask(self) -> Mask:
        raster = self.raster
        land = raster != 0
        borders = np.zeros(raster.shape, dtype=bool)
        borders[1:, :] |= land[1:, :] & land[:-1, :] & (raster[1:, :] != raster[:-1, :])
        borders[:-1, :] |= land[:-1, :] & land[1:, :] & (raster[:-1, :] != raster[1:, :])
        borders[:, 1:] |= land[:, 1:] & land[:, :-1] & (raster[:, 1:] != raster[:, :-1])
        borders[:, :-1] |= land[:, :-1] & land[:, 1:] & (raster[:, :-1] != raster[:, 1:])
        return _mask_from_bool_array(borders)

    def scene_mask(self) -> Mask:
        return _mask_from_bool_array(self.raster != 0)

    def semantic_ids(self) -> set[int]:
        return {
            int(value)
            for value in np.unique(self.raster)
            if int(value) > 0
        }


def _load_region_claim_semantic(
    scene_roots: dict[str, Path],
    scene: dict,
    *,
    base_shape: tuple[int, int],
) -> _RasterRegionClaimSemantic | _VectorRegionClaimSemantic:
    raster_path = _scene_semantic_path(scene_roots, scene, "semantic_sidecar", required=False)
    if raster_path is not None:
        if raster_path.suffix != ".npy":
            raise ValueError("design_facing.semantic_sidecar must be a .npy asset")
        semantic = _RasterRegionClaimSemantic(np.load(raster_path, allow_pickle=False, mmap_mode="r"))
        if (semantic.height, semantic.width) != base_shape:
            raise ValueError("scene semantic sidecar dimensions do not match base image")
        return semantic

    sidecar_path = _scene_semantic_path(scene_roots, scene, "semantic_vector_sidecar", required=True)
    if sidecar_path.suffix != ".json":
        raise ValueError("region_claim requires design_facing.semantic_vector_sidecar JSON")
    sidecar = _load_json(sidecar_path)
    if (int(sidecar.get("height", -1)), int(sidecar.get("width", -1))) != base_shape:
        raise ValueError("scene semantic vector sidecar dimensions do not match base image")
    validation_errors = validate_semantic_vector_sidecar(
        sidecar,
        width=base_shape[1],
        height=base_shape[0],
    )
    if validation_errors:
        raise ValueError(f"invalid semantic vector sidecar: {validation_errors[0]}")
    return _VectorRegionClaimSemantic(sidecar)


def _load_claim_level_semantics(
    scene_roots: dict[str, Path],
    scene: dict,
    *,
    base_shape: tuple[int, int],
    claim_levels: list[int],
) -> list[tuple[int, _RasterRegionClaimSemantic]]:
    if not claim_levels:
        return []
    design = scene.get("design_facing")
    if not isinstance(design, dict):
        return []
    claim_sidecars = design.get("claim_semantic_sidecars")
    if not isinstance(claim_sidecars, dict):
        return []
    semantics: list[tuple[int, _RasterRegionClaimSemantic]] = []
    for claim_level in claim_levels:
        sidecar = claim_sidecars.get(str(claim_level))
        if not isinstance(sidecar, dict):
            continue
        try:
            resolved = _resolve_design_asset_path(scene_roots, sidecar, "claim_semantic_sidecars")
        except ValueError:
            continue
        if not resolved.exists() or resolved.suffix != ".npy":
            continue
        try:
            semantic = _RasterRegionClaimSemantic(
                np.load(resolved, allow_pickle=False, mmap_mode="r")
            )
        except Exception:
            continue
        if (semantic.height, semantic.width) != base_shape:
            continue
        semantics.append((claim_level, semantic))
    return semantics


def _load_optional_region_claim_semantic(
    scene_roots: dict[str, Path],
    scene: dict,
    *,
    base_shape: tuple[int, int],
) -> _RasterRegionClaimSemantic | _VectorRegionClaimSemantic | None:
    raster_path = _scene_semantic_path(scene_roots, scene, "semantic_sidecar", required=False)
    vector_path = _scene_semantic_path(
        scene_roots,
        scene,
        "semantic_vector_sidecar",
        required=False,
    )
    if raster_path is None and vector_path is None:
        return None
    semantic = _load_region_claim_semantic(
        scene_roots,
        scene,
        base_shape=base_shape,
    )
    return semantic


def _load_claim_boundary_semantic(
    scene_roots: dict[str, Path],
    scene: dict,
    *,
    base_shape: tuple[int, int],
    presentation_semantic: _RasterRegionClaimSemantic | _VectorRegionClaimSemantic,
) -> _RasterRegionClaimSemantic | None:
    claim_semantics = _load_claim_level_semantics(
        scene_roots,
        scene,
        base_shape=base_shape,
        claim_levels=_scene_claim_levels(scene),
    )
    if not claim_semantics:
        return None
    focus_mask = _selectable_country_mask(
        scene_roots,
        scene,
        base_shape=base_shape,
        presentation_semantic=presentation_semantic,
    )
    if focus_mask is None:
        return None
    coalesced = np.zeros(base_shape, dtype=np.uint32)
    semantic_offset = 1
    for _, semantic in claim_semantics:
        source = semantic.raster
        present = (coalesced == 0) & focus_mask & (source != 0)
        if np.any(present):
            coalesced[present] = source[present] + semantic_offset
        semantic_offset += int(source.max(initial=0)) + 1
    if isinstance(presentation_semantic, _RasterRegionClaimSemantic):
        source = presentation_semantic.raster
        present = (coalesced == 0) & (source != 0)
        if np.any(present):
            coalesced[present] = source[present] + semantic_offset
    return _RasterRegionClaimSemantic(coalesced)


def _selectable_country_mask(
    scene_roots: dict[str, Path],
    scene: dict,
    *,
    base_shape: tuple[int, int],
    presentation_semantic: _RasterRegionClaimSemantic | _VectorRegionClaimSemantic,
) -> np.ndarray | None:
    selectable = {
        str(value).upper()
        for value in scene.get("selectable_countries", [])
        if isinstance(value, str) and value
    }
    if not selectable or not isinstance(presentation_semantic, _RasterRegionClaimSemantic):
        return None
    feature_index_path = _scene_semantic_path(scene_roots, scene, "feature_index", required=False)
    if feature_index_path is None:
        return None
    try:
        feature_index = _load_json(feature_index_path)
    except Exception:
        return None
    rows = feature_index.get("features_by_scene_semantic_id")
    if not isinstance(rows, dict):
        return None
    selectable_ids = {
        int(scene_semantic_id)
        for scene_semantic_id, row in rows.items()
        if isinstance(row, dict) and str(row.get("country_iso", "")).upper() in selectable
    }
    if not selectable_ids:
        return None
    mask = np.isin(
        presentation_semantic.raster,
        np.array(sorted(selectable_ids), dtype=np.uint32),
    )
    if mask.shape != base_shape:
        return None
    return mask


def _scene_claim_levels(scene: dict) -> list[int]:
    renderer = scene.get("cadis_internal", {}).get("renderer", {})
    raw_levels = renderer.get("activation_claim_levels") if isinstance(renderer, dict) else None
    levels: list[int] = []
    if isinstance(raw_levels, list):
        for item in raw_levels:
            if isinstance(item, bool) or not isinstance(item, int) or item <= 0:
                continue
            if item not in levels:
                levels.append(item)
    if levels:
        return levels
    design = scene.get("design_facing")
    claim_sidecars = design.get("claim_semantic_sidecars") if isinstance(design, dict) else None
    if not isinstance(claim_sidecars, dict):
        return []
    return sorted(
        int(level)
        for level in claim_sidecars
        if isinstance(level, str) and level.isdigit() and int(level) > 0
    )


def _apply_base_boundaries(
    scene_roots: dict[str, Path],
    scene: dict,
    base_png: Path,
    style: dict,
) -> None:
    boundary_style = _base_boundary_style(style)
    if not boundary_style["enabled"]:
        return
    base = read_rgb_png(base_png)
    semantic = _load_optional_region_claim_semantic(
        scene_roots,
        scene,
        base_shape=(base.height, base.width),
    )
    if semantic is None:
        return
    if (semantic.height, semantic.width) != (base.height, base.width):
        raise ValueError("scene semantic sidecar dimensions do not match base image")
    inner_semantic = _load_claim_boundary_semantic(
        scene_roots,
        scene,
        base_shape=(base.height, base.width),
        presentation_semantic=semantic,
    ) or semantic

    output = _apply_scene_boundaries(
        base,
        outer_border_mask=semantic.scene_outer_border_mask(),
        inner_border_mask=inner_semantic.scene_inner_border_mask(),
        style=boundary_style,
    )
    write_png(base_png, output)


def _base_boundary_style(style: dict) -> dict:
    base = style_base(style)
    outer_width = float(base.get("outer_border_width_px", 0.0))
    inner_width = float(base.get("inner_border_width_px", 0.0))
    return {
        "enabled": outer_width > 0 or inner_width > 0,
        "outer_border_color": base.get("outer_border", "#aeadad"),
        "outer_border_alpha": float(base.get("outer_border_alpha", 1.0)),
        "outer_border_width_px": outer_width,
        "inner_border_color": base.get("inner_border", "#dedede"),
        "inner_border_alpha": float(base.get("inner_border_alpha", 1.0)),
        "inner_border_width_px": inner_width,
    }


def _request_points(request: dict) -> list[dict]:
    places = request.get("places")
    if not isinstance(places, list):
        return []
    points = []
    for place in places:
        if not isinstance(place, dict):
            continue
        lat = place.get("lat")
        lon = place.get("lon")
        if not isinstance(lat, int | float) or not isinstance(lon, int | float):
            continue
        points.append(
            {
                "lat": float(lat),
                "lon": float(lon),
                "weight": float(place.get("density", 1)),
            }
        )
    return points


def _request_selected_regions(request: dict) -> list[dict]:
    raw = request.get("selected_regions")
    if raw is None:
        return []
    if not isinstance(raw, list):
        raise ValueError("selected_regions must be a list")
    regions = []
    for index, row in enumerate(raw):
        if not isinstance(row, dict):
            raise ValueError(f"selected_regions[{index}] must be an object")
        semantic_id = row.get("semantic_id")
        if isinstance(semantic_id, bool) or not isinstance(semantic_id, int) or semantic_id <= 0:
            raise ValueError(f"selected_regions[{index}].semantic_id must be a positive integer")
        density = row.get("density", row.get("weight", 1))
        if isinstance(density, bool) or not isinstance(density, int | float) or not math.isfinite(float(density)) or density <= 0:
            raise ValueError(f"selected_regions[{index}].density must be a positive number")
        regions.append(
            {
                "semantic_id": int(semantic_id),
                "weight": float(density),
            }
        )
    return regions


def _scene_semantic_path(
    scene_roots: dict[str, Path],
    scene: dict,
    key: str,
    *,
    required: bool,
) -> Path | None:
    design = scene.get("design_facing")
    if not isinstance(design, dict):
        raise ValueError("scene manifest design_facing must be an object")
    sidecar = design.get(key)
    if sidecar is None and not required:
        return None
    if not isinstance(sidecar, dict):
        raise ValueError(f"region_claim requires scene design_facing.{key}")
    resolved = _resolve_design_asset_path(scene_roots, sidecar, key)
    if not resolved.exists():
        raise ValueError(f"Missing scene semantic sidecar: {resolved}")
    return resolved


def _load_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON asset must be an object: {path}")
    return value


def _resolve_scene_style(
    request: dict,
    *,
    style_profile: dict | str | Path | None,
    style_manifest: str | Path | None,
) -> dict:
    if isinstance(style_profile, dict):
        return normalize_style_profile(style_profile)
    if style_profile is not None:
        return load_style_profile(style_profile)
    requested_style_id = _request_style_id(request)
    if style_manifest is not None:
        try:
            return load_style_profile(_resolve_style_profile_for_id(style_manifest, requested_style_id))
        except ValueError as exc:
            if not str(exc).startswith("Unknown style_id in style manifest:"):
                raise
            bundled_style = load_bundled_style_profile(requested_style_id)
            if bundled_style is not None:
                return bundled_style
            raise
    bundled_style = load_bundled_style_profile(requested_style_id)
    if bundled_style is not None:
        return bundled_style
    if requested_style_id is not None:
        raise ValueError("request map_style requires --style-manifest")
    return load_style_profile(None)


def _load_scene_manifest(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("scene manifest must be a JSON object")
    if "design_facing" not in value:
        raise ValueError("scene manifest must contain design_facing")
    return value


def _scene_asset_path(scene_dir: Path, scene: dict, key: str) -> Path:
    design = scene.get("design_facing")
    if not isinstance(design, dict):
        raise ValueError("scene manifest design_facing must be an object")
    asset = design.get(key)
    if not isinstance(asset, dict):
        raise ValueError(f"scene manifest design_facing.{key} must be an object")
    scene_roots = scene_dir if isinstance(scene_dir, dict) else {"scene": scene_dir, "core": scene_dir, "presentation": scene_dir}
    resolved = _resolve_design_asset_path(scene_roots, asset, f"design_facing.{key}")
    if not resolved.exists():
        raise ValueError(f"Missing scene asset: {resolved}")
    return resolved


def _scene_package_roots(scene_path: Path, scene: dict) -> dict[str, Path]:
    package_dir = scene_path.parent
    roots = {
        "scene": package_dir,
        "core": package_dir,
        "presentation": package_dir,
    }
    split = scene.get("package_split")
    if split is None:
        return roots
    if not isinstance(split, dict):
        raise ValueError("scene package_split must be an object")
    mapping = {
        "core": split.get("core_root"),
        "presentation": split.get("presentation_root"),
    }
    for role, raw_path in mapping.items():
        if raw_path is None:
            continue
        if not isinstance(raw_path, str) or not raw_path:
            raise ValueError(f"scene package_split.{role}_root must be a package-relative path")
        roots[role] = _resolve_relative_package_path(package_dir, raw_path, f"package_split.{role}_root")
    return roots


def _resolve_design_asset_path(
    scene_roots: dict[str, Path],
    asset: dict,
    label: str,
) -> Path:
    raw_package = asset.get("package", "scene")
    if raw_package not in {"scene", "core", "presentation"}:
        raise ValueError(f"scene {label}.package must be scene, core, or presentation")
    raw_path = asset.get("path")
    if not isinstance(raw_path, str) or not raw_path:
        raise ValueError(f"scene {label}.path is required")
    return _resolve_relative_package_path(scene_roots[str(raw_package)], raw_path, f"{label}.path")


def _resolve_relative_package_path(root: Path, raw_path: str, label: str) -> Path:
    path = Path(raw_path)
    if path.is_absolute() or ".." in path.parts:
        raise ValueError(f"scene {label} must be package-relative")
    return root / path


def _load_request(path: str | Path) -> dict:
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("map render request must be a JSON object")
    return value


def _request_style_id(request: dict) -> str | None:
    value = request.get("map_style")
    if value is None:
        return None
    if not isinstance(value, str) or not value.strip():
        raise ValueError("request map_style must be a non-empty string")
    return value.strip()


def _request_claim_levels(request: dict) -> list[int] | None:
    return _request_activation_levels(request, "claim_levels")


def _request_admin_region_levels(request: dict) -> list[int] | None:
    return _request_activation_levels(request, "admin_region_levels")


def _default_country_activation_admin_region_levels(scene: dict) -> list[int] | None:
    design = scene.get("design_facing")
    claim_sidecars = design.get("claim_semantic_sidecars") if isinstance(design, dict) else None
    if not isinstance(claim_sidecars, dict):
        return None
    return [4] if isinstance(claim_sidecars.get("4"), dict) else None


def _request_region_levels(request: dict) -> list[int] | None:
    return _request_activation_levels(request, "region_levels")


def _request_country_activation(request: dict) -> bool:
    policy = request.get("activation_policy")
    if not isinstance(policy, dict):
        return False
    if policy.get("mode") != "region_claim":
        return False
    return policy.get("country_activation") is True


def _request_activation_levels(request: dict, key: str) -> list[int] | None:
    policy = request.get("activation_policy")
    if not isinstance(policy, dict):
        return None
    if policy.get("mode") != "region_claim":
        return None
    value = policy.get(key)
    if not isinstance(value, list):
        return None
    levels: list[int] = []
    for item in value:
        if isinstance(item, bool) or not isinstance(item, int) or item <= 0:
            continue
        if item not in levels:
            levels.append(item)
    return levels


def _apply_base_profile(base_png: Path, style: dict) -> None:
    base = style_base(style)
    replacements = []
    for key, source in {
        "sea": SEA,
        "land": LAND,
        "context_land": CONTEXT_LAND,
        "outer_border": OUTER_BORDER,
        "inner_border": INNER_BORDER,
        "focus_country_border": FOCUS_COUNTRY_BORDER,
        "context_border": CONTEXT_BORDER,
    }.items():
        target = _parse_u8_color(base.get(key))
        if source != target:
            replacements.append((source, target))
    if not replacements:
        return

    image = read_rgb_png(base_png)
    image.replace_rgb_colors(replacements)
    write_png(base_png, image)


def _apply_sea_depth_profile(
    scene_dir: Path,
    scene: dict,
    base_png: Path,
    style: dict,
) -> None:
    base = style_base(style)
    mode = _resolve_sea_depth_mode(str(base.get("sea_depth_mode", "none")))
    if mode == "none":
        return

    alpha = _clamp(float(base.get("sea_depth_alpha", 0.0)), 0.0, 1.0)
    radius = max(0, int(round(float(base.get("sea_depth_radius_px", 0)))))
    if alpha <= 0.0 or radius <= 0:
        return

    image = read_rgb_png(base_png)
    semantic = _load_optional_region_claim_semantic(
        scene_dir,
        scene,
        base_shape=(image.height, image.width),
    )
    if semantic is None:
        return

    near_color = np.array(
        parse_hex_color(base.get("sea_depth_near_color", base.get("sea", "#0c1a2b"))),
        dtype=np.float32,
    )
    far_color = np.array(
        parse_hex_color(base.get("sea_depth_far_color", base.get("sea", "#0c1a2b"))),
        dtype=np.float32,
    )
    if np.array_equal(near_color, far_color):
        return

    land = semantic.scene_mask().array.astype(bool, copy=False)
    sea = ~land
    if not np.any(sea):
        return

    depth = np.full(land.shape, radius + 1, dtype=np.int16)
    reached = land.copy()
    for step in range(1, radius + 1):
        dilated = Mask.from_bool_array(reached).dilate4().array.astype(bool, copy=False)
        ring = dilated & ~reached & sea
        if np.any(ring):
            depth[ring] = step
        reached |= ring
        if not np.any(sea & ~reached):
            break

    sea_depth = depth[sea]
    if radius == 1:
        ratio = np.zeros(sea_depth.shape, dtype=np.float32)
    else:
        ratio = np.clip(
            (sea_depth.astype(np.float32) - 1.0) / (radius - 1.0),
            0.0,
            1.0,
        )
    target = near_color * (1.0 - ratio[:, None]) + far_color * ratio[:, None]
    rgb = image.array[..., :3].astype(np.float32, copy=False)
    rgb[sea] = rgb[sea] * (1.0 - alpha) + target * alpha
    image.array[..., :3] = np.rint(np.clip(rgb, 0, 255)).astype(np.uint8)
    write_png(base_png, image)


def _apply_tone_profile(base_png: Path, style: dict) -> None:
    tone = style_tone(style)
    mode = _resolve_tone_mode(str(tone.get("mode", "none")))
    strength = float(tone.get("strength", 0.0))
    if mode == "none" or strength <= 0:
        return
    image = read_rgb_png(base_png)
    overlay = float_color(parse_hex_color(tone.get("overlay", "#000000")))
    if mode == "overlay":
        _apply_overlay_tone(image, overlay, strength)
    elif mode == "multiply":
        _apply_multiply_tone(image, overlay, strength)
    else:
        raise ValueError(f"Unknown style tone mode: {mode!r}")
    write_png(base_png, image)


def _apply_overlay_tone(image: Image, overlay: FloatColor, strength: float) -> None:
    image.apply_overlay_tone(overlay, strength)


def _apply_multiply_tone(image: Image, overlay: FloatColor, strength: float) -> None:
    image.apply_multiply_tone(overlay, strength)


def _resolve_style_profile_for_id(
    style_manifest_path: str | Path,
    requested_style_id: str | None,
) -> Path:
    manifest_path = Path(style_manifest_path)
    value = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("style manifest must be a JSON object")
    if value.get("profile") != "cadis.semantic_world.map_style_set":
        raise ValueError("style manifest has unknown profile")
    styles = value.get("styles")
    if not isinstance(styles, list) or not all(isinstance(item, dict) for item in styles):
        raise ValueError("style manifest must contain a styles array")
    style_id_value = resolve_style_id(requested_style_id) or str(value.get("default_style_id") or "")
    for style in styles:
        if str(style.get("style_id")) != style_id_value:
            continue
        raw_path = style.get("path")
        if not raw_path:
            raise ValueError("style manifest row is missing path")
        path = Path(str(raw_path))
        return path if path.is_absolute() else manifest_path.parent.parent / path
    raise ValueError(f"Unknown style_id in style manifest: {style_id_value!r}")


def _resolve_tone_mode(mode: str) -> str:
    normalized = mode.strip().lower().replace("-", "_")
    aliases = {
        "flat": "none",
        "warm_paper": "overlay",
        "cool_dusk": "multiply",
    }
    return aliases.get(normalized, normalized)


def _resolve_sea_depth_mode(mode: str) -> str:
    normalized = mode.strip().lower().replace("-", "_")
    if normalized in {"", "none"}:
        return "none"
    if normalized == "coastal_distance":
        return normalized
    raise ValueError(f"Unknown sea depth mode: {mode!r}")


def _active_claim_style(activation_style: dict) -> dict:
    return {
        "region_fill_color": activation_style.get(
            "activated_claim_fill_color",
            activation_style.get("region_fill_color", activation_style.get("glow_color", "#ffc556")),
        ),
        "region_border_color": activation_style.get(
            "activated_claim_border_color",
            activation_style.get("region_border_color", activation_style.get("marker_outline_color", "#5a3b10")),
        ),
        "region_glow_color": activation_style.get(
            "activated_claim_glow_color",
            activation_style.get("region_glow_color", activation_style.get("glow_color", "#ffc556")),
        ),
        "region_fill_alpha": float(
            activation_style.get(
                "activated_claim_fill_alpha",
                activation_style.get("region_fill_alpha", 0.28),
            )
        ),
        "region_fill_alpha_min": float(
            activation_style.get(
                "activated_claim_fill_alpha_min",
                activation_style.get("region_fill_alpha_min", 0.0),
            )
        ),
        "region_density_scale": activation_style.get(
            "activated_claim_density_scale",
            activation_style.get("region_density_scale", "log"),
        ),
        "region_border_alpha": float(
            activation_style.get(
                "activated_claim_border_alpha",
                activation_style.get("region_border_alpha", 0.72),
            )
        ),
        "region_glow_alpha": float(
            activation_style.get(
                "activated_claim_glow_alpha",
                activation_style.get("region_glow_alpha", 0.28),
            )
        ),
        "region_glow_radius_px": float(
            activation_style.get(
                "activated_claim_glow_radius_px",
                activation_style.get("region_glow_radius_px", 18.0),
            )
        ),
        "region_border_width_px": float(
            activation_style.get(
                "activated_claim_border_width_px",
                activation_style.get("region_border_width_px", 1.0),
            )
        ),
    }


def _active_country_style(activation_style: dict) -> dict:
    return {
        "region_fill_color": activation_style.get(
            "activated_country_fill_color",
            "#a7c79e",
        ),
        "region_border_color": activation_style.get(
            "activated_country_border_color",
            "#ffffff",
        ),
        "region_glow_color": activation_style.get(
            "activated_country_glow_color",
            "#ffffff",
        ),
        "region_fill_alpha": float(
            activation_style.get(
                "activated_country_fill_alpha",
                0.22,
            )
        ),
        "region_fill_alpha_min": float(
            activation_style.get(
                "activated_country_fill_alpha_min",
                0.08,
            )
        ),
        "region_density_scale": activation_style.get(
            "activated_country_density_scale",
            "log",
        ),
        "region_border_alpha": float(
            activation_style.get(
                "activated_country_border_alpha",
                0.55,
            )
        ),
        "region_glow_alpha": float(
            activation_style.get(
                "activated_country_glow_alpha",
                0.0,
            )
        ),
        "region_glow_radius_px": float(
            activation_style.get(
                "activated_country_glow_radius_px",
                0.0,
            )
        ),
        "region_border_width_px": float(
            activation_style.get(
                "activated_country_border_width_px",
                1.0,
            )
        ),
    }


def _active_admin_region_style(activation_style: dict) -> dict:
    return {
        "region_fill_color": activation_style.get(
            "activated_admin_region_fill_color",
            activation_style.get("activated_region_fill_color", "#7fb876"),
        ),
        "region_border_color": activation_style.get(
            "activated_admin_region_border_color",
            activation_style.get("activated_region_border_color", "#ffffff"),
        ),
        "region_glow_color": activation_style.get(
            "activated_admin_region_glow_color",
            activation_style.get("activated_region_glow_color", "#ffffff"),
        ),
        "region_fill_alpha": float(
            activation_style.get(
                "activated_admin_region_fill_alpha",
                activation_style.get("activated_region_fill_alpha", 0.18),
            )
        ),
        "region_fill_alpha_min": float(
            activation_style.get(
                "activated_admin_region_fill_alpha_min",
                activation_style.get("activated_region_fill_alpha_min", 0.04),
            )
        ),
        "region_density_scale": activation_style.get(
            "activated_admin_region_density_scale",
            activation_style.get("activated_region_density_scale", "log"),
        ),
        "region_border_alpha": float(
            activation_style.get(
                "activated_admin_region_border_alpha",
                activation_style.get("activated_region_border_alpha", 0.0),
            )
        ),
        "region_glow_alpha": float(
            activation_style.get(
                "activated_admin_region_glow_alpha",
                activation_style.get("activated_region_glow_alpha", 0.0),
            )
        ),
        "region_glow_radius_px": float(
            activation_style.get(
                "activated_admin_region_glow_radius_px",
                activation_style.get("activated_region_glow_radius_px", 0.0),
            )
        ),
        "region_border_width_px": float(
            activation_style.get(
                "activated_admin_region_border_width_px",
                activation_style.get("activated_region_border_width_px", 1.0),
            )
        ),
    }


def _active_middle_region_style(activation_style: dict) -> dict:
    return {
        "region_fill_color": activation_style.get(
            "activated_region_fill_color",
            activation_style.get(
                "activated_claim_fill_color",
                activation_style.get("region_fill_color", activation_style.get("glow_color", "#ffc556")),
            ),
        ),
        "region_border_color": activation_style.get(
            "activated_region_border_color",
            activation_style.get(
                "activated_claim_border_color",
                activation_style.get("region_border_color", activation_style.get("marker_outline_color", "#5a3b10")),
            ),
        ),
        "region_glow_color": activation_style.get(
            "activated_region_glow_color",
            activation_style.get(
                "activated_claim_glow_color",
                activation_style.get("region_glow_color", activation_style.get("glow_color", "#ffc556")),
            ),
        ),
        "region_fill_alpha": float(
            activation_style.get("activated_region_fill_alpha", 0.18)
        ),
        "region_fill_alpha_min": float(
            activation_style.get("activated_region_fill_alpha_min", 0.04)
        ),
        "region_density_scale": activation_style.get(
            "activated_region_density_scale",
            activation_style.get("region_density_scale", "log"),
        ),
        "region_border_alpha": float(
            activation_style.get("activated_region_border_alpha", 0.0)
        ),
        "region_glow_alpha": float(
            activation_style.get("activated_region_glow_alpha", 0.0)
        ),
        "region_glow_radius_px": float(
            activation_style.get("activated_region_glow_radius_px", 0.0)
        ),
        "region_border_width_px": float(
            activation_style.get("activated_region_border_width_px", 1.0)
        ),
    }


def _apply_region_glow(
    image: Image,
    active_mask: Mask,
    *,
    active_border_mask: Mask | None = None,
    style: dict | None = None,
    region_masks: dict[int, Mask] | None = None,
    region_weights: dict[int, int] | None = None,
) -> Image:
    style = style or {}
    glow_color = _style_color(style, "region_glow_color", "#ffc556")
    fill_color = _style_color(style, "region_fill_color", "#fff0a4")
    border_color = _style_color(style, "region_border_color", "#fff0a4")
    glow_alpha = _clamp(float(style.get("region_glow_alpha", 0.38)), 0.0, 1.0)
    fill_alpha = _clamp(float(style.get("region_fill_alpha", 0.65)), 0.0, 1.0)
    min_fill_alpha = _clamp(
        float(style.get("region_fill_alpha_min", 0.0)),
        0.0,
        fill_alpha,
    )
    border_alpha = _clamp(float(style.get("region_border_alpha", 0.0)), 0.0, 1.0)
    glow_radius = max(0, int(round(float(style.get("region_glow_radius_px", 5)))))
    border_width = _clamp(float(style.get("region_border_width_px", 1.0)), 0.0, 16.0)
    result = image.copy()
    if glow_radius > 0 and glow_alpha > 0:
        glow_distance = _mask_dilation_distance(active_mask, glow_radius)
        for step in range(glow_radius, 0, -1):
            alpha = (glow_radius - step + 1) / (glow_radius + 1) * glow_alpha
            _blend_mask_array(
                result,
                (glow_distance > 0) & (glow_distance <= step),
                glow_color,
                alpha,
            )
    if region_masks and region_weights:
        fill_alpha_by_region = _region_fill_alpha_by_weight(
            region_weights,
            min_alpha=min_fill_alpha,
            max_alpha=fill_alpha,
            scale=str(style.get("region_density_scale", "log")),
        )
        for scene_semantic_id in sorted(region_masks):
            _blend_mask(
                result,
                region_masks[scene_semantic_id],
                fill_color,
                fill_alpha_by_region.get(scene_semantic_id, fill_alpha),
            )
    else:
        _blend_mask(result, active_mask, fill_color, fill_alpha)
    if active_border_mask is not None and border_alpha > 0 and border_width > 0:
        border_mask = _stroke_mask(active_border_mask, border_width)
        _blend_mask(result, border_mask, border_color, border_alpha)
    return result


def _region_fill_alpha_by_weight(
    weights: dict[int, int | float],
    *,
    min_alpha: float,
    max_alpha: float,
    scale: str,
) -> dict[int, float]:
    if not weights:
        return {}
    max_weight = max(max(0.0, float(weight)) for weight in weights.values())
    if max_weight <= 0 or min_alpha >= max_alpha:
        return {scene_semantic_id: max_alpha for scene_semantic_id in weights}
    mode = scale.strip().lower().replace("-", "_")
    if mode not in {"linear", "log"}:
        raise ValueError(f"Unknown region density scale: {scale!r}")
    denominator = math.log1p(max_weight) if mode == "log" else float(max_weight)
    alpha_by_region = {}
    for scene_semantic_id, raw_weight in weights.items():
        weight = max(0.0, float(raw_weight))
        numerator = math.log1p(weight) if mode == "log" else float(weight)
        ratio = 0.0 if denominator <= 0 else numerator / denominator
        alpha_by_region[scene_semantic_id] = min_alpha + (max_alpha - min_alpha) * ratio
    return alpha_by_region


def _apply_scene_boundaries(
    image: Image,
    *,
    outer_border_mask: Mask,
    inner_border_mask: Mask,
    style: dict,
) -> Image:
    result = image.copy()
    outer_alpha = _clamp(float(style.get("outer_border_alpha", 0.0)), 0.0, 1.0)
    outer_width = _clamp(float(style.get("outer_border_width_px", 0.0)), 0.0, 16.0)
    if outer_alpha > 0 and outer_width > 0:
        _blend_mask(
            result,
            _stroke_mask(outer_border_mask, outer_width),
            _style_color(style, "outer_border_color", "#aeadad"),
            outer_alpha,
        )

    inner_alpha = _clamp(float(style.get("inner_border_alpha", 0.0)), 0.0, 1.0)
    inner_width = _clamp(float(style.get("inner_border_width_px", 0.0)), 0.0, 16.0)
    if inner_alpha > 0 and inner_width > 0:
        _blend_mask(
            result,
            _stroke_mask(inner_border_mask, inner_width),
            _style_color(style, "inner_border_color", "#dedede"),
            inner_alpha,
        )
    return result


def _style_color(style: dict, key: str, fallback: str) -> FloatColor:
    value = style.get(key, fallback)
    return float_color(parse_hex_color(value))


def _parse_u8_color(value: object) -> tuple[int, int, int]:
    red, green, blue = parse_hex_color(value)
    return (_to_u8(red), _to_u8(green), _to_u8(blue))


def _stroke_mask(mask: Mask, width_px: float) -> Mask:
    if width_px <= 0:
        return Mask.empty(mask.width, mask.height)
    radius = max(0, int(round(width_px)) - 1)
    result = mask.copy()
    for _ in range(radius):
        result = _dilate(result)
    return result


def _dilate(mask: Mask) -> Mask:
    return mask.dilate4()


def _or_mask(target: Mask, source: Mask) -> None:
    for offset, value in enumerate(source.data):
        if value:
            target.data[offset] = 1


def _mask_dilation_distance(mask: Mask, radius: int) -> np.ndarray:
    source = mask.array.astype(bool, copy=False)
    distance = np.zeros(source.shape, dtype=np.uint16)
    distance[source] = 1
    reached = source.copy()
    for step in range(1, radius + 1):
        dilated = _dilate_bool4(reached)
        new_pixels = dilated & ~reached
        if np.any(new_pixels):
            distance[new_pixels] = step
        reached = dilated
    return distance


def _dilate_bool4(source: np.ndarray) -> np.ndarray:
    dilated = source.copy()
    dilated[1:, :] |= source[:-1, :]
    dilated[:-1, :] |= source[1:, :]
    dilated[:, 1:] |= source[:, :-1]
    dilated[:, :-1] |= source[:, 1:]
    return dilated


def _outer_borders(land_mask: Mask) -> Mask:
    native_data = native.outer_borders(land_mask)
    if native_data is not None:
        return Mask(land_mask.width, land_mask.height, native_data)
    source = land_mask.array.astype(bool, copy=False)
    exterior_background = _exterior_background(source)
    borders = np.zeros(source.shape, dtype=bool)
    borders[1:, :] |= source[1:, :] & exterior_background[:-1, :]
    borders[:-1, :] |= source[:-1, :] & exterior_background[1:, :]
    borders[:, 1:] |= source[:, 1:] & exterior_background[:, :-1]
    borders[:, :-1] |= source[:, :-1] & exterior_background[:, 1:]
    return Mask.from_bool_array(borders)


def _exterior_background(land_mask: np.ndarray) -> np.ndarray:
    background = ~land_mask
    exterior = np.zeros(background.shape, dtype=bool)
    height, width = background.shape
    stack: list[tuple[int, int]] = []
    for col in range(width):
        if background[0, col]:
            stack.append((0, col))
        if height > 1 and background[height - 1, col]:
            stack.append((height - 1, col))
    for row in range(1, max(1, height - 1)):
        if background[row, 0]:
            stack.append((row, 0))
        if width > 1 and background[row, width - 1]:
            stack.append((row, width - 1))

    while stack:
        row, col = stack.pop()
        if exterior[row, col] or not background[row, col]:
            continue
        left = col
        while left > 0 and background[row, left - 1] and not exterior[row, left - 1]:
            left -= 1
        right = col
        while right + 1 < width and background[row, right + 1] and not exterior[row, right + 1]:
            right += 1
        exterior[row, left : right + 1] = True
        if row > 0:
            _append_unfilled_spans(stack, background, exterior, row - 1, left, right)
        if row + 1 < height:
            _append_unfilled_spans(stack, background, exterior, row + 1, left, right)
    return exterior


def _append_unfilled_spans(
    stack: list[tuple[int, int]],
    background: np.ndarray,
    exterior: np.ndarray,
    row: int,
    left: int,
    right: int,
) -> None:
    col = left
    while col <= right:
        while col <= right and (exterior[row, col] or not background[row, col]):
            col += 1
        if col > right:
            break
        stack.append((row, col))
        while col <= right and background[row, col] and not exterior[row, col]:
            col += 1


def _mask_from_bool_array(values: np.ndarray) -> Mask:
    return Mask.from_bool_array(values)


def _blend_mask(image: Image, mask: Mask, color: FloatColor, alpha: float) -> None:
    image.blend_mask(mask, color, alpha)


def _blend_mask_array(image: Image, mask: np.ndarray, color: FloatColor, alpha: float) -> None:
    if mask.shape != (image.height, image.width):
        raise ValueError("mask dimensions must match image")
    image.blend_mask(Mask.from_bool_array(mask), color, alpha)


def _clamp(value: float, minimum: float, maximum: float) -> float:
    return max(minimum, min(maximum, float(value)))


def _to_u8(value: float) -> int:
    return max(0, min(255, int(round(value))))
