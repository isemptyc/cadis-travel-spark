from __future__ import annotations

import math
from typing import Iterable

from cadis_map_render.image import Mask


SEMANTIC_VECTOR_SIDECAR_PROFILE = "cadis.semantic_world.scene_semantic_vector_sidecar"


def validate_semantic_vector_sidecar(sidecar: dict, *, width: int, height: int) -> list[str]:
    errors: list[str] = []
    if sidecar.get("profile") != SEMANTIC_VECTOR_SIDECAR_PROFILE:
        errors.append("semantic vector sidecar profile is unsupported")
    if sidecar.get("coordinate_space") != "scene_pixel":
        errors.append("semantic vector sidecar must use scene_pixel coordinates")
    if int(sidecar.get("width", -1)) != int(width) or int(sidecar.get("height", -1)) != int(height):
        errors.append("semantic vector sidecar dimensions must match scene height,width")
    regions = sidecar.get("regions")
    if not isinstance(regions, list):
        errors.append("semantic vector sidecar regions must be a list")
        return errors
    for index, region in enumerate(regions):
        if not isinstance(region, dict):
            errors.append(f"semantic vector region {index} must be an object")
            continue
        if not isinstance(region.get("scene_semantic_id"), int) or region["scene_semantic_id"] <= 0:
            errors.append(f"semantic vector region {index} requires positive scene_semantic_id")
        bbox = region.get("bbox")
        if not isinstance(bbox, list) or len(bbox) != 4 or not all(isinstance(v, int | float) for v in bbox):
            errors.append(f"semantic vector region {index} requires numeric bbox")
        geometry = region.get("geometry")
        if not isinstance(geometry, dict) or geometry.get("type") not in {"Polygon", "MultiPolygon"}:
            errors.append(f"semantic vector region {index} requires Polygon or MultiPolygon geometry")
    return errors


def sample_semantic_vector_id(sidecar: dict, *, x: float, y: float) -> int:
    for region in sidecar.get("regions", []):
        minx, miny, maxx, maxy = (float(value) for value in region["bbox"])
        if x < minx or x > maxx or y < miny or y > maxy:
            continue
        if _geometry_contains_point(region["geometry"], x=x, y=y):
            return int(region["scene_semantic_id"])
    return 0


def rasterize_semantic_vector_mask(
    sidecar: dict,
    active_semantic_ids: Iterable[int],
) -> Mask:
    active_ids = {int(value) for value in active_semantic_ids}
    height = int(sidecar["height"])
    width = int(sidecar["width"])
    mask = Mask.empty(width, height)
    if not active_ids:
        return mask
    for region in sidecar.get("regions", []):
        if int(region.get("scene_semantic_id", 0)) not in active_ids:
            continue
        minx, miny, maxx, maxy = (float(value) for value in region["bbox"])
        col0 = max(0, int(math.floor(minx)))
        row0 = max(0, int(math.floor(miny)))
        col1 = min(width, int(math.ceil(maxx)))
        row1 = min(height, int(math.ceil(maxy)))
        if col0 >= col1 or row0 >= row1:
            continue
        geometry = region["geometry"]
        for row in range(row0, row1):
            y = row + 0.5
            for col in range(col0, col1):
                if _geometry_contains_point(geometry, x=col + 0.5, y=y):
                    mask.set(row, col)
    return mask


def _geometry_contains_point(geometry: dict, *, x: float, y: float) -> bool:
    geometry_type = geometry.get("type")
    coordinates = geometry.get("coordinates")
    if geometry_type == "Polygon":
        return _polygon_contains_point(coordinates, x=x, y=y)
    if geometry_type == "MultiPolygon":
        return any(_polygon_contains_point(polygon, x=x, y=y) for polygon in coordinates)
    return False


def _polygon_contains_point(coordinates: list, *, x: float, y: float) -> bool:
    if not coordinates:
        return False
    if not _ring_contains_point(coordinates[0], x=x, y=y):
        return False
    return not any(_ring_contains_point(ring, x=x, y=y) for ring in coordinates[1:])


def _ring_contains_point(ring: list, *, x: float, y: float) -> bool:
    inside = False
    if len(ring) < 3:
        return False
    x1, y1 = (float(value) for value in ring[-1][:2])
    for point in ring:
        x2, y2 = (float(value) for value in point[:2])
        if _point_on_segment(x, y, x1, y1, x2, y2):
            return True
        if (y1 > y) != (y2 > y):
            intersection_x = (x2 - x1) * (y - y1) / (y2 - y1) + x1
            if x < intersection_x:
                inside = not inside
        x1, y1 = x2, y2
    return inside


def _point_on_segment(
    x: float,
    y: float,
    x1: float,
    y1: float,
    x2: float,
    y2: float,
) -> bool:
    cross = (x - x1) * (y2 - y1) - (y - y1) * (x2 - x1)
    if abs(cross) > 1e-9:
        return False
    dot = (x - x1) * (x2 - x1) + (y - y1) * (y2 - y1)
    if dot < 0:
        return False
    squared_len = (x2 - x1) ** 2 + (y2 - y1) ** 2
    return dot <= squared_len
