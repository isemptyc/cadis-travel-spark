from __future__ import annotations

from dataclasses import dataclass

import numpy as np

import cadis_map_render.native as native


Color = tuple[int, int, int]
FloatColor = tuple[float, float, float]


@dataclass
class Image:
    width: int
    height: int
    channels: int
    data: bytearray

    @classmethod
    def new(
        cls,
        width: int,
        height: int,
        channels: int,
        color: Color | tuple[int, int, int, int] | None = None,
    ) -> Image:
        if channels not in {3, 4}:
            raise ValueError("image channels must be 3 or 4")
        pixel = tuple(color or (0,) * channels)
        if len(pixel) != channels:
            raise ValueError("image color channel count does not match image")
        return cls(width, height, channels, bytearray(pixel * (width * height)))

    @property
    def shape(self) -> tuple[int, int, int]:
        return (self.height, self.width, self.channels)

    @property
    def array(self) -> np.ndarray:
        return np.frombuffer(self.data, dtype=np.uint8).reshape(self.shape)

    def copy(self) -> Image:
        return Image(self.width, self.height, self.channels, bytearray(self.data))

    def row_bytes(self, row: int) -> bytes:
        start = row * self.width * self.channels
        end = start + self.width * self.channels
        return bytes(self.data[start:end])

    def offset(self, row: int, col: int) -> int:
        return (row * self.width + col) * self.channels

    def blend_pixel(self, row: int, col: int, color: FloatColor, alpha: float) -> None:
        if alpha <= 0.0:
            return
        offset = self.offset(row, col)
        inverse = 1.0 - alpha
        for channel in range(3):
            self.data[offset + channel] = _to_u8(
                self.data[offset + channel] * inverse + color[channel] * alpha
            )

    def set_rgb(self, row: int, col: int, color: Color) -> None:
        offset = self.offset(row, col)
        self.data[offset : offset + 3] = bytes(color)

    def replace_rgb_colors(self, replacements: list[tuple[Color, Color]]) -> None:
        if not replacements:
            return
        if native.replace_rgb_colors(self, replacements):
            return
        rgb = self.array[..., :3]
        original = rgb.copy()
        replaced = np.zeros(self.shape[:2], dtype=bool)
        for source, target in replacements:
            matches = np.all(original == np.array(source, dtype=np.uint8), axis=-1) & ~replaced
            rgb[matches] = np.array(target, dtype=np.uint8)
            replaced |= matches

    def apply_overlay_tone(self, overlay: FloatColor, strength: float) -> None:
        if strength <= 0.0:
            return
        target = np.array(overlay, dtype=np.float32)
        rgb = self.array[..., :3]
        for row in range(self.height):
            row_rgb = rgb[row].astype(np.float32, copy=False)
            toned = row_rgb * (1.0 - strength) + target * strength
            rgb[row] = np.rint(np.clip(toned, 0, 255)).astype(np.uint8)

    def apply_multiply_tone(self, overlay: FloatColor, strength: float) -> None:
        if strength <= 0.0:
            return
        multipliers = 1.0 - strength + strength * np.array(overlay, dtype=np.float32) / 255.0
        rgb = self.array[..., :3]
        for row in range(self.height):
            toned = rgb[row].astype(np.float32, copy=False) * multipliers
            rgb[row] = np.rint(np.clip(toned, 0, 255)).astype(np.uint8)

    def blend_mask(self, mask: Mask, color: FloatColor, alpha: float) -> None:
        if alpha <= 0.0:
            return
        if (mask.height, mask.width) != (self.height, self.width):
            raise ValueError("mask dimensions must match image")
        if native.blend_mask(self, mask, color, alpha):
            return
        active = mask.array.astype(bool, copy=False)
        if not np.any(active):
            return
        target = np.array(color, dtype=np.float32)
        inverse = 1.0 - alpha
        rgb = self.array[..., :3]
        active_rows = np.flatnonzero(np.any(active, axis=1))
        for row in active_rows:
            row_active = active[row]
            row_rgb = rgb[row, row_active].astype(np.float32, copy=False)
            blended = row_rgb * inverse + target * alpha
            rgb[row, row_active] = np.rint(np.clip(blended, 0, 255)).astype(np.uint8)


@dataclass
class Mask:
    width: int
    height: int
    data: bytearray

    @classmethod
    def empty(cls, width: int, height: int) -> Mask:
        return cls(width, height, bytearray(width * height))

    @property
    def shape(self) -> tuple[int, int]:
        return (self.height, self.width)

    @property
    def array(self) -> np.ndarray:
        return np.frombuffer(self.data, dtype=np.uint8).reshape(self.shape)

    def copy(self) -> Mask:
        return Mask(self.width, self.height, bytearray(self.data))

    def offset(self, row: int, col: int) -> int:
        return row * self.width + col

    def get(self, row: int, col: int) -> bool:
        return bool(self.data[self.offset(row, col)])

    def set(self, row: int, col: int, value: bool = True) -> None:
        self.data[self.offset(row, col)] = 1 if value else 0

    @classmethod
    def from_bool_array(cls, values: np.ndarray) -> Mask:
        height, width = values.shape
        mask = cls.empty(int(width), int(height))
        mask.array[:] = values.astype(np.uint8, copy=False)
        return mask

    def dilate4(self) -> Mask:
        native_data = native.dilate4(self)
        if native_data is not None:
            return Mask(self.width, self.height, native_data)
        source = self.array.astype(bool, copy=False)
        dilated = source.copy()
        dilated[1:, :] |= source[:-1, :]
        dilated[:-1, :] |= source[1:, :]
        dilated[:, 1:] |= source[:, :-1]
        dilated[:, :-1] |= source[:, 1:]
        return Mask.from_bool_array(dilated)

    def outer_borders4(self) -> Mask:
        source = self.array.astype(bool, copy=False)
        borders = source.copy()
        borders[1:-1, 1:-1] = (
            source[1:-1, 1:-1]
            & (
                ~source[:-2, 1:-1]
                | ~source[2:, 1:-1]
                | ~source[1:-1, :-2]
                | ~source[1:-1, 2:]
            )
        )
        return Mask.from_bool_array(borders)


def parse_color(value: tuple[int, int, int]) -> Color:
    return (_to_u8(value[0]), _to_u8(value[1]), _to_u8(value[2]))


def float_color(value: tuple[int, int, int]) -> FloatColor:
    return (float(value[0]), float(value[1]), float(value[2]))


def _to_u8(value: float) -> int:
    return max(0, min(255, int(round(value))))
