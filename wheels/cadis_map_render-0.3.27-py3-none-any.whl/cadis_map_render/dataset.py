from __future__ import annotations

import hashlib
import json
import shutil
import tarfile
import tempfile
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Protocol
from urllib.parse import unquote, urlparse


_HTTP_USER_AGENT = "cadis-map-render/0.3"
DEFAULT_CDN_DATASET_ROOT = "https://map-dataset.cadis.dev/releases"


class DatasetSourceError(RuntimeError):
    pass


class DatasetSource(Protocol):
    def resolve_dataset_root(self) -> Path:
        """Return a local dataset root that cadis-map-render can scan."""


@dataclass(frozen=True)
class FileDatasetSource:
    dataset_root: str | Path

    def resolve_dataset_root(self) -> Path:
        root = Path(self.dataset_root).expanduser().resolve()
        if not root.is_dir():
            raise DatasetSourceError(f"dataset root does not exist: {root}")
        return root


@dataclass(frozen=True)
class CdnDatasetSource:
    archive_url: str
    cache_root: str | Path
    dataset_key: str
    sha256: str | None = None
    dataset_subdir: str | None = None

    def resolve_dataset_root(self) -> Path:
        cache_root = Path(self.cache_root).expanduser().resolve()
        key = _safe_cache_key(self.dataset_key)
        dataset_root = cache_root / "datasets" / key
        marker = dataset_root / ".cadis-map-render-dataset-ready"
        if marker.exists():
            return _dataset_subdir(dataset_root, self.dataset_subdir)

        archive = cache_root / "archives" / f"{key}{_archive_suffix(self.archive_url)}"
        archive.parent.mkdir(parents=True, exist_ok=True)
        if not archive.exists():
            _download_file(self.archive_url, archive)
        if self.sha256 is not None:
            _verify_sha256(archive, self.sha256)

        with tempfile.TemporaryDirectory(prefix="cadis-map-render-dataset-", dir=str(cache_root)) as temp_dir:
            temp_root = Path(temp_dir) / "dataset"
            temp_root.mkdir(parents=True)
            _extract_archive(archive, temp_root)
            ready_root = _dataset_subdir(temp_root, self.dataset_subdir)
            if not ready_root.exists():
                raise DatasetSourceError(f"extracted dataset root does not exist: {ready_root}")
            marker_target = temp_root / ".cadis-map-render-dataset-ready"
            marker_target.write_text(self.archive_url + "\n", encoding="utf-8")
            if dataset_root.exists():
                shutil.rmtree(dataset_root)
            dataset_root.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(temp_root), dataset_root)
        return _dataset_subdir(dataset_root, self.dataset_subdir)


@dataclass(frozen=True)
class CdnDatasetCatalogSource:
    dataset_root_url: str | Path
    cache_root: str | Path
    scene_id: str
    resolution: int | str | None = None
    version: str | None = None
    dataset_family: str | None = None

    def resolve_dataset_root(self) -> Path:
        return self.resolve_archive_source().resolve_dataset_root()

    def resolve_archive_source(self) -> CdnDatasetSource:
        return _resolve_cdn_catalog_source(
            dataset_root_url=self.dataset_root_url,
            cache_root=self.cache_root,
            scene_id=self.scene_id,
            resolution=self.resolution,
            version=self.version,
            dataset_family=self.dataset_family,
        )


@dataclass(frozen=True)
class CadisMapRenderClient:
    dataset_source: DatasetSource
    output_root: str | Path
    cache_root: str | Path | None = None
    admission_mode: str = "trusted"
    export_psd: bool = False
    render_profile: bool = False

    @classmethod
    def from_file_dataset(
        cls,
        dataset_root: str | Path,
        *,
        output_root: str | Path,
        cache_root: str | Path | None = None,
        admission_mode: str = "trusted",
    ) -> "CadisMapRenderClient":
        return cls(
            dataset_source=FileDatasetSource(dataset_root),
            output_root=output_root,
            cache_root=cache_root,
            admission_mode=admission_mode,
        )

    @classmethod
    def from_cdn_dataset(
        cls,
        archive_url: str,
        *,
        cache_root: str | Path,
        dataset_key: str,
        output_root: str | Path,
        sha256: str | None = None,
        dataset_subdir: str | None = None,
    ) -> "CadisMapRenderClient":
        return cls(
            dataset_source=CdnDatasetSource(
                archive_url=archive_url,
                cache_root=cache_root,
                dataset_key=dataset_key,
                sha256=sha256,
                dataset_subdir=dataset_subdir,
            ),
            output_root=output_root,
            cache_root=cache_root,
        )

    @classmethod
    def from_cdn_catalog(
        cls,
        dataset_root_url: str | Path = DEFAULT_CDN_DATASET_ROOT,
        *,
        cache_root: str | Path,
        scene_id: str,
        output_root: str | Path,
        resolution: int | str | None = None,
        version: str | None = None,
        dataset_family: str | None = None,
    ) -> "CadisMapRenderClient":
        return cls(
            dataset_source=CdnDatasetCatalogSource(
                dataset_root_url=dataset_root_url,
                cache_root=cache_root,
                scene_id=scene_id,
                resolution=resolution,
                version=version,
                dataset_family=dataset_family,
            ),
            output_root=output_root,
            cache_root=cache_root,
        )

    def render_map(self, payload: dict) -> dict:
        return self._service().render_map_request(payload)

    def list_scenes(self) -> list[dict]:
        return self._service().list_scenes()

    def list_place_names(self, scene_id: str) -> dict:
        return self._service().list_place_names(scene_id)

    def _service(self):
        from cadis_map_render.api import CadisMapRenderService, CadisMapRenderServiceConfig

        return CadisMapRenderService(
            CadisMapRenderServiceConfig(
                dataset_root=self.dataset_source.resolve_dataset_root(),
                output_root=Path(self.output_root).expanduser(),
                cache_root=None if self.cache_root is None else Path(self.cache_root).expanduser(),
                admission_mode=self.admission_mode,
                export_psd=self.export_psd,
                render_profile=self.render_profile,
            )
        )


def _download_file(url: str, destination: Path) -> None:
    temp = destination.with_suffix(destination.suffix + ".tmp")
    try:
        with _open_url(url) as response:
            with temp.open("wb") as output:
                shutil.copyfileobj(response, output)
        temp.replace(destination)
    finally:
        if temp.exists():
            temp.unlink()


def _resolve_cdn_catalog_source(
    *,
    dataset_root_url: str | Path,
    cache_root: str | Path,
    scene_id: str,
    resolution: int | str | None,
    version: str | None,
    dataset_family: str | None,
) -> CdnDatasetSource:
    normalized_scene_id = _required_string(scene_id, "scene_id")
    normalized_version = _optional_nonempty_string(version)
    catalog_root, manifest = _load_catalog_manifest_for_scene(
        dataset_root_url=dataset_root_url,
        scene_id=normalized_scene_id,
        resolution=resolution,
        dataset_family=dataset_family,
    )
    entry = _find_scene_entry(manifest, scene_id=normalized_scene_id, version=normalized_version)
    if entry is None:
        suffix = f" version {normalized_version!r}" if normalized_version else ""
        raise DatasetSourceError(f"scene_id {normalized_scene_id!r}{suffix} is not listed in CDN dataset catalog")
    archive = entry.get("archive")
    if not isinstance(archive, Mapping):
        raise DatasetSourceError(f"scene entry {normalized_scene_id!r} does not include an archive")
    sha256 = archive.get("sha256")
    if not isinstance(sha256, str) or not sha256.strip():
        raise DatasetSourceError(f"scene entry {normalized_scene_id!r} archive does not include sha256")
    scene_version = _entry_version(entry)
    if not scene_version:
        raise DatasetSourceError(f"scene entry {normalized_scene_id!r} does not include a version")
    archive_root = _catalog_archive_root(manifest, manifest_root=catalog_root)
    archive_url = _catalog_archive_url(archive, archive_root=archive_root)
    return CdnDatasetSource(
        archive_url=archive_url,
        cache_root=cache_root,
        dataset_key=f"{normalized_scene_id}/{scene_version}/{sha256.strip().lower()[:16]}",
        sha256=sha256.strip(),
    )


def _load_catalog_manifest_for_scene(
    *,
    dataset_root_url: str | Path,
    scene_id: str,
    resolution: int | str | None,
    dataset_family: str | None,
) -> tuple[str, dict[str, Any]]:
    roots = _candidate_catalog_roots(
        dataset_root_url=dataset_root_url,
        scene_id=scene_id,
        resolution=resolution,
        dataset_family=dataset_family,
    )
    failures: list[str] = []
    for root in roots:
        try:
            manifest = _load_json_object(_join_url_or_path(root, "dataset_manifest.json"))
        except Exception as exc:
            failures.append(f"{root}: {exc}")
            continue
        if _find_scene_entry(manifest, scene_id=scene_id, version=None) is not None:
            return root, manifest
        failures.append(f"{root}: scene_id {scene_id!r} not listed")
    detail = "; ".join(failures) if failures else "no candidate catalog roots"
    raise DatasetSourceError(f"unable to resolve scene_id {scene_id!r} from CDN dataset catalog: {detail}")


def _candidate_catalog_roots(
    *,
    dataset_root_url: str | Path,
    scene_id: str,
    resolution: int | str | None,
    dataset_family: str | None,
) -> list[str]:
    root = str(dataset_root_url).strip().rstrip("/")
    if not root:
        raise DatasetSourceError("dataset_root_url is required")
    if root.endswith("/dataset_manifest.json"):
        return [root.removesuffix("/dataset_manifest.json")]
    if _is_local_url_or_path(root):
        local_manifest = _local_path_from_url_or_path(root) / "dataset_manifest.json"
        if local_manifest.is_file():
            return [root]

    families = (
        [_normalize_catalog_family(dataset_family)]
        if dataset_family
        else _scene_catalog_families(scene_id, resolution)
    )
    return [_join_url_or_path(root, family) for family in families]


def _scene_catalog_families(scene_id: str, resolution: int | str | None) -> list[str]:
    normalized_resolution = _optional_nonempty_string(None if resolution is None else str(resolution))
    scene = scene_id.strip().lower()
    if _is_iso2_scene_id(scene) or scene.startswith(("country_", "iso2_")):
        if normalized_resolution:
            return [f"single-country/{normalized_resolution}", "single-country"]
        return ["single-country"]
    if scene.startswith("world_"):
        return ["worldwide"]
    if scene.startswith("lon_"):
        families: list[str] = []
        if normalized_resolution:
            families.append(f"region/longitude-strips-{normalized_resolution}")
        families.extend(["region/longitude-strips-2048", "regional-scene", "region/longitude-strips"])
        return list(dict.fromkeys(families))
    raise DatasetSourceError(
        f"scene_id {scene_id!r} does not imply a CDN catalog family; pass dataset_family explicitly"
    )


def _normalize_catalog_family(value: str | None) -> str:
    family = _required_string(value, "dataset_family")
    aliases = {
        "region": "region/longitude-strips-2048",
        "regional-scene": "regional-scene",
        "longitude-strips": "region/longitude-strips-2048",
    }
    return aliases.get(family, family)


def _load_json_object(url_or_path: str) -> dict[str, Any]:
    try:
        if _is_local_url_or_path(url_or_path):
            raw = _local_path_from_url_or_path(url_or_path).read_bytes()
        else:
            with _open_url(url_or_path) as response:
                raw = response.read()
        payload = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise DatasetSourceError(f"failed to read CDN dataset catalog JSON {url_or_path!r}: {exc}") from exc
    if not isinstance(payload, dict):
        raise DatasetSourceError(f"CDN dataset catalog JSON must be an object: {url_or_path!r}")
    return payload


def _open_url(url: str):
    request = urllib.request.Request(url, headers={"User-Agent": _HTTP_USER_AGENT})
    return urllib.request.urlopen(request, timeout=300)  # noqa: S310 - caller chooses dataset/catalog URL.


def _find_scene_entry(manifest: Mapping[str, Any], *, scene_id: str, version: str | None) -> Mapping[str, Any] | None:
    scene_ids = set(_scene_id_aliases(scene_id))
    matches: list[Mapping[str, Any]] = []
    scenes = manifest.get("scenes")
    if isinstance(scenes, list):
        matches.extend(entry for entry in scenes if isinstance(entry, Mapping) and entry.get("scene_id") in scene_ids)
    elif isinstance(scenes, Mapping):
        for candidate_scene_id in scene_ids:
            entry = scenes.get(candidate_scene_id)
            if isinstance(entry, Mapping):
                matches.append({"scene_id": candidate_scene_id, **entry})

    countries = manifest.get("countries")
    if isinstance(countries, Mapping):
        for entry in countries.values():
            if isinstance(entry, Mapping) and entry.get("scene_id") in scene_ids:
                matches.append(entry)

    if version is not None:
        matches = [entry for entry in matches if _entry_version(entry) == version]
    matches = _dedupe_scene_entries(matches)
    if len(matches) > 1 and version is None:
        raise DatasetSourceError(f"scene_id {scene_id!r} has multiple catalog entries; pass version")
    return matches[0] if matches else None


def _scene_id_aliases(scene_id: str) -> tuple[str, ...]:
    normalized = scene_id.strip().lower()
    if _is_iso2_scene_id(normalized):
        return (scene_id, f"iso2_{normalized}", f"country_{normalized}")
    if normalized.startswith("iso2_") and len(normalized) == len("iso2_") + 2:
        iso2 = normalized.removeprefix("iso2_")
        return (scene_id, iso2, f"country_{iso2}")
    if normalized.startswith("country_") and len(normalized) == len("country_") + 2:
        iso2 = normalized.removeprefix("country_")
        return (scene_id, iso2, f"iso2_{iso2}")
    return (scene_id,)


def _is_iso2_scene_id(value: str) -> bool:
    return len(value) == 2 and value.isalpha()


def _dedupe_scene_entries(entries: list[Mapping[str, Any]]) -> list[Mapping[str, Any]]:
    result: list[Mapping[str, Any]] = []
    seen: set[tuple[str | None, str | None, str | None]] = set()
    for entry in entries:
        archive = entry.get("archive")
        archive_path = archive.get("path") if isinstance(archive, Mapping) else None
        archive_sha256 = archive.get("sha256") if isinstance(archive, Mapping) else None
        key = (
            _entry_version(entry),
            archive_path if isinstance(archive_path, str) else None,
            archive_sha256 if isinstance(archive_sha256, str) else None,
        )
        if key in seen:
            continue
        seen.add(key)
        result.append(entry)
    return result


def _entry_version(entry: Mapping[str, Any]) -> str | None:
    value = entry.get("version") or entry.get("scene_version")
    return value.strip() if isinstance(value, str) and value.strip() else None


def _catalog_archive_root(manifest: Mapping[str, Any], *, manifest_root: str) -> str:
    base_url = manifest.get("base_url")
    if isinstance(base_url, str) and base_url.strip() and urlparse(base_url).scheme != "cdn":
        return base_url.strip().rstrip("/")
    return manifest_root


def _catalog_archive_url(archive: Mapping[str, Any], *, archive_root: str) -> str:
    url = archive.get("url")
    if isinstance(url, str) and url.strip() and urlparse(url.strip()).scheme != "cdn":
        return url.strip()
    path = archive.get("path")
    if isinstance(path, str) and path.strip():
        return _join_url_or_path(archive_root, path.strip())
    if isinstance(url, str) and url.strip():
        return _join_url_or_path(archive_root, _cdn_catalog_path(url.strip(), archive_root=archive_root))
    raise DatasetSourceError("CDN dataset catalog archive requires path or url")


def _cdn_catalog_path(url: str, *, archive_root: str) -> str:
    parsed = urlparse(url)
    path = parsed.path.strip().lstrip("/")
    if not path:
        raise DatasetSourceError(f"cdn archive URL does not include a path: {url!r}")
    root_name = str(archive_root).strip().rstrip("/").rsplit("/", 1)[-1]
    prefixes = (
        "single-country",
        "worldwide",
        "regional-scene",
        "region/longitude-strips-2048",
        "region/longitude-strips",
    )
    for prefix in prefixes:
        if path.startswith(f"{prefix}/") and root_name == prefix.rsplit("/", 1)[-1]:
            return path[len(prefix) + 1 :]
    return path


def _join_url_or_path(root: str, path: str) -> str:
    normalized_root = str(root).strip().rstrip("/")
    normalized_path = path.strip().lstrip("/")
    if _is_local_url_or_path(normalized_root) and not urlparse(normalized_root).scheme:
        return str((Path(normalized_root).expanduser() / normalized_path).resolve())
    return f"{normalized_root}/{normalized_path}"


def _is_local_url_or_path(value: str) -> bool:
    return urlparse(str(value)).scheme in {"", "file"}


def _local_path_from_url_or_path(value: str) -> Path:
    parsed = urlparse(str(value))
    if parsed.scheme == "file":
        return Path(unquote(parsed.path)).expanduser().resolve()
    return Path(value).expanduser().resolve()


def _required_string(value: object, label: str) -> str:
    if isinstance(value, str):
        normalized = value.strip()
        if normalized:
            return normalized
    raise DatasetSourceError(f"{label} is required")


def _optional_nonempty_string(value: object) -> str | None:
    if isinstance(value, str) and value.strip():
        return value.strip()
    return None


def _verify_sha256(path: Path, expected: str) -> None:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    actual = digest.hexdigest()
    if actual.lower() != expected.lower():
        raise DatasetSourceError(f"dataset archive sha256 mismatch: expected {expected}, got {actual}")


def _extract_archive(archive: Path, destination: Path) -> None:
    suffixes = "".join(archive.suffixes)
    if suffixes.endswith((".tar.gz", ".tgz", ".tar")):
        with tarfile.open(archive) as handle:
            _safe_extract_tar(handle, destination)
        return
    if suffixes.endswith(".zip"):
        with zipfile.ZipFile(archive) as handle:
            _safe_extract_zip(handle, destination)
        return
    raise DatasetSourceError(f"unsupported dataset archive format: {archive.name}")


def _safe_extract_tar(handle: tarfile.TarFile, destination: Path) -> None:
    root = destination.resolve()
    for member in handle.getmembers():
        target = (destination / member.name).resolve()
        if root != target and root not in target.parents:
            raise DatasetSourceError(f"unsafe archive member path: {member.name}")
    try:
        handle.extractall(destination, filter="data")
    except TypeError:
        handle.extractall(destination)


def _safe_extract_zip(handle: zipfile.ZipFile, destination: Path) -> None:
    root = destination.resolve()
    for member in handle.namelist():
        target = (destination / member).resolve()
        if root != target and root not in target.parents:
            raise DatasetSourceError(f"unsafe archive member path: {member}")
    handle.extractall(destination)


def _archive_suffix(url: str) -> str:
    name = url.rsplit("/", 1)[-1]
    suffixes = "".join(Path(name).suffixes)
    for suffix in (".tar.gz", ".tgz", ".tar", ".zip"):
        if suffixes.endswith(suffix):
            return suffix
    return ".archive"


def _safe_cache_key(value: str) -> str:
    key = value.strip().replace("/", "_")
    if not key or any(char in key for char in "\\:\0"):
        raise DatasetSourceError(f"invalid dataset cache key: {value!r}")
    return key


def _dataset_subdir(root: Path, subdir: str | None) -> Path:
    if subdir is None:
        return root
    candidate = (root / subdir).resolve()
    resolved_root = root.resolve()
    if candidate != resolved_root and resolved_root not in candidate.parents:
        raise DatasetSourceError(f"invalid dataset subdir: {subdir!r}")
    return candidate
