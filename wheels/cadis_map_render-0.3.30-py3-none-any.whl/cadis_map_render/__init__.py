from __future__ import annotations

from cadis_map_render.admission import admit_scene_package, validate_scene_package
from cadis_map_render.api import CadisMapRenderApiError, CadisMapRenderService, CadisMapRenderServiceConfig
from cadis_map_render.dataset import (
    DEFAULT_CDN_DATASET_ROOT,
    CadisMapRenderClient,
    CdnDatasetCatalogSource,
    CdnDatasetSource,
    DatasetSourceError,
    FileDatasetSource,
    resolve_default_cache_root,
)
from cadis_map_render.render import MAP_RENDER_PROFILE, render_map

__all__ = [
    "CadisMapRenderApiError",
    "CadisMapRenderClient",
    "CadisMapRenderService",
    "CadisMapRenderServiceConfig",
    "CdnDatasetCatalogSource",
    "CdnDatasetSource",
    "DEFAULT_CDN_DATASET_ROOT",
    "DatasetSourceError",
    "FileDatasetSource",
    "MAP_RENDER_PROFILE",
    "admit_scene_package",
    "render_map",
    "resolve_default_cache_root",
    "validate_scene_package",
]

__version__ = "0.3.30"
